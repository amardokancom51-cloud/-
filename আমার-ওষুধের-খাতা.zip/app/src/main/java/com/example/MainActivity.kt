package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PharmacyTealPrimary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AppViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

data class BottomNavItem(
    val label: String,
    val screen: AppScreen,
    val icon: ImageVector
)

@Composable
fun MainApp(viewModel: AppViewModel = viewModel()) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val context = LocalContext.current

    // Request notification permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Hardware back button navigation handling
    BackHandler(
        enabled = currentScreen != AppScreen.DASHBOARD &&
                currentScreen != AppScreen.PIN_LOCK &&
                currentScreen != AppScreen.FIRST_SETUP
    ) {
        viewModel.navigateBack()
    }

    val primaryNavScreens = listOf(
        AppScreen.DASHBOARD,
        AppScreen.SALES_LIST,
        AppScreen.CHALLAN_LIST,
        AppScreen.CUSTOMER_LIST,
        AppScreen.MEDICINE_LIST,
        AppScreen.REPORTS,
        AppScreen.SETTINGS
    )

    val showBottomBar = currentScreen in primaryNavScreens

    val navItems = listOf(
        BottomNavItem("হোম", AppScreen.DASHBOARD, Icons.Default.Home),
        BottomNavItem("বিক্রি", AppScreen.SALES_LIST, Icons.Default.PointOfSale),
        BottomNavItem("বাকি", AppScreen.CUSTOMER_LIST, Icons.Default.People),
        BottomNavItem("ওষুধ", AppScreen.MEDICINE_LIST, Icons.Default.Medication),
        BottomNavItem("রিপোর্ট", AppScreen.REPORTS, Icons.Default.BarChart),
        BottomNavItem("সেটিংস", AppScreen.SETTINGS, Icons.Default.Settings)
    )

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    navItems.forEach { item ->
                        val selected = currentScreen == item.screen
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentScreen != item.screen) {
                                    viewModel.navigateTo(item.screen)
                                }
                            },
                            icon = { Icon(imageVector = item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PharmacyTealPrimary,
                                selectedTextColor = PharmacyTealPrimary,
                                indicatorColor = PharmacyTealPrimary.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.FIRST_SETUP -> FirstLaunchSetupScreen(viewModel)
                AppScreen.PIN_LOCK -> PinLockScreen(viewModel)
                AppScreen.DASHBOARD -> DashboardScreen(viewModel)
                AppScreen.SALES_LIST -> SalesListScreen(viewModel)
                AppScreen.NEW_SALE -> NewSaleScreen(viewModel)
                AppScreen.CUSTOMER_LIST -> CustomerListScreen(viewModel)
                AppScreen.CUSTOMER_DETAIL -> CustomerDetailScreen(viewModel)
                AppScreen.MEDICINE_LIST -> MedicineListScreen(viewModel)
                AppScreen.MEDICINE_DETAIL -> MedicineDetailScreen(viewModel)
                AppScreen.PAYMENT_ENTRY -> PaymentEntryScreen(viewModel)
                AppScreen.STOCK_PURCHASE -> StockPurchaseScreen(viewModel)
                AppScreen.SALES_RETURN -> SalesReturnScreen(viewModel)
                AppScreen.CHALLAN_LIST -> ChallanListScreen(viewModel)
                AppScreen.NEW_CHALLAN -> NewChallanScreen(viewModel)
                AppScreen.CHALLAN_DETAIL -> ChallanDetailScreen(viewModel)
                AppScreen.CHALLAN_PREVIEW -> ChallanPreviewScreen(viewModel)
                AppScreen.REPORTS -> ReportsScreen(viewModel)
                AppScreen.RECEIPT_PREVIEW -> ReceiptPreviewScreen(viewModel)
                AppScreen.SETTINGS -> SettingsScreen(viewModel)
            }
        }
    }
}
