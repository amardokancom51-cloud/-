package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

data class CustomerLedgerEntry(
    val id: Long,
    val date: Long,
    val type: String, // "OPENING_DUE", "SALE", "PAYMENT", "RETURN"
    val title: String,
    val receiptNumber: String,
    val debit: Double, // Added to Due (Sale total)
    val credit: Double, // Deducted from Due (Payment or Return)
    val balance: Double, // Running balance after this entry
    val note: String = ""
)

data class CustomerFinancialSummary(
    val customer: Customer,
    val totalSalesAmount: Double,
    val totalPaidAmount: Double,
    val totalReturnsAmount: Double,
    val currentDue: Double
)

class AppRepository(private val database: AppDatabase) {
    val customerDao = database.customerDao()
    val medicineDao = database.medicineDao()
    val saleDao = database.saleDao()
    val paymentDao = database.paymentDao()
    val supplierDao = database.supplierDao()
    val stockDao = database.stockDao()
    val settingDao = database.settingDao()
    val challanDao = database.challanDao()

    // Customers
    fun getAllCustomers(): Flow<List<Customer>> = customerDao.getAllCustomers()
    suspend fun getCustomerById(id: Long): Customer? = customerDao.getCustomerById(id)
    fun getCustomerByIdFlow(id: Long): Flow<Customer?> = customerDao.getCustomerByIdFlow(id)
    fun searchCustomers(query: String): Flow<List<Customer>> = customerDao.searchCustomers(query)

    suspend fun insertCustomer(customer: Customer): Long = withContext(Dispatchers.IO) {
        customerDao.insertCustomer(customer)
    }

    suspend fun updateCustomer(customer: Customer) = withContext(Dispatchers.IO) {
        customerDao.updateCustomer(customer)
    }

    suspend fun deleteCustomer(customer: Customer) = withContext(Dispatchers.IO) {
        customerDao.deleteCustomer(customer)
    }

    suspend fun updateExpectedPaymentDate(customerId: Long, date: Long?, note: String) = withContext(Dispatchers.IO) {
        customerDao.updateExpectedPayment(customerId, date, note)
    }

    // Medicines
    fun getAllMedicines(): Flow<List<Medicine>> = medicineDao.getAllMedicines()
    fun searchMedicines(query: String): Flow<List<Medicine>> = medicineDao.searchMedicines(query)
    fun getLowStockMedicines(): Flow<List<Medicine>> = medicineDao.getLowStockMedicines()
    suspend fun getMedicineById(id: Long): Medicine? = medicineDao.getMedicineById(id)
    fun getMedicineByIdFlow(id: Long): Flow<Medicine?> = medicineDao.getMedicineByIdFlow(id)

    suspend fun insertMedicine(medicine: Medicine): Long = withContext(Dispatchers.IO) {
        medicineDao.insertMedicine(medicine)
    }

    suspend fun updateMedicine(medicine: Medicine) = withContext(Dispatchers.IO) {
        medicineDao.updateMedicine(medicine)
    }

    suspend fun deleteMedicine(id: Long) = withContext(Dispatchers.IO) {
        medicineDao.deleteMedicine(id)
    }

    // Suppliers
    fun getAllSuppliers(): Flow<List<Supplier>> = supplierDao.getAllSuppliers()
    suspend fun insertSupplier(supplier: Supplier): Long = withContext(Dispatchers.IO) {
        supplierDao.insertSupplier(supplier)
    }

    // Stock Transactions
    fun getTransactionsForMedicine(medicineId: Long): Flow<List<StockTransaction>> =
        stockDao.getTransactionsForMedicine(medicineId)

    suspend fun adjustStock(medicineId: Long, newStock: Double, note: String) = withContext(Dispatchers.IO) {
        val med = medicineDao.getMedicineById(medicineId) ?: return@withContext
        val prevStock = med.currentStock
        medicineDao.updateStock(medicineId, newStock)
        stockDao.insertStockTransaction(
            StockTransaction(
                medicineId = medicineId,
                medicineName = med.name,
                type = "ADJUSTMENT",
                quantityChange = newStock - prevStock,
                previousStock = prevStock,
                newStock = newStock,
                note = note
            )
        )
    }

    // Stock Purchase
    suspend fun recordStockPurchase(purchase: StockPurchase) = withContext(Dispatchers.IO) {
        database.withTransaction {
            val purchaseId = stockDao.insertPurchase(purchase)
            val med = medicineDao.getMedicineById(purchase.medicineId)
            if (med != null) {
                val updatedStock = med.currentStock + purchase.quantity
                medicineDao.updateStock(med.id, updatedStock)
                stockDao.insertStockTransaction(
                    StockTransaction(
                        medicineId = med.id,
                        medicineName = med.name,
                        type = "PURCHASE",
                        quantityChange = purchase.quantity,
                        previousStock = med.currentStock,
                        newStock = updatedStock,
                        referenceId = purchaseId,
                        note = "ক্রয় চালান / সরবরাহকারী: ${purchase.supplierName}"
                    )
                )
            }
        }
    }

    // Sales Returns
    suspend fun recordSalesReturn(salesReturn: SalesReturn) = withContext(Dispatchers.IO) {
        database.withTransaction {
            val returnId = stockDao.insertReturn(salesReturn)
            val med = medicineDao.getMedicineById(salesReturn.medicineId)
            if (med != null) {
                val updatedStock = med.currentStock + salesReturn.quantity
                medicineDao.updateStock(med.id, updatedStock)
                stockDao.insertStockTransaction(
                    StockTransaction(
                        medicineId = med.id,
                        medicineName = med.name,
                        type = "RETURN",
                        quantityChange = salesReturn.quantity,
                        previousStock = med.currentStock,
                        newStock = updatedStock,
                        referenceId = returnId,
                        note = "ওষুধ ফেরত - ${salesReturn.customerName}"
                    )
                )
            }
        }
    }

    // Sales
    fun getAllSales(): Flow<List<Sale>> = saleDao.getAllSales()
    suspend fun getSaleById(id: Long): Sale? = saleDao.getSaleById(id)
    fun getSaleItems(saleId: Long): Flow<List<SaleItem>> = saleDao.getSaleItems(saleId)

    suspend fun createSale(sale: Sale, items: List<SaleItem>): Long = withContext(Dispatchers.IO) {
        database.withTransaction {
            val saleId = saleDao.insertSale(sale)
            val itemsWithSaleId = items.map { it.copy(saleId = saleId) }
            saleDao.insertSaleItems(itemsWithSaleId)

            // Deduct stock for each item sold
            for (item in items) {
                val med = medicineDao.getMedicineById(item.medicineId)
                if (med != null) {
                    val newStock = (med.currentStock - item.quantity).coerceAtLeast(0.0)
                    medicineDao.updateStock(med.id, newStock)
                    stockDao.insertStockTransaction(
                        StockTransaction(
                            medicineId = med.id,
                            medicineName = med.name,
                            type = "SALE",
                            quantityChange = -item.quantity,
                            previousStock = med.currentStock,
                            newStock = newStock,
                            referenceId = saleId,
                            note = "বিক্রি চালান: ${sale.receiptNumber}"
                        )
                    )
                }
            }
            saleId
        }
    }

    suspend fun updateSaleTransaction(sale: Sale, items: List<SaleItem>) = withContext(Dispatchers.IO) {
        database.withTransaction {
            // Restore previous stock
            val oldItems = saleDao.getSaleItemsSync(sale.id)
            for (oldItem in oldItems) {
                val med = medicineDao.getMedicineById(oldItem.medicineId)
                if (med != null) {
                    medicineDao.updateStock(med.id, med.currentStock + oldItem.quantity)
                }
            }

            // Remove old items and insert new ones
            saleDao.deleteSaleItems(sale.id)
            val updatedItems = items.map { it.copy(saleId = sale.id) }
            saleDao.insertSaleItems(updatedItems)
            saleDao.updateSale(sale)

            // Deduct new stock
            for (newItem in items) {
                val med = medicineDao.getMedicineById(newItem.medicineId)
                if (med != null) {
                    val newStock = (med.currentStock - newItem.quantity).coerceAtLeast(0.0)
                    medicineDao.updateStock(med.id, newStock)
                }
            }
        }
    }

    suspend fun deleteSale(saleId: Long) = withContext(Dispatchers.IO) {
        database.withTransaction {
            val sale = saleDao.getSaleById(saleId) ?: return@withTransaction
            val items = saleDao.getSaleItemsSync(saleId)
            // Restore stock
            for (item in items) {
                val med = medicineDao.getMedicineById(item.medicineId)
                if (med != null) {
                    val restoredStock = med.currentStock + item.quantity
                    medicineDao.updateStock(med.id, restoredStock)
                    stockDao.insertStockTransaction(
                        StockTransaction(
                            medicineId = med.id,
                            medicineName = med.name,
                            type = "ADJUSTMENT",
                            quantityChange = item.quantity,
                            previousStock = med.currentStock,
                            newStock = restoredStock,
                            referenceId = saleId,
                            note = "বিক্রি বাতিল হয়ে স্টক ফেরত: ${sale.receiptNumber}"
                        )
                    )
                }
            }
            saleDao.softDeleteSale(saleId)
        }
    }

    // Payments
    fun getAllPayments(): Flow<List<Payment>> = paymentDao.getAllPayments()
    suspend fun getPaymentById(id: Long): Payment? = paymentDao.getPaymentById(id)

    suspend fun recordPayment(payment: Payment): Long = withContext(Dispatchers.IO) {
        paymentDao.insertPayment(payment)
    }

    suspend fun updatePayment(payment: Payment) = withContext(Dispatchers.IO) {
        paymentDao.updatePayment(payment)
    }

    suspend fun deletePayment(paymentId: Long) = withContext(Dispatchers.IO) {
        paymentDao.softDeletePayment(paymentId)
    }

    // Ledger Calculation Engine
    suspend fun getCustomerLedger(customerId: Long): List<CustomerLedgerEntry> = withContext(Dispatchers.IO) {
        val customer = customerDao.getCustomerById(customerId) ?: return@withContext emptyList()
        val sales = saleDao.getSalesForCustomerSync(customerId)
        val payments = paymentDao.getPaymentsForCustomerSync(customerId)
        val returns = stockDao.getReturnsForCustomerSync(customerId)
        val challans = challanDao.getChallansForCustomerSync(customerId)

        // Raw events to be sorted chronologically
        data class RawEvent(
            val id: Long,
            val date: Long,
            val type: String,
            val title: String,
            val receiptNumber: String,
            val debit: Double,
            val credit: Double,
            val note: String
        )

        val events = mutableListOf<RawEvent>()

        // Opening Due
        if (customer.openingDue > 0.0) {
            events.add(
                RawEvent(
                    id = 0,
                    date = customer.createdAt,
                    type = "OPENING_DUE",
                    title = "পূর্বের জের (Opening Due)",
                    receiptNumber = "-",
                    debit = customer.openingDue,
                    credit = 0.0,
                    note = "খাতা খোলার সময় পূর্বের বাকি"
                )
            )
        }

        // Sales
        for (sale in sales) {
            events.add(
                RawEvent(
                    id = sale.id,
                    date = sale.saleDate,
                    type = "SALE",
                    title = "ওষুধ বিক্রি",
                    receiptNumber = sale.receiptNumber,
                    debit = sale.grandTotal,
                    credit = sale.paidAmount,
                    note = sale.note
                )
            )
        }

        // Challans (ওষুধের চালান)
        for (ch in challans) {
            events.add(
                RawEvent(
                    id = ch.id,
                    date = ch.challanDate,
                    type = "CHALLAN",
                    title = "ওষুধের চালান",
                    receiptNumber = ch.challanNumber,
                    debit = ch.grandTotal,
                    credit = ch.paidAmount,
                    note = ch.note
                )
            )
        }

        // Payments
        for (payment in payments) {
            events.add(
                RawEvent(
                    id = payment.id,
                    date = payment.paymentDate,
                    type = "PAYMENT",
                    title = "বাকি আদায় / জমা (${payment.paymentMethod})",
                    receiptNumber = payment.receiptNumber.ifBlank { "PAY-${payment.id}" },
                    debit = 0.0,
                    credit = payment.amount,
                    note = payment.note
                )
            )
        }

        // Returns
        for (ret in returns) {
            events.add(
                RawEvent(
                    id = ret.id,
                    date = ret.returnDate,
                    type = "RETURN",
                    title = "ওষুধ ফেরত সমন্বয় (${ret.medicineName})",
                    receiptNumber = "RET-${ret.id}",
                    debit = 0.0,
                    credit = ret.returnAmount,
                    note = ret.reason
                )
            )
        }

        // Sort by date ascending
        events.sortBy { it.date }

        var runningBalance = 0.0
        val ledger = mutableListOf<CustomerLedgerEntry>()

        for (e in events) {
            // debit increases balance due, credit decreases balance due
            runningBalance += (e.debit - e.credit)
            ledger.add(
                CustomerLedgerEntry(
                    id = e.id,
                    date = e.date,
                    type = e.type,
                    title = e.title,
                    receiptNumber = e.receiptNumber,
                    debit = e.debit,
                    credit = e.credit,
                    balance = runningBalance,
                    note = e.note
                )
            )
        }

        ledger
    }

    suspend fun getCustomerFinancialSummary(customerId: Long): CustomerFinancialSummary? = withContext(Dispatchers.IO) {
        val customer = customerDao.getCustomerById(customerId) ?: return@withContext null
        val sales = saleDao.getSalesForCustomerSync(customerId)
        val challans = challanDao.getChallansForCustomerSync(customerId)
        val payments = paymentDao.getPaymentsForCustomerSync(customerId)
        val returns = stockDao.getReturnsForCustomerSync(customerId)

        val totalSalesOnly = sales.sumOf { it.grandTotal }
        val totalChallanSales = challans.sumOf { it.grandTotal }
        val totalSales = totalSalesOnly + totalChallanSales

        val totalSalePayments = sales.sumOf { it.paidAmount }
        val totalChallanPayments = challans.sumOf { it.paidAmount }
        val directPayments = payments.sumOf { it.amount }
        val totalPaid = totalSalePayments + totalChallanPayments + directPayments
        val totalReturns = returns.sumOf { it.returnAmount }

        val currentDue = (customer.openingDue + totalSales) - (totalPaid + totalReturns)

        CustomerFinancialSummary(
            customer = customer,
            totalSalesAmount = totalSales,
            totalPaidAmount = totalPaid,
            totalReturnsAmount = totalReturns,
            currentDue = currentDue
        )
    }

    // Medicine Challan Management
    fun getAllChallans(): Flow<List<Challan>> = challanDao.getAllChallans()
    suspend fun getChallanById(id: Long): Challan? = challanDao.getChallanById(id)
    fun getChallanItems(challanId: Long): Flow<List<ChallanItem>> = challanDao.getChallanItems(challanId)
    suspend fun getChallanItemsSync(challanId: Long): List<ChallanItem> = challanDao.getChallanItemsSync(challanId)

    suspend fun saveChallan(challan: Challan, items: List<ChallanItem>): Long = withContext(Dispatchers.IO) {
        database.withTransaction {
            val challanId = challanDao.insertChallan(challan)
            val itemsWithId = items.map { it.copy(challanId = challanId) }
            challanDao.insertChallanItems(itemsWithId)

            // Deduct stock for each medicine item
            for (item in items) {
                if (item.medicineId > 0) {
                    val med = medicineDao.getMedicineById(item.medicineId)
                    if (med != null) {
                        val newStock = (med.currentStock - item.totalPieces).coerceAtLeast(0.0)
                        medicineDao.updateStock(med.id, newStock)
                        stockDao.insertStockTransaction(
                            StockTransaction(
                                medicineId = med.id,
                                medicineName = med.name,
                                type = "SALE",
                                quantityChange = -item.totalPieces,
                                previousStock = med.currentStock,
                                newStock = newStock,
                                referenceId = challanId,
                                note = "ওষুধের চালান: ${challan.challanNumber} (${item.boxQuantity} বক্স)"
                            )
                        )
                    }
                }
            }
            challanId
        }
    }

    suspend fun updateChallanTransaction(challan: Challan, items: List<ChallanItem>) = withContext(Dispatchers.IO) {
        database.withTransaction {
            // Restore previous stock
            val oldItems = challanDao.getChallanItemsSync(challan.id)
            for (oldItem in oldItems) {
                if (oldItem.medicineId > 0) {
                    val med = medicineDao.getMedicineById(oldItem.medicineId)
                    if (med != null) {
                        medicineDao.updateStock(med.id, med.currentStock + oldItem.totalPieces)
                    }
                }
            }

            // Remove old items and insert new ones
            challanDao.deleteChallanItems(challan.id)
            val updatedItems = items.map { it.copy(challanId = challan.id) }
            challanDao.insertChallanItems(updatedItems)
            challanDao.updateChallan(challan)

            // Deduct new stock
            for (newItem in items) {
                if (newItem.medicineId > 0) {
                    val med = medicineDao.getMedicineById(newItem.medicineId)
                    if (med != null) {
                        val newStock = (med.currentStock - newItem.totalPieces).coerceAtLeast(0.0)
                        medicineDao.updateStock(med.id, newStock)
                    }
                }
            }
        }
    }

    suspend fun cancelChallan(challanId: Long) = withContext(Dispatchers.IO) {
        database.withTransaction {
            val challan = challanDao.getChallanById(challanId) ?: return@withTransaction
            val items = challanDao.getChallanItemsSync(challanId)
            // Restore stock
            for (item in items) {
                if (item.medicineId > 0) {
                    val med = medicineDao.getMedicineById(item.medicineId)
                    if (med != null) {
                        val restoredStock = med.currentStock + item.totalPieces
                        medicineDao.updateStock(med.id, restoredStock)
                        stockDao.insertStockTransaction(
                            StockTransaction(
                                medicineId = med.id,
                                medicineName = med.name,
                                type = "ADJUSTMENT",
                                quantityChange = item.totalPieces,
                                previousStock = med.currentStock,
                                newStock = restoredStock,
                                referenceId = challanId,
                                note = "চালান বাতিল হওয়ায় স্টক ফেরত: ${challan.challanNumber}"
                            )
                        )
                    }
                }
            }
            challanDao.cancelChallan(challanId)
        }
    }

    fun generateChallanNumber(): String {
        val dateFormat = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US)
        val dateStr = dateFormat.format(Date())
        return "CH-$dateStr"
    }

    suspend fun calculateCustomerDue(customerId: Long): Double = withContext(Dispatchers.IO) {
        val summary = getCustomerFinancialSummary(customerId)
        summary?.currentDue ?: 0.0
    }

    // App Settings
    suspend fun getSetting(key: String, defaultValue: String = ""): String = withContext(Dispatchers.IO) {
        settingDao.getSetting(key) ?: defaultValue
    }

    suspend fun setSetting(key: String, value: String) = withContext(Dispatchers.IO) {
        settingDao.setSetting(AppSetting(key, value))
    }

    fun generateReceiptNumber(prefix: String = "INV"): String {
        val dateFormat = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US)
        val dateStr = dateFormat.format(Date())
        return "$prefix-$dateStr"
    }
}
