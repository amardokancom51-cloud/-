package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE isArchived = 0 ORDER BY name ASC")
    fun getAllCustomers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerById(id: Long): Customer?

    @Query("SELECT * FROM customers WHERE id = :id")
    fun getCustomerByIdFlow(id: Long): Flow<Customer?>

    @Query("SELECT * FROM customers WHERE isArchived = 0 AND (name LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%') ORDER BY name ASC")
    fun searchCustomers(query: String): Flow<List<Customer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer): Long

    @Update
    suspend fun updateCustomer(customer: Customer)

    @Delete
    suspend fun deleteCustomer(customer: Customer)

    @Query("UPDATE customers SET expectedPaymentDate = :date, expectedPaymentNote = :note WHERE id = :customerId")
    suspend fun updateExpectedPayment(customerId: Long, date: Long?, note: String)

    @Query("DELETE FROM customers")
    suspend fun clearAll()
}

@Dao
interface MedicineDao {
    @Query("SELECT * FROM medicines WHERE isDeleted = 0 ORDER BY name ASC")
    fun getAllMedicines(): Flow<List<Medicine>>

    @Query("SELECT * FROM medicines WHERE isDeleted = 0 ORDER BY name ASC")
    suspend fun getAllMedicinesSync(): List<Medicine>

    @Query("SELECT * FROM medicines WHERE id = :id")
    suspend fun getMedicineById(id: Long): Medicine?

    @Query("SELECT * FROM medicines WHERE id = :id")
    fun getMedicineByIdFlow(id: Long): Flow<Medicine?>

    @Query("SELECT * FROM medicines WHERE isDeleted = 0 AND (name LIKE '%' || :query || '%' OR genericName LIKE '%' || :query || '%' OR company LIKE '%' || :query || '%') ORDER BY name ASC")
    fun searchMedicines(query: String): Flow<List<Medicine>>

    @Query("SELECT * FROM medicines WHERE isDeleted = 0 AND currentStock <= minStockLevel ORDER BY currentStock ASC")
    fun getLowStockMedicines(): Flow<List<Medicine>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicine(medicine: Medicine): Long

    @Update
    suspend fun updateMedicine(medicine: Medicine)

    @Query("UPDATE medicines SET isDeleted = 1 WHERE id = :id")
    suspend fun deleteMedicine(id: Long)

    @Query("UPDATE medicines SET currentStock = :newStock WHERE id = :id")
    suspend fun updateStock(id: Long, newStock: Double)

    @Query("DELETE FROM medicines")
    suspend fun clearAll()
}

@Dao
interface SaleDao {
    @Query("SELECT * FROM sales WHERE isDeleted = 0 ORDER BY saleDate DESC")
    fun getAllSales(): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE isDeleted = 0 ORDER BY saleDate DESC")
    suspend fun getAllSalesSync(): List<Sale>

    @Query("SELECT * FROM sales WHERE id = :id")
    suspend fun getSaleById(id: Long): Sale?

    @Query("SELECT * FROM sales WHERE isDeleted = 0 AND customerId = :customerId ORDER BY saleDate ASC")
    fun getSalesForCustomer(customerId: Long): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE isDeleted = 0 AND customerId = :customerId ORDER BY saleDate ASC")
    suspend fun getSalesForCustomerSync(customerId: Long): List<Sale>

    @Query("SELECT * FROM sales WHERE isDeleted = 0 AND saleDate >= :startDate AND saleDate <= :endDate ORDER BY saleDate DESC")
    fun getSalesBetweenDates(startDate: Long, endDate: Long): Flow<List<Sale>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: Sale): Long

    @Update
    suspend fun updateSale(sale: Sale)

    @Query("UPDATE sales SET isDeleted = 1 WHERE id = :id")
    suspend fun softDeleteSale(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSaleItems(items: List<SaleItem>)

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
    fun getSaleItems(saleId: Long): Flow<List<SaleItem>>

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
    suspend fun getSaleItemsSync(saleId: Long): List<SaleItem>

    @Query("SELECT * FROM sale_items")
    suspend fun getAllSaleItemsSync(): List<SaleItem>

    @Query("DELETE FROM sale_items WHERE saleId = :saleId")
    suspend fun deleteSaleItems(saleId: Long)

    @Query("DELETE FROM sales")
    suspend fun clearAllSales()

    @Query("DELETE FROM sale_items")
    suspend fun clearAllSaleItems()
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE isDeleted = 0 ORDER BY paymentDate DESC")
    fun getAllPayments(): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE isDeleted = 0 ORDER BY paymentDate DESC")
    suspend fun getAllPaymentsSync(): List<Payment>

    @Query("SELECT * FROM payments WHERE id = :id")
    suspend fun getPaymentById(id: Long): Payment?

    @Query("SELECT * FROM payments WHERE isDeleted = 0 AND customerId = :customerId ORDER BY paymentDate ASC")
    fun getPaymentsForCustomer(customerId: Long): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE isDeleted = 0 AND customerId = :customerId ORDER BY paymentDate ASC")
    suspend fun getPaymentsForCustomerSync(customerId: Long): List<Payment>

    @Query("SELECT * FROM payments WHERE isDeleted = 0 AND paymentDate >= :startDate AND paymentDate <= :endDate ORDER BY paymentDate DESC")
    fun getPaymentsBetweenDates(startDate: Long, endDate: Long): Flow<List<Payment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: Payment): Long

    @Update
    suspend fun updatePayment(payment: Payment)

    @Query("UPDATE payments SET isDeleted = 1 WHERE id = :id")
    suspend fun softDeletePayment(id: Long)

    @Query("DELETE FROM payments")
    suspend fun clearAll()
}

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers ORDER BY name ASC")
    fun getAllSuppliers(): Flow<List<Supplier>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplier(supplier: Supplier): Long

    @Update
    suspend fun updateSupplier(supplier: Supplier)

    @Query("DELETE FROM suppliers WHERE id = :id")
    suspend fun deleteSupplier(id: Long)

    @Query("DELETE FROM suppliers")
    suspend fun clearAll()
}

@Dao
interface StockDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: StockPurchase): Long

    @Query("SELECT * FROM stock_purchases ORDER BY purchaseDate DESC")
    fun getAllPurchases(): Flow<List<StockPurchase>>

    @Query("SELECT * FROM stock_purchases ORDER BY purchaseDate DESC")
    suspend fun getAllPurchasesSync(): List<StockPurchase>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReturn(salesReturn: SalesReturn): Long

    @Query("SELECT * FROM sales_returns ORDER BY returnDate DESC")
    fun getAllReturns(): Flow<List<SalesReturn>>

    @Query("SELECT * FROM sales_returns ORDER BY returnDate DESC")
    suspend fun getAllReturnsSync(): List<SalesReturn>

    @Query("SELECT * FROM sales_returns WHERE customerId = :customerId ORDER BY returnDate ASC")
    suspend fun getReturnsForCustomerSync(customerId: Long): List<SalesReturn>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockTransaction(transaction: StockTransaction): Long

    @Query("SELECT * FROM stock_transactions WHERE medicineId = :medicineId ORDER BY date DESC")
    fun getTransactionsForMedicine(medicineId: Long): Flow<List<StockTransaction>>

    @Query("DELETE FROM stock_purchases")
    suspend fun clearAllPurchases()

    @Query("DELETE FROM sales_returns")
    suspend fun clearAllReturns()

    @Query("DELETE FROM stock_transactions")
    suspend fun clearAllTransactions()
}

@Dao
interface SettingDao {
    @Query("SELECT value FROM app_settings WHERE `key` = :key")
    suspend fun getSetting(key: String): String?

    @Query("SELECT value FROM app_settings WHERE `key` = :key")
    fun getSettingFlow(key: String): Flow<String?>

    @Query("SELECT * FROM app_settings")
    suspend fun getAllSettings(): List<AppSetting>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: AppSetting)

    @Query("DELETE FROM app_settings")
    suspend fun clearAll()
}

@Dao
interface ChallanDao {
    @Query("SELECT * FROM challans WHERE isCancelled = 0 ORDER BY challanDate DESC")
    fun getAllChallans(): Flow<List<Challan>>

    @Query("SELECT * FROM challans WHERE isCancelled = 0 ORDER BY challanDate DESC")
    suspend fun getAllChallansSync(): List<Challan>

    @Query("SELECT * FROM challans WHERE id = :id")
    suspend fun getChallanById(id: Long): Challan?

    @Query("SELECT * FROM challans WHERE isCancelled = 0 AND customerId = :customerId ORDER BY challanDate ASC")
    fun getChallansForCustomer(customerId: Long): Flow<List<Challan>>

    @Query("SELECT * FROM challans WHERE isCancelled = 0 AND customerId = :customerId ORDER BY challanDate ASC")
    suspend fun getChallansForCustomerSync(customerId: Long): List<Challan>

    @Query("SELECT * FROM challans WHERE isCancelled = 0 AND challanDate >= :startDate AND challanDate <= :endDate ORDER BY challanDate DESC")
    fun getChallansBetweenDates(startDate: Long, endDate: Long): Flow<List<Challan>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChallan(challan: Challan): Long

    @Update
    suspend fun updateChallan(challan: Challan)

    @Query("UPDATE challans SET isCancelled = 1 WHERE id = :id")
    suspend fun cancelChallan(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChallanItems(items: List<ChallanItem>)

    @Query("SELECT * FROM challan_items WHERE challanId = :challanId ORDER BY serialNumber ASC")
    fun getChallanItems(challanId: Long): Flow<List<ChallanItem>>

    @Query("SELECT * FROM challan_items WHERE challanId = :challanId ORDER BY serialNumber ASC")
    suspend fun getChallanItemsSync(challanId: Long): List<ChallanItem>

    @Query("SELECT * FROM challan_items")
    suspend fun getAllChallanItemsSync(): List<ChallanItem>

    @Query("DELETE FROM challan_items WHERE challanId = :challanId")
    suspend fun deleteChallanItems(challanId: Long)

    @Query("DELETE FROM challans")
    suspend fun clearAllChallans()

    @Query("DELETE FROM challan_items")
    suspend fun clearAllChallanItems()
}
