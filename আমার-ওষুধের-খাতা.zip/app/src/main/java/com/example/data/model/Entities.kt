package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val address: String = "",
    val note: String = "",
    val openingDue: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val expectedPaymentDate: Long? = null,
    val expectedPaymentNote: String = "",
    val isArchived: Boolean = false
)

@Entity(tableName = "medicines")
data class Medicine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val genericName: String = "",
    val company: String = "",
    val category: String = "ট্যাবলেট",
    val strength: String = "",
    val dosageForm: String = "ট্যাবলেট",
    val unit: String = "পাতা/পিস",
    val purchasePrice: Double = 0.0,
    val sellingPrice: Double = 0.0,
    val currentStock: Double = 0.0,
    val minStockLevel: Double = 10.0,
    val batchNumber: String = "",
    val expiryDate: Long = 0L,
    val supplierName: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val isDeleted: Boolean = false
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val receiptNumber: String,
    val customerId: Long? = null,
    val customerName: String = "নগদ ক্রেতা",
    val customerPhone: String = "",
    val subtotal: Double = 0.0,
    val discount: Double = 0.0,
    val grandTotal: Double = 0.0,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val saleDate: Long = System.currentTimeMillis(),
    val note: String = "",
    val isDeleted: Boolean = false
)

@Entity(tableName = "sale_items")
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val medicineId: Long,
    val medicineName: String,
    val quantity: Double,
    val unitPrice: Double,
    val purchasePrice: Double = 0.0,
    val totalPrice: Double
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val receiptNumber: String = "",
    val customerId: Long,
    val amount: Double,
    val paymentDate: Long = System.currentTimeMillis(),
    val paymentMethod: String = "নগদ (Cash)",
    val note: String = "",
    val isDeleted: Boolean = false
)

@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val companyName: String = "",
    val address: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "stock_purchases")
data class StockPurchase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplierId: Long? = null,
    val supplierName: String = "",
    val medicineId: Long,
    val medicineName: String,
    val quantity: Double,
    val purchasePrice: Double,
    val sellingPrice: Double,
    val batchNumber: String = "",
    val expiryDate: Long = 0L,
    val purchaseDate: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(tableName = "sales_returns")
data class SalesReturn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long? = null,
    val customerId: Long? = null,
    val customerName: String = "",
    val medicineId: Long,
    val medicineName: String,
    val quantity: Double,
    val returnAmount: Double,
    val returnDate: Long = System.currentTimeMillis(),
    val reason: String = ""
)

@Entity(tableName = "stock_transactions")
data class StockTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medicineId: Long,
    val medicineName: String,
    val type: String, // SALE, PURCHASE, RETURN, ADJUSTMENT
    val quantityChange: Double,
    val previousStock: Double,
    val newStock: Double,
    val date: Long = System.currentTimeMillis(),
    val referenceId: Long? = null,
    val note: String = ""
)

@Entity(tableName = "app_settings")
data class AppSetting(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "challans")
data class Challan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val challanNumber: String,
    val customerId: Long? = null,
    val customerName: String = "সাধারণ ক্রেতা",
    val customerPhone: String = "",
    val customerAddress: String = "",
    val grossTotal: Double = 0.0,
    val totalDiscount: Double = 0.0,
    val grandTotal: Double = 0.0,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val challanDate: Long = System.currentTimeMillis(),
    val note: String = "",
    val isCancelled: Boolean = false
)

@Entity(tableName = "challan_items")
data class ChallanItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val challanId: Long,
    val serialNumber: Int = 1,
    val medicineId: Long = 0,
    val medicineName: String,
    val companyName: String = "",
    val piecesPerBox: Int = 100,
    val boxQuantity: Double = 1.0,
    val totalPieces: Double = 100.0,
    val boxPrice: Double = 0.0,
    val discountPercent: Double = 0.0,
    val discountAmount: Double = 0.0,
    val netTotal: Double = 0.0
)
