package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.*
import com.example.data.model.*

@Database(
    entities = [
        Customer::class,
        Medicine::class,
        Sale::class,
        SaleItem::class,
        Payment::class,
        Supplier::class,
        StockPurchase::class,
        SalesReturn::class,
        StockTransaction::class,
        AppSetting::class,
        Challan::class,
        ChallanItem::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun medicineDao(): MedicineDao
    abstract fun saleDao(): SaleDao
    abstract fun paymentDao(): PaymentDao
    abstract fun supplierDao(): SupplierDao
    abstract fun stockDao(): StockDao
    abstract fun settingDao(): SettingDao
    abstract fun challanDao(): ChallanDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `challans` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `challanNumber` TEXT NOT NULL,
                        `customerId` INTEGER,
                        `customerName` TEXT NOT NULL,
                        `customerPhone` TEXT NOT NULL,
                        `customerAddress` TEXT NOT NULL,
                        `grossTotal` REAL NOT NULL,
                        `totalDiscount` REAL NOT NULL,
                        `grandTotal` REAL NOT NULL,
                        `paidAmount` REAL NOT NULL,
                        `dueAmount` REAL NOT NULL,
                        `challanDate` INTEGER NOT NULL,
                        `note` TEXT NOT NULL,
                        `isCancelled` INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `challan_items` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `challanId` INTEGER NOT NULL,
                        `serialNumber` INTEGER NOT NULL,
                        `medicineId` INTEGER NOT NULL,
                        `medicineName` TEXT NOT NULL,
                        `companyName` TEXT NOT NULL,
                        `piecesPerBox` INTEGER NOT NULL,
                        `boxQuantity` REAL NOT NULL,
                        `totalPieces` REAL NOT NULL,
                        `boxPrice` REAL NOT NULL,
                        `discountPercent` REAL NOT NULL,
                        `discountAmount` REAL NOT NULL,
                        `netTotal` REAL NOT NULL
                    )
                """.trimIndent())
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "amar_oshudher_khata.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration(false)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
