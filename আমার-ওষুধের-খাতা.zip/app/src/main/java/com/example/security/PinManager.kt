package com.example.security

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import java.util.UUID

class PinManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("app_security_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PIN_HASH = "sec_pin_hash"
        private const val KEY_PIN_SALT = "sec_pin_salt"
        private const val KEY_IS_SETUP_COMPLETE = "is_setup_complete"
        private const val KEY_FAILED_ATTEMPTS = "failed_pin_attempts"
        private const val KEY_LOCKOUT_UNTIL = "lockout_until_time"
        private const val KEY_RECOVERY_QUESTION = "security_recovery_question"
        private const val KEY_RECOVERY_ANSWER_HASH = "security_recovery_answer_hash"
        private const val MAX_FAILED_ATTEMPTS = 5
        private const val LOCKOUT_DURATION_MS = 30_000L // 30 seconds
    }

    fun isSetupComplete(): Boolean {
        return prefs.getBoolean(KEY_IS_SETUP_COMPLETE, false) && hasPin()
    }

    fun hasPin(): Boolean {
        return prefs.getString(KEY_PIN_HASH, null) != null
    }

    private fun hashWithSalt(pin: String, salt: String): String {
        val input = "$salt:$pin"
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun setPin(pin: String): Boolean {
        if (pin.length != 4 || !pin.all { it.isDigit() }) return false
        val salt = UUID.randomUUID().toString()
        val hash = hashWithSalt(pin, salt)
        prefs.edit()
            .putString(KEY_PIN_HASH, hash)
            .putString(KEY_PIN_SALT, salt)
            .putBoolean(KEY_IS_SETUP_COMPLETE, true)
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0L)
            .apply()
        return true
    }

    fun verifyPin(pin: String): Boolean {
        if (isLockedOut()) return false
        val savedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val savedSalt = prefs.getString(KEY_PIN_SALT, "") ?: ""
        val inputHash = hashWithSalt(pin, savedSalt)

        return if (savedHash == inputHash) {
            resetFailedAttempts()
            true
        } else {
            recordFailedAttempt()
            false
        }
    }

    fun isLockedOut(): Boolean {
        val lockoutUntil = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L)
        return System.currentTimeMillis() < lockoutUntil
    }

    fun getRemainingLockoutSeconds(): Int {
        val lockoutUntil = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L)
        val remainingMs = lockoutUntil - System.currentTimeMillis()
        return if (remainingMs > 0) (remainingMs / 1000).toInt() + 1 else 0
    }

    private fun recordFailedAttempt() {
        val currentAttempts = prefs.getInt(KEY_FAILED_ATTEMPTS, 0) + 1
        val editor = prefs.edit().putInt(KEY_FAILED_ATTEMPTS, currentAttempts)
        if (currentAttempts >= MAX_FAILED_ATTEMPTS) {
            editor.putLong(KEY_LOCKOUT_UNTIL, System.currentTimeMillis() + LOCKOUT_DURATION_MS)
        }
        editor.apply()
    }

    fun resetFailedAttempts() {
        prefs.edit()
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0L)
            .apply()
    }

    fun getFailedAttempts(): Int {
        return prefs.getInt(KEY_FAILED_ATTEMPTS, 0)
    }

    fun setRecoveryQuestion(question: String, answer: String) {
        val normalizedAnswer = answer.trim().lowercase()
        val hash = hashWithSalt(normalizedAnswer, "recovery_salt")
        prefs.edit()
            .putString(KEY_RECOVERY_QUESTION, question)
            .putString(KEY_RECOVERY_ANSWER_HASH, hash)
            .apply()
    }

    fun getRecoveryQuestion(): String {
        return prefs.getString(KEY_RECOVERY_QUESTION, "আপনার প্রিয় খাবার বা শৈশবের স্কুলের নাম কি?") ?: "আপনার প্রিয় খাবার বা শৈশবের স্কুলের নাম কি?"
    }

    fun verifyRecoveryAnswer(answer: String): Boolean {
        val savedHash = prefs.getString(KEY_RECOVERY_ANSWER_HASH, null) ?: return false
        val inputHash = hashWithSalt(answer.trim().lowercase(), "recovery_salt")
        val correct = savedHash == inputHash
        if (correct) {
            resetFailedAttempts()
        }
        return correct
    }
}
