package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Pharmacy Greens / Teals
val PharmacyTealDark = Color(0xFF004D40)
val PharmacyTealPrimary = Color(0xFF00695C)
val PharmacyTealLight = Color(0xFF80CBC4)
val PharmacyTealContainer = Color(0xFFE0F2F1)
val OnPharmacyTealContainer = Color(0xFF00201A)

val PharmacyEmerald = Color(0xFF1B5E20)
val PharmacyMint = Color(0xFF4CAF50)

// Warning / Overdue / Due colors
val DueRed = Color(0xFFC62828)
val DueRedContainer = Color(0xFFFFEBEE)
val DueRedLight = Color(0xFFEF5350)

// Payment / Collection colors
val PaidGreen = Color(0xFF2E7D32)
val PaidGreenContainer = Color(0xFFE8F5E9)

// Expiry colors
val ExpiryOrange = Color(0xFFE65100)
val ExpiryOrangeContainer = Color(0xFFFFF3E0)

// Neutral & surfaces
val NeutralDark = Color(0xFF1E293B)
val NeutralLight = Color(0xFFF8FAFC)
val SurfaceCard = Color(0xFFFFFFFF)
val BorderSubtle = Color(0xFFE2E8F0)
val TextMuted = Color(0xFF64748B)

// Dark theme specific
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceElevated = Color(0xFF334155)
