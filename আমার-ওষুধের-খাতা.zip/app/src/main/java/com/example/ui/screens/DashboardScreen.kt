package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FormatHelper
import com.example.ui.components.QuickActionButton
import com.example.ui.components.StatCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: AppViewModel) {
    val stats by viewModel.dashboardStats.collectAsState()
    val shopInfo by viewModel.shopInfo.collectAsState()
    val customers by viewModel.allCustomers.collectAsState()
    val medicines by viewModel.allMedicines.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }

    val filteredCustomers = remember(searchQuery, customers) {
        if (searchQuery.isBlank()) emptyList()
        else customers.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.phone.contains(searchQuery)
        }
    }

    val filteredMedicines = remember(searchQuery, medicines) {
        if (searchQuery.isBlank()) emptyList()
        else medicines.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.genericName.contains(searchQuery, ignoreCase = true) ||
                    it.company.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = shopInfo.shopName.ifBlank { "আমার ওষুধের খাতা" },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = FormatHelper.formatDate(System.currentTimeMillis()),
                            style = MaterialTheme.typography.bodySmall,
                            color = PharmacyTealLight
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.navigateTo(AppScreen.SETTINGS) }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "সেটিংস",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Quick Search Bar
            item {
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        isSearching = it.isNotBlank()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    placeholder = { Text("গ্রাহক বা ওষুধ খুঁজুন...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "সার্চ",
                            tint = PharmacyTealPrimary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = {
                                searchQuery = ""
                                isSearching = false
                            }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "পরিষ্কার")
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }

            // Search Results Popup / Inline List
            if (isSearching) {
                if (filteredCustomers.isNotEmpty()) {
                    item {
                        Text(
                            text = "গ্রাহক ফলাফল (${filteredCustomers.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = PharmacyTealPrimary
                        )
                    }
                    items(filteredCustomers.take(5)) { c ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    searchQuery = ""
                                    isSearching = false
                                    viewModel.selectCustomer(c.id)
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(12.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = c.name, fontWeight = FontWeight.Bold)
                                    Text(text = c.phone, style = MaterialTheme.typography.bodySmall)
                                }
                                Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null)
                            }
                        }
                    }
                }

                if (filteredMedicines.isNotEmpty()) {
                    item {
                        Text(
                            text = "ওষুধ ফলাফল (${filteredMedicines.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = PharmacyTealPrimary
                        )
                    }
                    items(filteredMedicines.take(5)) { m ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    searchQuery = ""
                                    isSearching = false
                                    viewModel.selectMedicine(m.id)
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(12.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = m.name, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${m.company} | স্টক: ${"%.0f".format(m.currentStock)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Text(
                                    text = FormatHelper.formatTaka(m.sellingPrice),
                                    fontWeight = FontWeight.Bold,
                                    color = PharmacyTealPrimary
                                )
                            }
                        }
                    }
                }

                if (filteredCustomers.isEmpty() && filteredMedicines.isEmpty()) {
                    item {
                        Text(
                            text = "কোন ফলাফল পাওয়া যায়নি",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                }
            }

            // Quick Actions Bar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "দ্রুত কার্যক্রম (Quick Actions)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = PharmacyTealPrimary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            QuickActionButton(
                                label = "নতুন বিক্রি",
                                icon = Icons.Default.PointOfSale,
                                backgroundColor = PharmacyTealContainer,
                                iconColor = PharmacyTealPrimary,
                                onClick = {
                                    viewModel.clearCart()
                                    viewModel.navigateTo(AppScreen.NEW_SALE)
                                },
                                modifier = Modifier.weight(1f)
                            )
                            QuickActionButton(
                                label = "ওষুধের চালান",
                                icon = Icons.Default.Description,
                                backgroundColor = Color(0xFFE8F5E9),
                                iconColor = PharmacyTealPrimary,
                                onClick = { viewModel.startNewChallan() },
                                modifier = Modifier.weight(1f)
                            )
                            QuickActionButton(
                                label = "টাকা জমা",
                                icon = Icons.Default.Payments,
                                backgroundColor = PaidGreenContainer,
                                iconColor = PaidGreen,
                                onClick = { viewModel.navigateTo(AppScreen.PAYMENT_ENTRY) },
                                modifier = Modifier.weight(1f)
                            )
                            QuickActionButton(
                                label = "নতুন গ্রাহক",
                                icon = Icons.Default.PersonAdd,
                                backgroundColor = Color(0xFFE1F5FE),
                                iconColor = Color(0xFF0288D1),
                                onClick = { viewModel.navigateTo(AppScreen.CUSTOMER_LIST) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            QuickActionButton(
                                label = "চালান ইতিহাস",
                                icon = Icons.Default.HistoryEdu,
                                backgroundColor = Color(0xFFFFF3E0),
                                iconColor = Color(0xFFE65100),
                                onClick = { viewModel.navigateTo(AppScreen.CHALLAN_LIST) },
                                modifier = Modifier.weight(1f)
                            )
                            QuickActionButton(
                                label = "স্টক ক্রয়",
                                icon = Icons.Default.AddShoppingCart,
                                backgroundColor = Color(0xFFF3E5F5),
                                iconColor = Color(0xFF7B1FA2),
                                onClick = { viewModel.navigateTo(AppScreen.STOCK_PURCHASE) },
                                modifier = Modifier.weight(1f)
                            )
                            QuickActionButton(
                                label = "ওষুধ ইনভেন্টরি",
                                icon = Icons.Default.Medication,
                                backgroundColor = Color(0xFFE8EAF6),
                                iconColor = Color(0xFF283593),
                                onClick = { viewModel.navigateTo(AppScreen.MEDICINE_LIST) },
                                modifier = Modifier.weight(1f)
                            )
                            QuickActionButton(
                                label = "হিসাব রিপোর্ট",
                                icon = Icons.Default.BarChart,
                                backgroundColor = Color(0xFFEDE7F6),
                                iconColor = Color(0xFF512DA8),
                                onClick = { viewModel.navigateTo(AppScreen.REPORTS) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            QuickActionButton(
                                label = "ওষুধ ফেরত",
                                icon = Icons.Default.AssignmentReturn,
                                backgroundColor = Color(0xFFFFEBEE),
                                iconColor = DueRed,
                                onClick = { viewModel.navigateTo(AppScreen.SALES_RETURN) },
                                modifier = Modifier.weight(1f)
                            )
                            QuickActionButton(
                                label = "বাকি খাতা",
                                icon = Icons.Default.MenuBook,
                                backgroundColor = Color(0xFFFFF8E1),
                                iconColor = Color(0xFFF57F17),
                                onClick = { viewModel.navigateTo(AppScreen.CUSTOMER_LIST) },
                                modifier = Modifier.weight(1f)
                            )
                            QuickActionButton(
                                label = "ব্যাকআপ / সেটিংস",
                                icon = Icons.Default.CloudSync,
                                backgroundColor = Color(0xFFE0F2F1),
                                iconColor = PharmacyTealPrimary,
                                onClick = { viewModel.navigateTo(AppScreen.SETTINGS) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Overdue Reminders Notice (if any)
            if (stats.dueRemindersCount > 0) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo(AppScreen.CUSTOMER_LIST) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DueRedContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = DueRed,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "আজকের বাকি তাগাদা (${stats.dueRemindersCount} জন গ্রাহক)",
                                    fontWeight = FontWeight.Bold,
                                    color = DueRed
                                )
                                Text(
                                    text = "সম্ভাব্য পরিশোধের তারিখ আজ বা অতিক্রম করেছে। তালিকা দেখতে ক্লিক করুন।",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DueRed.copy(alpha = 0.85f)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = DueRed
                            )
                        }
                    }
                }
            }

            // Today's Financial Overview Cards
            item {
                Text(
                    text = "আজকের হিসাব",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "আজকের বিক্রি",
                        value = FormatHelper.formatTaka(stats.todaySales),
                        subtitle = "নগদ + বাকি বিক্রি",
                        icon = Icons.Default.TrendingUp,
                        containerColor = PharmacyTealContainer,
                        contentColor = PharmacyTealPrimary,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(AppScreen.SALES_LIST) }
                    )
                    StatCard(
                        title = "আজকের আদায়",
                        value = FormatHelper.formatTaka(stats.todayCollection),
                        subtitle = "ক্যাশ ইন / জমা",
                        icon = Icons.Default.Savings,
                        containerColor = PaidGreenContainer,
                        contentColor = PaidGreen,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(AppScreen.REPORTS) }
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "আজকের নতুন বাকি",
                        value = FormatHelper.formatTaka(stats.todayNewDue),
                        subtitle = "আজকের চালানের বাকি",
                        icon = Icons.Default.AccountBalanceWallet,
                        containerColor = Color(0xFFFFF8E1),
                        contentColor = Color(0xFFF57F17),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(AppScreen.CUSTOMER_LIST) }
                    )
                    StatCard(
                        title = "মোট বকেয়া বাকি",
                        value = FormatHelper.formatTaka(stats.totalOutstandingDue),
                        subtitle = "সব গ্রাহকের বকেয়া",
                        icon = Icons.Default.Warning,
                        containerColor = DueRedContainer,
                        contentColor = DueRed,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(AppScreen.CUSTOMER_LIST) }
                    )
                }
            }

            // Inventory & Stock Overview
            item {
                Text(
                    text = "ওষুধ ও ইনভেন্টরি স্টক",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "মোট ওষুধ আইটেম",
                        value = "${stats.totalMedicineCount} টি",
                        subtitle = "মজুত স্টক: ${"%.0f".format(stats.totalStockQuantity)}",
                        icon = Icons.Default.Medication,
                        containerColor = Color(0xFFE8EAF6),
                        contentColor = Color(0xFF283593),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(AppScreen.MEDICINE_LIST) }
                    )
                    StatCard(
                        title = "মোট গ্রাহক",
                        value = "${stats.totalCustomerCount} জন",
                        subtitle = "বাকির খাতা তালিকা",
                        icon = Icons.Default.People,
                        containerColor = Color(0xFFE0F7FA),
                        contentColor = Color(0xFF006064),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(AppScreen.CUSTOMER_LIST) }
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "স্বল্প স্টক ওষুধ",
                        value = "${stats.lowStockCount} টি",
                        subtitle = "পুনরায় অর্ডার প্রয়োজন",
                        icon = Icons.Default.ProductionQuantityLimits,
                        containerColor = if (stats.lowStockCount > 0) Color(0xFFFFE0B2) else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (stats.lowStockCount > 0) ExpiryOrange else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(AppScreen.MEDICINE_LIST) }
                    )
                    StatCard(
                        title = "আসন্ন মেয়াদ / মেয়াদোত্তীর্ণ",
                        value = "${stats.expiredCount} টি",
                        subtitle = "৩০ দিনের মধ্যে মেয়াদ শেষ",
                        icon = Icons.Default.EventBusy,
                        containerColor = if (stats.expiredCount > 0) DueRedContainer else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (stats.expiredCount > 0) DueRed else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(AppScreen.MEDICINE_LIST) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
