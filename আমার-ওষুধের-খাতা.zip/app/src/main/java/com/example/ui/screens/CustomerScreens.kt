package com.example.ui.screens

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.widget.DatePicker
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.ui.components.FormatHelper
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerListScreen(viewModel: AppViewModel) {
    val customers by viewModel.allCustomers.collectAsState()
    val sales by viewModel.allSales.collectAsState()
    val payments by viewModel.allPayments.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val filteredCustomers = remember(searchQuery, customers) {
        if (searchQuery.isBlank()) customers
        else customers.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.phone.contains(searchQuery)
        }
    }

    // Helper map to quickly compute dues for list items
    val duesMap = remember(customers, sales, payments) {
        customers.associate { c ->
            val cSales = sales.filter { it.customerId == c.id }
            val cPayments = payments.filter { it.customerId == c.id }
            val due = (c.openingDue + cSales.sumOf { it.grandTotal }) -
                    (cSales.sumOf { it.paidAmount } + cPayments.sumOf { it.amount })
            c.id to due
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("গ্রাহক ও বাকির খাতা", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(imageVector = Icons.Default.PersonAdd, contentDescription = "নতুন গ্রাহক", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = PharmacyTealPrimary,
                contentColor = Color.White
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "নতুন গ্রাহক")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("নাম বা মোবাইল নম্বর দিয়ে খুঁজুন...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredCustomers.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("কোন গ্রাহক পাওয়া যায়নি", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filteredCustomers) { cust ->
                        val due = duesMap[cust.id] ?: 0.0
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectCustomer(cust.id) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(PharmacyTealPrimary.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = cust.name.take(1).uppercase(),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp,
                                            color = PharmacyTealPrimary
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(text = cust.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text(
                                            text = if (cust.phone.isNotBlank()) cust.phone else "মোবাইল নম্বর নেই",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (cust.expectedPaymentDate != null && due > 0) {
                                            Text(
                                                text = "তাগাদা: ${FormatHelper.formatDate(cust.expectedPaymentDate)}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = ExpiryOrange,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = FormatHelper.formatTaka(due),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = if (due > 0) DueRed else PaidGreen
                                    )
                                    Text(
                                        text = if (due > 0) "বাকি আছে" else "পরিশোধিত",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (due > 0) DueRed else PaidGreen
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        CustomerAddEditDialog(
            customer = null,
            onDismiss = { showAddDialog = false },
            onSave = { newCust ->
                scope.launch {
                    viewModel.repository.insertCustomer(newCust)
                    showAddDialog = false
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val customer by viewModel.selectedCustomer.collectAsState()
    val ledger by viewModel.selectedCustomerLedger.collectAsState()
    val summary by viewModel.selectedCustomerSummary.collectAsState()
    val shopInfo by viewModel.shopInfo.collectAsState()

    var showEditCustomerDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showExpectedDateDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(customer) {
        viewModel.refreshSelectedCustomer()
    }

    if (customer == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val cust = customer!!

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(cust.name, fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        // Generate Customer Ledger PDF
                        if (summary != null) {
                            val pdf = com.example.service.PdfGenerator.generateCustomerLedgerPdf(
                                context = context,
                                customer = cust,
                                ledger = ledger,
                                summary = summary!!,
                                shopInfo = shopInfo
                            )
                            viewModel.previewReceiptPdf.value = pdf
                            viewModel.previewReceiptTitle.value = "${cust.name} - খতিয়ান"
                            viewModel.navigateTo(AppScreen.RECEIPT_PREVIEW)
                        }
                    }) {
                        Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = "PDF খতিয়ান", tint = Color.White)
                    }
                    IconButton(onClick = { showEditCustomerDialog = true }) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "এডিট", tint = Color.White)
                    }
                    IconButton(onClick = { showDeleteConfirmDialog = true }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "মুছুন", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Customer Profile Header Card
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = cust.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                if (cust.phone.isNotBlank()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = cust.phone, style = MaterialTheme.typography.bodyMedium)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        IconButton(
                                            onClick = {
                                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${cust.phone}"))
                                                context.startActivity(intent)
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Phone, contentDescription = "কল দিন", tint = PaidGreen, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                                if (cust.address.isNotBlank()) {
                                    Text(text = "ঠিকানা: ${cust.address}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            // Current Due Badge
                            Column(horizontalAlignment = Alignment.End) {
                                Text("বর্তমান বাকি:", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = FormatHelper.formatTaka(summary?.currentDue ?: 0.0),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if ((summary?.currentDue ?: 0.0) > 0) DueRed else PaidGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(10.dp))

                        // Expected Payment Date Section
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "সম্ভাব্য পরিশোধের তারিখ:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = if (cust.expectedPaymentDate != null) FormatHelper.formatDate(cust.expectedPaymentDate) else "নির্ধারণ করা হয়নি",
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (cust.expectedPaymentDate != null) ExpiryOrange else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            TextButton(onClick = { showExpectedDateDialog = true }) {
                                Icon(imageVector = Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (cust.expectedPaymentDate == null) "তারিখ দিন" else "পরিবর্তন")
                            }
                        }
                    }
                }
            }

            // Quick Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.navigateTo(AppScreen.PAYMENT_ENTRY)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = PaidGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Payments, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("টাকা জমা")
                    }

                    Button(
                        onClick = {
                            viewModel.clearCart()
                            viewModel.saleCustomer.value = cust
                            viewModel.navigateTo(AppScreen.NEW_SALE)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("নতুন বিক্রি")
                    }
                }
            }

            // Summary Totals
            if (summary != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("মোট বিক্রি", style = MaterialTheme.typography.bodySmall)
                                Text(FormatHelper.formatTaka(summary!!.totalSalesAmount), fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("মোট জমা", style = MaterialTheme.typography.bodySmall)
                                Text(FormatHelper.formatTaka(summary!!.totalPaidAmount), fontWeight = FontWeight.Bold, color = PaidGreen)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("নিট বাকি", style = MaterialTheme.typography.bodySmall)
                                Text(FormatHelper.formatTaka(summary!!.currentDue), fontWeight = FontWeight.Bold, color = DueRed)
                            }
                        }
                    }
                }
            }

            // Ledger Entries Header
            item {
                Text(
                    text = "খতিয়ান বিবরণ (ক্রমানুসারে)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = PharmacyTealPrimary
                )
            }

            if (ledger.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("কোন পূর্ববর্তী লেনদেন পাওয়া যায়নি", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                items(ledger) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = item.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "${FormatHelper.formatDate(item.date)} | ${item.receiptNumber}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    if (item.debit > 0) {
                                        Text(
                                            text = "+${FormatHelper.formatTaka(item.debit)}",
                                            fontWeight = FontWeight.Bold,
                                            color = DueRed
                                        )
                                    }
                                    if (item.credit > 0) {
                                        Text(
                                            text = "-${FormatHelper.formatTaka(item.credit)}",
                                            fontWeight = FontWeight.Bold,
                                            color = PaidGreen
                                        )
                                    }
                                    Text(
                                        text = "ব্যালেন্স: ${FormatHelper.formatTaka(item.balance)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Edit Customer Dialog
    if (showEditCustomerDialog) {
        CustomerAddEditDialog(
            customer = cust,
            onDismiss = { showEditCustomerDialog = false },
            onSave = { updated ->
                scope.launch {
                    viewModel.repository.updateCustomer(updated)
                    viewModel.refreshSelectedCustomer()
                    showEditCustomerDialog = false
                }
            }
        )
    }

    // Delete Customer Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("গ্রাহক ডিলিট নিশ্চিত করুন") },
            text = {
                Text("আপনি কি নিশ্চিতভাবে গ্রাহক '${cust.name}' কে খাতা থেকে মুছে ফেলতে চান? গ্রাহকের সমস্ত খতিয়ান ও রেকর্ড মুছে যাবে।")
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            viewModel.repository.deleteCustomer(cust)
                            showDeleteConfirmDialog = false
                            viewModel.navigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DueRed)
                ) {
                    Text("মুছে ফেলুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Expected Date Dialog
    if (showExpectedDateDialog) {
        val cal = Calendar.getInstance().apply {
            if (cust.expectedPaymentDate != null) timeInMillis = cust.expectedPaymentDate
        }
        DatePickerDialog(
            context,
            { _: DatePicker, year: Int, month: Int, day: Int ->
                val newCal = Calendar.getInstance().apply { set(year, month, day) }
                scope.launch {
                    viewModel.repository.updateExpectedPaymentDate(cust.id, newCal.timeInMillis, "")
                    viewModel.refreshSelectedCustomer()
                }
                showExpectedDateDialog = false
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).apply {
            setOnCancelListener { showExpectedDateDialog = false }
        }.show()
    }
}

@Composable
fun CustomerAddEditDialog(
    customer: Customer?,
    onDismiss: () -> Unit,
    onSave: (Customer) -> Unit
) {
    var name by remember { mutableStateOf(customer?.name ?: "") }
    var phone by remember { mutableStateOf(customer?.phone ?: "") }
    var address by remember { mutableStateOf(customer?.address ?: "") }
    var openingDueText by remember { mutableStateOf(if (customer != null && customer.openingDue > 0) customer.openingDue.toString() else "") }
    var note by remember { mutableStateOf(customer?.note ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (customer == null) "নতুন গ্রাহক যুক্ত করুন" else "গ্রাহক তথ্য এডিট") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("গ্রাহকের নাম *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("মোবাইল নম্বর") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("ঠিকানা") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (customer == null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = openingDueText,
                        onValueChange = { openingDueText = it },
                        label = { Text("পূর্বের বাকি (Opening Due)") },
                        placeholder = { Text("0.0") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("মন্তব্য (ঐচ্ছিক)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = error ?: "", color = DueRed, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        error = "গ্রাহকের নাম অবশ্যই দিতে হবে"
                    } else {
                        val openingDue = openingDueText.toDoubleOrNull() ?: 0.0
                        val toSave = customer?.copy(
                            name = name,
                            phone = phone,
                            address = address,
                            note = note
                        ) ?: Customer(
                            name = name,
                            phone = phone,
                            address = address,
                            openingDue = openingDue,
                            note = note
                        )
                        onSave(toSave)
                    }
                }
            ) {
                Text("সংরক্ষণ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
