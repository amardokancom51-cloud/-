package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.PinDots
import com.example.ui.components.PinKeypad
import com.example.ui.theme.DueRed
import com.example.ui.theme.PharmacyTealPrimary
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.delay

@Composable
fun PinLockScreen(viewModel: AppViewModel) {
    val enteredPin by viewModel.enteredPin.collectAsState()
    val pinError by viewModel.pinError.collectAsState()
    val isLockedOut by viewModel.isLockedOut.collectAsState()
    val lockoutSeconds by viewModel.lockoutSeconds.collectAsState()
    val shopInfo by viewModel.shopInfo.collectAsState()

    var showRecoveryDialog by remember { mutableStateOf(false) }
    var recoveryAnswer by remember { mutableStateOf("") }
    var recoveryError by remember { mutableStateOf<String?>(null) }

    // Lockout countdown timer
    LaunchedEffect(isLockedOut) {
        if (isLockedOut) {
            while (viewModel.pinManager.isLockedOut()) {
                viewModel.lockoutSeconds.value = viewModel.pinManager.getRemainingLockoutSeconds()
                delay(1000)
            }
            viewModel.isLockedOut.value = false
            viewModel.pinError.value = null
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(PharmacyTealPrimary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_app_pharmacy_logo),
                        contentDescription = "লোগো",
                        modifier = Modifier.size(54.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = shopInfo.shopName.ifBlank { "আমার ওষুধের খাতা" },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = PharmacyTealPrimary,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "ফার্মেসি ও বাকি খাতা সুরক্ষা",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "৪ ডিজিটের গোপন পিন লিখুন",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                PinDots(pinLength = enteredPin.length)

                if (pinError != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = pinError ?: "",
                        color = DueRed,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Keypad
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                PinKeypad(
                    onDigitClick = { digit -> viewModel.onPinDigit(digit) },
                    onBackspace = { viewModel.onPinBackspace() }
                )

                Spacer(modifier = Modifier.height(16.dp))

                TextButton(
                    onClick = {
                        recoveryAnswer = ""
                        recoveryError = null
                        showRecoveryDialog = true
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("পিন ভুলে গেছেন? পিন রিকভার করুন")
                }
            }
        }
    }

    if (showRecoveryDialog) {
        val question = viewModel.pinManager.getRecoveryQuestion()
        AlertDialog(
            onDismissRequest = { showRecoveryDialog = false },
            title = { Text("পিন পুনরুদ্ধার (Security Recovery)") },
            text = {
                Column {
                    Text(
                        text = "নিরাপত্তা প্রশ্ন:\n$question",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = recoveryAnswer,
                        onValueChange = { recoveryAnswer = it },
                        label = { Text("আপনার উত্তর") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (recoveryError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = recoveryError ?: "",
                            color = DueRed,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (viewModel.unlockWithRecovery(recoveryAnswer)) {
                            showRecoveryDialog = false
                        } else {
                            recoveryError = "ভুল উত্তর! সঠিক উত্তর দিয়ে চেষ্টা করুন।"
                        }
                    }
                ) {
                    Text("আনলক করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRecoveryDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}
