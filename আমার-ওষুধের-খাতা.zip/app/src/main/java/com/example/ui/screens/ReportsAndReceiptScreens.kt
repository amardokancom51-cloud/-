package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.service.PdfGenerator
import com.example.ui.components.FormatHelper
import com.example.ui.components.StatCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AppViewModel
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val sales by viewModel.allSales.collectAsState()
    val payments by viewModel.allPayments.collectAsState()
    val customers by viewModel.allCustomers.collectAsState()
    val medicines by viewModel.allMedicines.collectAsState()
    val shopInfo by viewModel.shopInfo.collectAsState()

    var selectedRange by remember { mutableStateOf(0) } // 0: Today, 1: 7 Days, 2: This Month, 3: All

    val filteredSales = remember(selectedRange, sales) {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        val startOfToday = cal.timeInMillis

        when (selectedRange) {
            0 -> sales.filter { it.saleDate >= startOfToday }
            1 -> {
                val sevenDaysAgo = now - (7L * 24 * 3600 * 1000)
                sales.filter { it.saleDate >= sevenDaysAgo }
            }
            2 -> {
                cal.set(Calendar.DAY_OF_MONTH, 1)
                val startOfMonth = cal.timeInMillis
                sales.filter { it.saleDate >= startOfMonth }
            }
            else -> sales
        }
    }

    val totalSalesAmount = filteredSales.sumOf { it.grandTotal }
    val totalDirectSalesPaid = filteredSales.sumOf { it.paidAmount }
    val totalSalesDue = filteredSales.sumOf { it.dueAmount }

    // Dues per customer
    val dueCustomers = remember(customers, sales, payments) {
        customers.mapNotNull { c ->
            val cSales = sales.filter { it.customerId == c.id }
            val cPayments = payments.filter { it.customerId == c.id }
            val due = (c.openingDue + cSales.sumOf { it.grandTotal }) -
                    (cSales.sumOf { it.paidAmount } + cPayments.sumOf { it.amount })
            if (due > 0) c to due else null
        }
    }

    val totalCustomerDue = dueCustomers.sumOf { it.second }
    val totalStockValue = medicines.sumOf { it.currentStock * it.purchasePrice }
    val totalRetailValue = medicines.sumOf { it.currentStock * it.sellingPrice }
    val estimatedStockProfit = (totalRetailValue - totalStockValue).coerceAtLeast(0.0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("রিপোর্ট ও আর্থিক বিশ্লেষণ", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Range Filter Chips
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedRange == 0,
                        onClick = { selectedRange = 0 },
                        label = { Text("আজকে") }
                    )
                    FilterChip(
                        selected = selectedRange == 1,
                        onClick = { selectedRange = 1 },
                        label = { Text("গত ৭ দিন") }
                    )
                    FilterChip(
                        selected = selectedRange == 2,
                        onClick = { selectedRange = 2 },
                        label = { Text("এই মাস") }
                    )
                    FilterChip(
                        selected = selectedRange == 3,
                        onClick = { selectedRange = 3 },
                        label = { Text("সর্বমোট") }
                    )
                }
            }

            // Sales Summary
            item {
                Text("বিক্রি ও আদায় সারসংক্ষেপ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "মোট বিক্রি",
                        value = FormatHelper.formatTaka(totalSalesAmount),
                        subtitle = "${filteredSales.size} টি চালান",
                        icon = Icons.Default.TrendingUp,
                        containerColor = PharmacyTealContainer,
                        contentColor = PharmacyTealPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "নগদ আদায়",
                        value = FormatHelper.formatTaka(totalDirectSalesPaid),
                        subtitle = "নগদ বিক্রয় ক্যাশ",
                        icon = Icons.Default.CheckCircle,
                        containerColor = PaidGreenContainer,
                        contentColor = PaidGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "চালানের বাকি",
                        value = FormatHelper.formatTaka(totalSalesDue),
                        subtitle = "নির্বাচিত সময়ের",
                        icon = Icons.Default.HourglassTop,
                        containerColor = Color(0xFFFFF8E1),
                        contentColor = Color(0xFFF57F17),
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "সর্বমোট গ্রাহক বকেয়া",
                        value = FormatHelper.formatTaka(totalCustomerDue),
                        subtitle = "${dueCustomers.size} জন গ্রাহক",
                        icon = Icons.Default.Warning,
                        containerColor = DueRedContainer,
                        contentColor = DueRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Inventory Valuation
            item {
                Text("স্টক ভ্যালুয়েশন ও সম্ভাব্য মুনাফা", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("মোট মজুদ ওষুধ:")
                            Text("${medicines.size} টি আইটেম", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ক্রয়মূল্যে মোট স্টক ভ্যালু:")
                            Text(FormatHelper.formatTaka(totalStockValue), fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("খুচরা বিক্রয়মূল্যে মোট ভ্যালু:")
                            Text(FormatHelper.formatTaka(totalRetailValue), fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("সম্ভাব্য মোট গ্রস লাভ:")
                            Text(FormatHelper.formatTaka(estimatedStockProfit), fontWeight = FontWeight.Bold, color = PaidGreen)
                        }
                    }
                }
            }

            // PDF Export Actions
            item {
                Text("পিডিএফ রিপোর্ট তৈরি ও ডাউনলোড", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val pdf = PdfGenerator.generateStockReportPdf(
                                context = context,
                                medicines = medicines,
                                shopInfo = shopInfo,
                                title = "ফার্মেসি স্টক ভ্যালুয়েশন রিপোর্ট"
                            )
                            viewModel.previewReceiptPdf.value = pdf
                            viewModel.previewReceiptTitle.value = "স্টক রিপোর্ট PDF"
                            viewModel.navigateTo(AppScreen.RECEIPT_PREVIEW)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("স্টক PDF")
                    }

                    Button(
                        onClick = {
                            // Low stock report
                            val lowStockList = medicines.filter { it.currentStock <= it.minStockLevel }
                            val pdf = PdfGenerator.generateStockReportPdf(
                                context = context,
                                medicines = lowStockList,
                                shopInfo = shopInfo,
                                title = "স্বল্প স্টক ও রি-অর্ডার রিপোর্ট"
                            )
                            viewModel.previewReceiptPdf.value = pdf
                            viewModel.previewReceiptTitle.value = "স্বল্প স্টক রিপোর্ট PDF"
                            viewModel.navigateTo(AppScreen.RECEIPT_PREVIEW)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.LowPriority, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("স্বল্প স্টক PDF")
                    }
                }
            }

            // Due Customers List Header
            item {
                Text(
                    text = "বকেয়া বাকি গ্রাহক তালিকা (${dueCustomers.size} জন)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DueRed
                )
            }

            items(dueCustomers) { (cust, due) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectCustomer(cust.id) },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(cust.name, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (cust.phone.isNotBlank()) cust.phone else "মোবাইল নেই",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = FormatHelper.formatTaka(due),
                            fontWeight = FontWeight.Bold,
                            color = DueRed
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiptPreviewScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val pdfFile by viewModel.previewReceiptPdf.collectAsState()
    val title by viewModel.previewReceiptTitle.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(AppScreen.DASHBOARD) }) {
                        Icon(imageVector = Icons.Default.Home, contentDescription = "হোম", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(PharmacyTealContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = PharmacyTealPrimary,
                    modifier = Modifier.size(54.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "রসিদ ও চালান প্রস্তুত!",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = PharmacyTealPrimary
            )

            Text(
                text = if (pdfFile != null) "ফাইল: ${pdfFile!!.name}" else "পিডিএফ প্রস্তুতকৃত",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Action Buttons
            Button(
                onClick = {
                    if (pdfFile != null) {
                        PdfGenerator.sharePdf(context, pdfFile!!, "রসিদ পাঠান")
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary)
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("শেয়ার করুন (WhatsApp / মেসেজ)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = {
                    if (pdfFile != null) {
                        // Open PDF viewer
                        val uri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            pdfFile!!
                        )
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, "application/pdf")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(intent)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Visibility, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("রসিদ দেখুন", fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = {
                    if (pdfFile != null) {
                        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                        if (printManager != null) {
                            val adapter = object : android.print.PrintDocumentAdapter() {
                                override fun onLayout(
                                    oldAttributes: PrintAttributes?,
                                    newAttributes: PrintAttributes?,
                                    cancellationSignal: android.os.CancellationSignal?,
                                    callback: LayoutResultCallback?,
                                    extras: android.os.Bundle?
                                ) {
                                    val pdi = android.print.PrintDocumentInfo.Builder(pdfFile!!.name)
                                        .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                                        .build()
                                    callback?.onLayoutFinished(pdi, true)
                                }

                                override fun onWrite(
                                    pages: Array<out android.print.PageRange>?,
                                    destination: android.os.ParcelFileDescriptor?,
                                    cancellationSignal: android.os.CancellationSignal?,
                                    callback: WriteResultCallback?
                                ) {
                                    try {
                                        FileInputStream(pdfFile).use { input ->
                                            FileOutputStream(destination?.fileDescriptor).use { output ->
                                                input.copyTo(output)
                                            }
                                        }
                                        callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                                    } catch (e: Exception) {
                                        callback?.onWriteFailed(e.message)
                                    }
                                }
                            }
                            printManager.print("Receipt_${pdfFile!!.name}", adapter, null)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Print, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("প্রিন্ট করুন (Print)", fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            TextButton(onClick = { viewModel.navigateTo(AppScreen.DASHBOARD) }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("হোম ড্যাশবোর্ডে ফিরে যান")
            }
        }
    }
}
