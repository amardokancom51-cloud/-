package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.DatePicker
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Medicine
import com.example.ui.components.FormatHelper
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicineListScreen(viewModel: AppViewModel) {
    val medicines by viewModel.allMedicines.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(0) } // 0: All, 1: Low Stock, 2: Expiring
    var showAddDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val filteredMedicines = remember(searchQuery, medicines, selectedFilter) {
        val base = when (selectedFilter) {
            1 -> medicines.filter { it.currentStock <= it.minStockLevel }
            2 -> {
                val thirtyDaysFromNow = System.currentTimeMillis() + (30L * 24 * 3600 * 1000)
                medicines.filter { it.expiryDate in 1..thirtyDaysFromNow }
            }
            else -> medicines
        }

        if (searchQuery.isBlank()) base
        else base.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.genericName.contains(searchQuery, ignoreCase = true) ||
                    it.company.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ওষুধ ইনভেন্টরি ও স্টক", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "নতুন ওষুধ", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = PharmacyTealPrimary,
                contentColor = Color.White
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "নতুন ওষুধ যোগ")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("নাম, কোম্পানি বা জেনেরিক দিয়ে খুঁজুন...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == 0,
                    onClick = { selectedFilter = 0 },
                    label = { Text("সকল (${medicines.size})") }
                )
                val lowCount = medicines.count { it.currentStock <= it.minStockLevel }
                FilterChip(
                    selected = selectedFilter == 1,
                    onClick = { selectedFilter = 1 },
                    label = { Text("স্বল্প স্টক ($lowCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFFFE0B2),
                        selectedLabelColor = ExpiryOrange
                    )
                )
                val thirtyDays = System.currentTimeMillis() + (30L * 24 * 3600 * 1000)
                val expCount = medicines.count { it.expiryDate in 1..thirtyDays }
                FilterChip(
                    selected = selectedFilter == 2,
                    onClick = { selectedFilter = 2 },
                    label = { Text("মেয়াদ শেষ/আসন্ন ($expCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = DueRedContainer,
                        selectedLabelColor = DueRed
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredMedicines.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("কোন ওষুধ পাওয়া যায়নি", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filteredMedicines) { med ->
                        val isLowStock = med.currentStock <= med.minStockLevel
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectMedicine(med.id) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isLowStock) Color(0xFFFFEBEE) else PharmacyTealContainer
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Medication,
                                            contentDescription = null,
                                            tint = if (isLowStock) DueRed else PharmacyTealPrimary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(text = med.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            if (med.strength.isNotBlank()) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(text = "(${med.strength})", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                        Text(
                                            text = if (med.genericName.isNotBlank()) med.genericName else med.company,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (med.company.isNotBlank() && med.genericName.isNotBlank()) {
                                            Text(
                                                text = med.company,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = PharmacyTealPrimary
                                            )
                                        }
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "স্টক: ${"%.0f".format(med.currentStock)} ${med.unit}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (isLowStock) DueRed else PharmacyTealPrimary
                                    )
                                    Text(
                                        text = "বিক্রয়: ${FormatHelper.formatTaka(med.sellingPrice)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    if (med.purchasePrice > 0) {
                                        Text(
                                            text = "ক্রয়: ${FormatHelper.formatTaka(med.purchasePrice)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        MedicineAddEditDialog(
            medicine = null,
            onDismiss = { showAddDialog = false },
            onSave = { newMed ->
                scope.launch {
                    viewModel.repository.insertMedicine(newMed)
                    showAddDialog = false
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicineDetailScreen(viewModel: AppViewModel) {
    val medicine by viewModel.selectedMedicine.collectAsState()
    val transactions by viewModel.selectedMedicineTransactions.collectAsState()

    var showEditDialog by remember { mutableStateOf(false) }
    var showAdjustStockDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (medicine == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val med = medicine!!

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(med.name, fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { showEditDialog = true }) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "এডিট", tint = Color.White)
                    }
                    IconButton(onClick = { showDeleteConfirmDialog = true }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "মুছুন", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Main Details Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = med.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                if (med.genericName.isNotBlank()) {
                                    Text(text = "জেনেরিক: ${med.genericName}", style = MaterialTheme.typography.bodyMedium)
                                }
                                if (med.company.isNotBlank()) {
                                    Text(text = "কোম্পানি: ${med.company}", style = MaterialTheme.typography.bodyMedium, color = PharmacyTealPrimary)
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("বর্তমান স্টক", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "${"%.0f".format(med.currentStock)} ${med.unit}",
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (med.currentStock <= med.minStockLevel) DueRed else PaidGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("ক্রয়দর", style = MaterialTheme.typography.bodySmall)
                                Text(FormatHelper.formatTaka(med.purchasePrice), fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("বিক্রয়দর", style = MaterialTheme.typography.bodySmall)
                                Text(FormatHelper.formatTaka(med.sellingPrice), fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                            }
                            val profit = med.sellingPrice - med.purchasePrice
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("মুনাফা/লাভ", style = MaterialTheme.typography.bodySmall)
                                Text(FormatHelper.formatTaka(profit), fontWeight = FontWeight.Bold, color = PaidGreen)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(12.dp))

                        if (med.batchNumber.isNotBlank()) {
                            Text("ব্যাচ নম্বর: ${med.batchNumber}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (med.expiryDate > 0) {
                            Text("মেয়াদোত্তীর্ণ তারিখ: ${FormatHelper.formatDate(med.expiryDate)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        }
                        if (med.supplierName.isNotBlank()) {
                            Text("সরবরাহকারী: ${med.supplierName}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text("নূন্যতম স্টক সতর্কতা লেভেল: ${"%.0f".format(med.minStockLevel)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // Quick Stock Adjustment Button
            item {
                Button(
                    onClick = { showAdjustStockDialog = true },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary)
                ) {
                    Icon(imageVector = Icons.Default.Tune, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("স্টক সমন্বয় / বৃদ্ধি / হ্রাস করুন")
                }
            }

            // Stock Movement History Header
            item {
                Text(
                    text = "স্টক লেনদেনের ইতিহাস",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = PharmacyTealPrimary
                )
            }

            if (transactions.isEmpty()) {
                item {
                    Text("কোন স্টক ইতিহাস পাওয়া যায়নি", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(transactions) { t ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = when (t.type) {
                                        "SALE" -> "বিক্রির মাধ্যমে স্টক হ্রাস"
                                        "PURCHASE" -> "ক্রয়ের মাধ্যমে স্টক বৃদ্ধি"
                                        "RETURN" -> "ফেরত আসার কারণে স্টক বৃদ্ধি"
                                        else -> "ম্যানুয়াল স্টক সমন্বয়"
                                    },
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${FormatHelper.formatDateTime(t.date)} | ${t.note}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = if (t.quantityChange > 0) "+${"%.0f".format(t.quantityChange)}" else "${"%.0f".format(t.quantityChange)}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (t.quantityChange > 0) PaidGreen else DueRed
                                )
                                Text("স্টক: ${"%.0f".format(t.newStock)}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdjustStockDialog) {
        var newStockText by remember { mutableStateOf(med.currentStock.toString()) }
        var reason by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAdjustStockDialog = false },
            title = { Text("স্টক সমন্বয়") },
            text = {
                Column {
                    Text("বর্তমান স্টক: ${"%.0f".format(med.currentStock)}")
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newStockText,
                        onValueChange = { newStockText = it },
                        label = { Text("নতুন সঠিক স্টক লিখুন") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("সমন্বয়ের কারণ") },
                        placeholder = { Text("যেমন: গণনা যাচাই বা নষ্ট হওয়া") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newStock = newStockText.toDoubleOrNull()
                        if (newStock != null && newStock >= 0) {
                            scope.launch {
                                viewModel.repository.adjustStock(med.id, newStock, reason)
                                showAdjustStockDialog = false
                            }
                        }
                    }
                ) {
                    Text("হালনাগাদ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdjustStockDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    if (showEditDialog) {
        MedicineAddEditDialog(
            medicine = med,
            onDismiss = { showEditDialog = false },
            onSave = { updated ->
                scope.launch {
                    viewModel.repository.updateMedicine(updated)
                    showEditDialog = false
                }
            }
        )
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("ওষুধ ডিলিট নিশ্চিত করুন") },
            text = { Text("আপনি কি নিশ্চিতভাবে '${med.name}' ইনভেন্টরি থেকে মুছে ফেলতে চান?") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            viewModel.repository.deleteMedicine(med.id)
                            showDeleteConfirmDialog = false
                            viewModel.navigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DueRed)
                ) {
                    Text("মুছে ফেলুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
fun MedicineAddEditDialog(
    medicine: Medicine?,
    onDismiss: () -> Unit,
    onSave: (Medicine) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(medicine?.name ?: "") }
    var genericName by remember { mutableStateOf(medicine?.genericName ?: "") }
    var company by remember { mutableStateOf(medicine?.company ?: "") }
    var category by remember { mutableStateOf(medicine?.category ?: "ট্যাবলেট") }
    var strength by remember { mutableStateOf(medicine?.strength ?: "") }
    var unit by remember { mutableStateOf(medicine?.unit ?: "পাতা/পিস") }
    var purchasePriceText by remember { mutableStateOf(if (medicine != null && medicine.purchasePrice > 0) medicine.purchasePrice.toString() else "") }
    var sellingPriceText by remember { mutableStateOf(if (medicine != null && medicine.sellingPrice > 0) medicine.sellingPrice.toString() else "") }
    var stockText by remember { mutableStateOf(if (medicine != null) medicine.currentStock.toString() else "0") }
    var minStockText by remember { mutableStateOf(if (medicine != null) medicine.minStockLevel.toString() else "10") }
    var batchNumber by remember { mutableStateOf(medicine?.batchNumber ?: "") }
    var expiryDate by remember { mutableStateOf(medicine?.expiryDate ?: 0L) }
    var supplierName by remember { mutableStateOf(medicine?.supplierName ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (medicine == null) "নতুন ওষুধ যোগ করুন" else "ওষুধের তথ্য এডিট") },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("ওষুধের নাম *") },
                        placeholder = { Text("যেমন: Napa Extra") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = genericName,
                        onValueChange = { genericName = it },
                        label = { Text("জেনেরিক নাম") },
                        placeholder = { Text("যেমন: Paracetamol + Caffeine") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = company,
                        onValueChange = { company = it },
                        label = { Text("ফার্মাসিউটিক্যাল কোম্পানি") },
                        placeholder = { Text("যেমন: Beximco Pharma") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = strength,
                            onValueChange = { strength = it },
                            label = { Text("মাত্রা (Strength)") },
                            placeholder = { Text("500mg") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = { Text("ক্যাটাগরি") },
                            placeholder = { Text("ট্যাবলেট / সিরাপ") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = purchasePriceText,
                            onValueChange = { purchasePriceText = it },
                            label = { Text("ক্রয়দর *") },
                            placeholder = { Text("0.0") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = sellingPriceText,
                            onValueChange = { sellingPriceText = it },
                            label = { Text("বিক্রয়দর *") },
                            placeholder = { Text("0.0") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = stockText,
                            onValueChange = { stockText = it },
                            label = { Text("বর্তমান স্টক") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = minStockText,
                            onValueChange = { minStockText = it },
                            label = { Text("সতর্কতা লেভেল") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = batchNumber,
                        onValueChange = { batchNumber = it },
                        label = { Text("ব্যাচ নম্বর (Batch)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (expiryDate > 0) "মেয়াদ: ${FormatHelper.formatDate(expiryDate)}" else "মেয়াদ নির্বাচন করুন",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        TextButton(onClick = {
                            val cal = Calendar.getInstance().apply {
                                if (expiryDate > 0) timeInMillis = expiryDate
                            }
                            DatePickerDialog(
                                context,
                                { _: DatePicker, y: Int, m: Int, d: Int ->
                                    val c = Calendar.getInstance().apply { set(y, m, d) }
                                    expiryDate = c.timeInMillis
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }) {
                            Text("তারিখ দিন")
                        }
                    }
                    if (error != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = error ?: "", color = DueRed, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        error = "ওষুধের নাম দিতে হবে"
                    } else {
                        val buy = purchasePriceText.toDoubleOrNull() ?: 0.0
                        val sell = sellingPriceText.toDoubleOrNull() ?: 0.0
                        val stock = stockText.toDoubleOrNull() ?: 0.0
                        val minStock = minStockText.toDoubleOrNull() ?: 10.0

                        val toSave = medicine?.copy(
                            name = name,
                            genericName = genericName,
                            company = company,
                            category = category,
                            strength = strength,
                            unit = unit,
                            purchasePrice = buy,
                            sellingPrice = sell,
                            currentStock = stock,
                            minStockLevel = minStock,
                            batchNumber = batchNumber,
                            expiryDate = expiryDate,
                            supplierName = supplierName
                        ) ?: Medicine(
                            name = name,
                            genericName = genericName,
                            company = company,
                            category = category,
                            strength = strength,
                            unit = unit,
                            purchasePrice = buy,
                            sellingPrice = sell,
                            currentStock = stock,
                            minStockLevel = minStock,
                            batchNumber = batchNumber,
                            expiryDate = expiryDate,
                            supplierName = supplierName
                        )
                        onSave(toSave)
                    }
                }
            ) {
                Text("সংরক্ষণ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
