package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.DatePicker
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.Medicine
import com.example.data.model.Sale
import com.example.ui.components.FormatHelper
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewSaleScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val cartItems by viewModel.cartItems.collectAsState()
    val subtotal by viewModel.cartSubtotal.collectAsState()
    val discount by viewModel.saleDiscount.collectAsState()
    val grandTotal by viewModel.cartGrandTotal.collectAsState()
    val paidAmount by viewModel.salePaidAmount.collectAsState()
    val dueAmount by viewModel.cartDueAmount.collectAsState()
    val selectedCustomer by viewModel.saleCustomer.collectAsState()
    val saleDate by viewModel.saleDate.collectAsState()
    val saleNote by viewModel.saleNote.collectAsState()

    val allMedicines by viewModel.allMedicines.collectAsState()
    val allCustomers by viewModel.allCustomers.collectAsState()

    var showMedicinePicker by remember { mutableStateOf(false) }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var showQuickAddCustomer by remember { mutableStateOf(false) }

    var discountText by remember { mutableStateOf(if (discount > 0) discount.toString() else "") }
    var paidText by remember { mutableStateOf(if (paidAmount > 0) paidAmount.toString() else "") }

    var previousDue by remember { mutableStateOf(0.0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(selectedCustomer) {
        val c = selectedCustomer
        if (c != null) {
            previousDue = viewModel.repository.calculateCustomerDue(c.id)
        } else {
            previousDue = 0.0
        }
    }

    // Keep paid text synced when full paid is clicked
    fun setFullPaid() {
        paidText = grandTotal.toString()
        viewModel.salePaidAmount.value = grandTotal
    }

    fun setFullDue() {
        paidText = "0"
        viewModel.salePaidAmount.value = 0.0
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("নতুন বিক্রি চালান", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "পেছনে",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    if (cartItems.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearCart() }) {
                            Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "পরিষ্কার", tint = Color.White)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Customer Selection Card
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "গ্রাহক তথ্য",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = PharmacyTealPrimary
                            )
                            TextButton(onClick = { showCustomerPicker = true }) {
                                Icon(imageVector = Icons.Default.PersonSearch, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("গ্রাহক নির্বাচন")
                            }
                        }

                        if (selectedCustomer != null) {
                            val c = selectedCustomer!!
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = c.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text(text = c.phone, style = MaterialTheme.typography.bodySmall)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "পূর্বের বাকি:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = FormatHelper.formatTaka(previousDue),
                                        fontWeight = FontWeight.Bold,
                                        color = if (previousDue > 0) DueRed else PaidGreen
                                    )
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "নগদ ক্রেতা (নামবিহীন)", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedButton(
                                    onClick = { showQuickAddCustomer = true },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("নতুন গ্রাহক")
                                }
                            }
                        }
                    }
                }
            }

            // Sale Date & Time Selector
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "চালানের তারিখ: ${FormatHelper.formatDate(saleDate)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    TextButton(onClick = {
                        val cal = Calendar.getInstance().apply { timeInMillis = saleDate }
                        DatePickerDialog(
                            context,
                            { _: DatePicker, year: Int, month: Int, day: Int ->
                                val newCal = Calendar.getInstance().apply {
                                    set(year, month, day)
                                }
                                viewModel.saleDate.value = newCal.timeInMillis
                            },
                            cal.get(Calendar.YEAR),
                            cal.get(Calendar.MONTH),
                            cal.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }) {
                        Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("তারিখ পরিবর্তন")
                    }
                }
            }

            // Medicine Items Header & Add Button
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ওষুধের তালিকা (${cartItems.size} টি আইটেম)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = PharmacyTealPrimary
                    )
                    Button(
                        onClick = { showMedicinePicker = true },
                        colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ওষুধ যোগ করুন")
                    }
                }
            }

            // Cart Items List
            if (cartItems.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Medication,
                                contentDescription = null,
                                modifier = Modifier.size(40.dp),
                                tint = PharmacyTealPrimary.copy(alpha = 0.6f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "কোন ওষুধ যোগ করা হয়নি",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "'ওষুধ যোগ করুন' বাটনে চাপ দিয়ে ওষুধ নির্বাচন করুন",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            } else {
                items(cartItems) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.medicine.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${item.medicine.company} | মজুত: ${"%.0f".format(item.medicine.currentStock)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.updateCartItemQuantity(item.medicine.id, 0.0) }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "বাদ দিন",
                                        tint = DueRed
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Quantity and Price adjustment
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Stepper for Quantity
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { viewModel.updateCartItemQuantity(item.medicine.id, item.quantity - 1.0) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                    ) {
                                        Icon(imageVector = Icons.Default.Remove, contentDescription = "কমান", modifier = Modifier.size(16.dp))
                                    }

                                    Text(
                                        text = " ${"%.0f".format(item.quantity)} ",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    )

                                    IconButton(
                                        onClick = { viewModel.updateCartItemQuantity(item.medicine.id, item.quantity + 1.0) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                    ) {
                                        Icon(imageVector = Icons.Default.Add, contentDescription = "বাড়ান", modifier = Modifier.size(16.dp))
                                    }
                                }

                                // Unit Price and Item Total
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "দর: ${FormatHelper.formatTaka(item.unitPrice)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "মোট: ${FormatHelper.formatTaka(item.totalPrice)}",
                                        fontWeight = FontWeight.Bold,
                                        color = PharmacyTealPrimary,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Financial Calculation Breakdown
            if (cartItems.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("মোট পণ্য মূল্য (Subtotal):")
                                Text(FormatHelper.formatTaka(subtotal), fontWeight = FontWeight.SemiBold)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Discount field
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("ছাড় (Discount):")
                                OutlinedTextField(
                                    value = discountText,
                                    onValueChange = {
                                        discountText = it
                                        viewModel.saleDiscount.value = it.toDoubleOrNull() ?: 0.0
                                    },
                                    placeholder = { Text("0") },
                                    modifier = Modifier.width(130.dp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("সর্বমোট চালান মূল্য:", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(FormatHelper.formatTaka(grandTotal), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PharmacyTealPrimary)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Paid Amount Input & Quick buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("নগদ পরিশোধ:", fontWeight = FontWeight.Medium)
                                OutlinedTextField(
                                    value = paidText,
                                    onValueChange = {
                                        paidText = it
                                        viewModel.salePaidAmount.value = it.toDoubleOrNull() ?: 0.0
                                    },
                                    placeholder = { Text("0") },
                                    modifier = Modifier.width(130.dp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                SuggestionChip(
                                    onClick = { setFullPaid() },
                                    label = { Text("পুরো পরিশোধ") }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                SuggestionChip(
                                    onClick = { setFullDue() },
                                    label = { Text("পুরো বাকি") }
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("চালানের নতুন বাকি:", fontWeight = FontWeight.SemiBold, color = DueRed)
                                Text(FormatHelper.formatTaka(dueAmount), fontWeight = FontWeight.Bold, color = DueRed)
                            }

                            if (selectedCustomer != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                val totalCustomerFinalDue = previousDue + dueAmount
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("সর্বমোট অবশিষ্ট বাকি:", fontWeight = FontWeight.Bold, color = DueRed)
                                    Text(FormatHelper.formatTaka(totalCustomerFinalDue), fontWeight = FontWeight.Bold, color = DueRed)
                                }
                            }
                        }
                    }
                }

                // Optional Note
                item {
                    OutlinedTextField(
                        value = saleNote,
                        onValueChange = { viewModel.saleNote.value = it },
                        label = { Text("মন্তব্য (ঐচ্ছিক)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                // Complete Sale Button
                item {
                    Button(
                        onClick = {
                            viewModel.completeSaleAndOpenReceipt { saleId ->
                                // Navigated to receipt
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("চালান সম্পন্ন ও রসিদ তৈরি করুন", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }

    // Medicine Picker Dialog
    if (showMedicinePicker) {
        var pickerSearch by remember { mutableStateOf("") }
        val filteredList = remember(pickerSearch, allMedicines) {
            if (pickerSearch.isBlank()) allMedicines
            else allMedicines.filter {
                it.name.contains(pickerSearch, ignoreCase = true) ||
                        it.genericName.contains(pickerSearch, ignoreCase = true) ||
                        it.company.contains(pickerSearch, ignoreCase = true)
            }
        }

        AlertDialog(
            onDismissRequest = { showMedicinePicker = false },
            title = { Text("ওষুধ নির্বাচন করুন") },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    OutlinedTextField(
                        value = pickerSearch,
                        onValueChange = { pickerSearch = it },
                        placeholder = { Text("নাম, কোম্পানি বা জেনেরিক দিয়ে খুঁজুন...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(filteredList) { med ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        viewModel.addMedicineToCart(med)
                                        showMedicinePicker = false
                                    },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = med.name, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "${med.company} | স্টক: ${"%.0f".format(med.currentStock)}",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    Text(
                                        text = FormatHelper.formatTaka(med.sellingPrice),
                                        fontWeight = FontWeight.Bold,
                                        color = PharmacyTealPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMedicinePicker = false }) {
                    Text("বন্ধ করুন")
                }
            }
        )
    }

    // Customer Picker Dialog
    if (showCustomerPicker) {
        var custSearch by remember { mutableStateOf("") }
        val filteredCust = remember(custSearch, allCustomers) {
            if (custSearch.isBlank()) allCustomers
            else allCustomers.filter {
                it.name.contains(custSearch, ignoreCase = true) || it.phone.contains(custSearch)
            }
        }

        AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            title = { Text("গ্রাহক নির্বাচন করুন") },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    OutlinedTextField(
                        value = custSearch,
                        onValueChange = { custSearch = it },
                        placeholder = { Text("নাম বা মোবাইল নম্বর দিয়ে খুঁজুন...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                viewModel.saleCustomer.value = null
                                showCustomerPicker = false
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Text(
                            text = "নগদ ক্রেতা (নামহীন)",
                            modifier = Modifier.padding(12.dp),
                            fontWeight = FontWeight.Bold,
                            color = PharmacyTealPrimary
                        )
                    }
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(filteredCust) { cust ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        viewModel.saleCustomer.value = cust
                                        showCustomerPicker = false
                                    },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = cust.name, fontWeight = FontWeight.Bold)
                                        Text(text = cust.phone, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCustomerPicker = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Quick Add Customer Dialog
    if (showQuickAddCustomer) {
        var newName by remember { mutableStateOf("") }
        var newPhone by remember { mutableStateOf("") }
        var newAddress by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showQuickAddCustomer = false },
            title = { Text("দ্রুত নতুন গ্রাহক যুক্ত করুন") },
            text = {
                Column {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("গ্রাহকের নাম *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newPhone,
                        onValueChange = { newPhone = it },
                        label = { Text("মোবাইল নম্বর") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newAddress,
                        onValueChange = { newAddress = it },
                        label = { Text("ঠিকানা") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newName.isNotBlank()) {
                            scope.launch {
                                val id = viewModel.repository.insertCustomer(
                                    Customer(
                                        name = newName,
                                        phone = newPhone,
                                        address = newAddress
                                    )
                                )
                                val added = viewModel.repository.getCustomerById(id)
                                viewModel.saleCustomer.value = added
                                showQuickAddCustomer = false
                            }
                        }
                    }
                ) {
                    Text("সংরক্ষণ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickAddCustomer = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesListScreen(viewModel: AppViewModel) {
    val sales by viewModel.allSales.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    val filteredSales = remember(searchQuery, sales) {
        if (searchQuery.isBlank()) sales
        else sales.filter {
            it.receiptNumber.contains(searchQuery, ignoreCase = true) ||
                    it.customerName.contains(searchQuery, ignoreCase = true) ||
                    it.customerPhone.contains(searchQuery)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("বিক্রি চালানের তালিকা", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.clearCart()
                        viewModel.navigateTo(AppScreen.NEW_SALE)
                    }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "নতুন বিক্রি", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("রসিদ নং বা ক্রেতার নাম খুঁজুন...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredSales.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("কোন বিক্রি পাওয়া যায়নি", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filteredSales) { sale ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    // Open receipt for this sale
                                    // Load items and generate receipt
                                    scope.launch {
                                        val items = viewModel.repository.saleDao.getSaleItemsSync(sale.id)
                                        val prevDue = if (sale.customerId != null) {
                                            viewModel.repository.calculateCustomerDue(sale.customerId)
                                        } else 0.0
                                        val pdf = com.example.service.PdfGenerator.generateSaleReceiptPdf(
                                            context = viewModel.getApplication(),
                                            sale = sale,
                                            items = items,
                                            shopInfo = viewModel.shopInfo.value,
                                            previousDue = prevDue,
                                            currentDue = prevDue + sale.dueAmount
                                        )
                                        viewModel.previewReceiptPdf.value = pdf
                                        viewModel.previewReceiptTitle.value = "চালান #${sale.receiptNumber}"
                                        viewModel.navigateTo(AppScreen.RECEIPT_PREVIEW)
                                    }
                                },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = sale.customerName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text(
                                            text = "${sale.receiptNumber} | ${FormatHelper.formatDateTime(sale.saleDate)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = FormatHelper.formatTaka(sale.grandTotal),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = PharmacyTealPrimary
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "নগদ পরিশোধ: ${FormatHelper.formatTaka(sale.paidAmount)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = PaidGreen
                                    )
                                    if (sale.dueAmount > 0) {
                                        Text(
                                            text = "বাকি: ${FormatHelper.formatTaka(sale.dueAmount)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = DueRed
                                        )
                                    } else {
                                        Text(
                                            text = "পরিশোধিত",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = PaidGreen
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
