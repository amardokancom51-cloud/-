package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.AppSetting
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val shopInfo by viewModel.shopInfo.collectAsState()
    val isDriveBackupEnabled by viewModel.isDriveBackupEnabled.collectAsState()
    val isDriveConnected by viewModel.isDriveConnected.collectAsState()
    val lastBackupText by viewModel.lastBackupText.collectAsState()
    val backupOperationStatus by viewModel.backupOperationStatus.collectAsState()
    val backupPreview by viewModel.backupPreview.collectAsState()

    var showChangePinDialog by remember { mutableStateOf(false) }
    var showEditShopDialog by remember { mutableStateOf(false) }
    var showRestoreConfirmDialog by remember { mutableStateOf(false) }
    var showClearDataConfirmDialog by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("সেটিংস ও নিরাপত্তা", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // SECURITY SECTION
            Text("নিরাপত্তা (Security)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showChangePinDialog = true }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier.size(38.dp).clip(CircleShape).background(PharmacyTealContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Password, contentDescription = null, tint = PharmacyTealPrimary, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("পিন পরিবর্তন করুন (Change PIN)", fontWeight = FontWeight.SemiBold)
                                Text("৪ ডিজিটের গোপন পিন বদলান", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                    }
                }
            }

            // GOOGLE DRIVE & DATA BACKUP SECTION
            Text("গুগল ড্রাইভ ও ব্যাকআপ (Backup & Restore)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Google Drive Auto Backup Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("গুগল ড্রাইভ অটো ব্যাকআপ", fontWeight = FontWeight.SemiBold)
                            Text("ইন্টারনেট থাকলে স্বয়ংক্রিয় ব্যাকআপ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = isDriveBackupEnabled,
                            onCheckedChange = { viewModel.setDriveBackupToggle(it) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(10.dp))

                    // Connect Google Drive
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("গুগল ড্রাইভ সংযোগ", fontWeight = FontWeight.SemiBold)
                            Text(
                                text = if (isDriveConnected) "সংযুক্ত (Connected)" else "সংযুক্ত নেই",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isDriveConnected) PaidGreen else DueRed
                            )
                        }
                        OutlinedButton(onClick = { viewModel.connectGoogleDrive() }) {
                            Text(if (isDriveConnected) "পুনরায় কানেক্ট" else "কানেক্ট করুন")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(10.dp))

                    // Last Backup
                    Text("সর্বশেষ ব্যাকআপ: $lastBackupText", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)

                    if (backupOperationStatus != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(backupOperationStatus ?: "", style = MaterialTheme.typography.bodySmall, color = PharmacyTealPrimary)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.performBackupNow() },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("এখন ব্যাকআপ নিন")
                        }

                        OutlinedButton(
                            onClick = {
                                // Load latest backup file and inspect
                                scope.launch {
                                    val dir = File(context.filesDir, "backups")
                                    val files = dir.listFiles()
                                    if (files != null && files.isNotEmpty()) {
                                        val latest = files.maxByOrNull { it.lastModified() }
                                        if (latest != null) {
                                            viewModel.prepareRestoreFromJson(latest.readText())
                                            showRestoreConfirmDialog = true
                                        }
                                    } else {
                                        viewModel.backupOperationStatus.value = "কোন পূর্ববর্তী ব্যাকআপ ফাইল পাওয়া যায়নি"
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("রিস্টোর")
                        }
                    }
                }
            }

            // SHOP PROFILE SECTION
            Text("দোকান / ফার্মেসির প্রোফাইল", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = shopInfo.shopName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (shopInfo.phone.isNotBlank()) {
                        Text(text = "মোবাইল: ${shopInfo.phone}", style = MaterialTheme.typography.bodyMedium)
                    }
                    if (shopInfo.address.isNotBlank()) {
                        Text(text = "ঠিকানা: ${shopInfo.address}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { showEditShopDialog = true },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("দোকানের তথ্য এডিট করুন")
                    }
                }
            }

            // DATA EXPORT SECTION
            Text("ডাটা এক্সপোর্ট (Excel / CSV)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        scope.launch {
                            val file = viewModel.backupManager.exportCustomersCsv()
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/csv"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "গ্রাহক তালিকা এক্সপোর্ট"))
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.FileDownload, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("গ্রাহক CSV")
                }

                Button(
                    onClick = {
                        scope.launch {
                            val file = viewModel.backupManager.exportMedicinesCsv()
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/csv"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "ওষুধ তালিকা এক্সপোর্ট"))
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF43A047)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.FileDownload, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ওষুধ CSV")
                }
            }

            // APP INFO & DANGER ZONE
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
                onClick = { showClearDataConfirmDialog = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = DueRed)
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("সকল ডাটা রিসেট করুন (Clear Data)")
            }

            Text(
                text = "আমার ওষুধের খাতা - সংস্করণ ১.০\nসম্পূর্ণ অফলাইন ডাটাবেস ও গুগল ড্রাইভ ব্যাকআপ",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }
    }

    // Change PIN Dialog
    if (showChangePinDialog) {
        var oldPin by remember { mutableStateOf("") }
        var newPin by remember { mutableStateOf("") }
        var confirmPin by remember { mutableStateOf("") }
        var pinChangeError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChangePinDialog = false },
            title = { Text("পিন পরিবর্তন করুন") },
            text = {
                Column {
                    OutlinedTextField(
                        value = oldPin,
                        onValueChange = { if (it.length <= 4) oldPin = it },
                        label = { Text("বর্তমান পিন") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { if (it.length <= 4) newPin = it },
                        label = { Text("নতুন ৪ ডিজিট পিন") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = confirmPin,
                        onValueChange = { if (it.length <= 4) confirmPin = it },
                        label = { Text("নতুন পিন নিশ্চিত করুন") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinChangeError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(pinChangeError ?: "", color = DueRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (!viewModel.pinManager.verifyPin(oldPin)) {
                            pinChangeError = "বর্তমান পিনটি ভুল!"
                        } else if (newPin.length != 4) {
                            pinChangeError = "নতুন পিন অবশ্যই ৪ ডিজিটের হতে হবে"
                        } else if (newPin != confirmPin) {
                            pinChangeError = "নতুন পিন দুটি মেলেনি"
                        } else {
                            viewModel.pinManager.setPin(newPin)
                            showChangePinDialog = false
                        }
                    }
                ) {
                    Text("পরিবর্তন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePinDialog = false }) { Text("বাতিল") }
            }
        )
    }

    // Edit Shop Info Dialog
    if (showEditShopDialog) {
        var name by remember { mutableStateOf(shopInfo.shopName) }
        var owner by remember { mutableStateOf(shopInfo.ownerName) }
        var phone by remember { mutableStateOf(shopInfo.phone) }
        var address by remember { mutableStateOf(shopInfo.address) }
        var footer by remember { mutableStateOf(shopInfo.receiptFooter) }

        AlertDialog(
            onDismissRequest = { showEditShopDialog = false },
            title = { Text("দোকানের তথ্য পরিবর্তন") },
            text = {
                Column {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("ফার্মেসির নাম") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = owner,
                        onValueChange = { owner = it },
                        label = { Text("মালিকের নাম") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("মোবাইল") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("ঠিকানা") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = footer,
                        onValueChange = { footer = it },
                        label = { Text("রসিদের ফুটার বার্তা") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateShopInfo(name, owner, phone, address, footer)
                        showEditShopDialog = false
                    }
                ) {
                    Text("সংরক্ষণ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditShopDialog = false }) { Text("বাতিল") }
            }
        )
    }

    // Restore Confirm Dialog with Preview
    if (showRestoreConfirmDialog && backupPreview != null) {
        val p = backupPreview!!
        AlertDialog(
            onDismissRequest = { showRestoreConfirmDialog = false },
            title = { Text("ব্যাকআপ রিস্টোর নিশ্চিত করুন") },
            text = {
                Column {
                    Text("সতর্কতা: রিস্টোর করলে বর্তমান ডাটা ব্যাকআপের ডাটা দিয়ে প্রতিস্থাপিত হবে।")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("ব্যাকআপ তারিখ: ${p.dateFormatted}", fontWeight = FontWeight.Bold)
                    Text("মোট গ্রাহক: ${p.customerCount} জন")
                    Text("মোট ওষুধ: ${p.medicineCount} টি")
                    Text("মোট বিক্রি: ${p.saleCount} টি")
                    Text("মোট পেমেন্ট: ${p.paymentCount} টি")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.confirmRestoreBackup()
                        showRestoreConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DueRed)
                ) {
                    Text("রিস্টোর করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreConfirmDialog = false }) { Text("বাতিল") }
            }
        )
    }

    // Clear Data Dialog
    if (showClearDataConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearDataConfirmDialog = false },
            title = { Text("ডাটা রিসেট নিশ্চিতকরণ") },
            text = {
                Text("আপনি কি নিশ্চিতভাবে দোকানের সকল ওষুধ, বিক্রি, গ্রাহক ও বাকি খাতার রেকর্ড মুছে ফেলতে চান? এটি আর ফিরিয়ে আনা যাবে না।")
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            viewModel.repository.customerDao.clearAll()
                            viewModel.repository.medicineDao.clearAll()
                            viewModel.repository.saleDao.clearAllSales()
                            viewModel.repository.saleDao.clearAllSaleItems()
                            viewModel.repository.paymentDao.clearAll()
                            showClearDataConfirmDialog = false
                            viewModel.navigateTo(AppScreen.DASHBOARD)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DueRed)
                ) {
                    Text("সকল তথ্য মুছুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDataConfirmDialog = false }) { Text("বাতিল") }
            }
        )
    }
}
