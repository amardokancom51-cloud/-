package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.PinDots
import com.example.ui.components.PinKeypad
import com.example.ui.theme.DueRed
import com.example.ui.theme.PharmacyTealPrimary
import com.example.ui.viewmodel.AppViewModel

@Composable
fun FirstLaunchSetupScreen(viewModel: AppViewModel) {
    val step by viewModel.setupStep.collectAsState()
    val shopName by viewModel.setupShopName.collectAsState()
    val phone by viewModel.setupOwnerPhone.collectAsState()
    val pin1 by viewModel.setupPin1.collectAsState()
    val pin2 by viewModel.setupPin2.collectAsState()
    val secQuestion by viewModel.setupSecurityQuestion.collectAsState()
    val secAnswer by viewModel.setupSecurityAnswer.collectAsState()

    var errorMessage by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(PharmacyTealPrimary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_app_pharmacy_logo),
                        contentDescription = "লোগো",
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "আমার ওষুধের খাতা",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = PharmacyTealPrimary
                )

                Text(
                    text = "ফার্মেসি ও গ্রাহক বাকি খাতার স্বয়ংক্রিয় হিসাব",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Step Indicator
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 1..4) {
                        Box(
                            modifier = Modifier
                                .size(if (i == step) 28.dp else 22.dp)
                                .clip(CircleShape)
                                .background(
                                    if (i == step) PharmacyTealPrimary
                                    else if (i < step) PharmacyTealPrimary.copy(alpha = 0.5f)
                                    else MaterialTheme.colorScheme.outlineVariant
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$i",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }

            // Step Content
            when (step) {
                1 -> {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "ধাপ ১: আপনার দোকানের তথ্য",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PharmacyTealPrimary
                        )
                        Text(
                            text = "এই তথ্যগুলো আপনার বিক্রয় রশিদ ও খতিয়ানে প্রদর্শিত হবে।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        OutlinedTextField(
                            value = shopName,
                            onValueChange = { viewModel.setupShopName.value = it },
                            label = { Text("দোকান / ফার্মেসির নাম *") },
                            placeholder = { Text("যেমন: সেবা ফার্মেসি") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = phone,
                            onValueChange = { viewModel.setupOwnerPhone.value = it },
                            label = { Text("মালিকের মোবাইল নম্বর *") },
                            placeholder = { Text("০১৭XXXXXXXX") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = errorMessage ?: "", color = DueRed, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                if (shopName.isBlank()) {
                                    errorMessage = "দয়া করে আপনার ফার্মেসির নাম লিখুন"
                                } else {
                                    errorMessage = null
                                    viewModel.setupStep.value = 2
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("পরবর্তী ধাপ (পিন সেটআপ)", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                2 -> {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "ধাপ ২: ৪ ডিজিটের নতুন পিন তৈরি করুন",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PharmacyTealPrimary
                        )
                        Text(
                            text = "অ্যাপ সুরক্ষিত রাখতে একটি ৪ সংখ্যার পিন কোড দিন",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        PinDots(pinLength = pin1.length)

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = errorMessage ?: "", color = DueRed, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        PinKeypad(
                            onDigitClick = { digit ->
                                if (pin1.length < 4) {
                                    viewModel.setupPin1.value += digit
                                    if (viewModel.setupPin1.value.length == 4) {
                                        errorMessage = null
                                        viewModel.setupStep.value = 3
                                    }
                                }
                            },
                            onBackspace = {
                                if (pin1.isNotEmpty()) viewModel.setupPin1.value = pin1.dropLast(1)
                            }
                        )
                    }
                }
                3 -> {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "ধাপ ৩: পিন নিশ্চিত (Confirm) করুন",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PharmacyTealPrimary
                        )
                        Text(
                            text = "আগের পিনটি আবার টাইপ করুন",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        PinDots(pinLength = pin2.length)

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = errorMessage ?: "", color = DueRed, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        PinKeypad(
                            onDigitClick = { digit ->
                                if (pin2.length < 4) {
                                    viewModel.setupPin2.value += digit
                                    if (viewModel.setupPin2.value.length == 4) {
                                        if (viewModel.setupPin1.value == viewModel.setupPin2.value) {
                                            errorMessage = null
                                            viewModel.setupStep.value = 4
                                        } else {
                                            viewModel.setupPin2.value = ""
                                            errorMessage = "পিন দুটি মেলেনি! আবার লিখুন।"
                                        }
                                    }
                                }
                            },
                            onBackspace = {
                                if (pin2.isNotEmpty()) viewModel.setupPin2.value = pin2.dropLast(1)
                            }
                        )
                    }
                }
                4 -> {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "ধাপ ৪: পিন রিকভারি সিকিউরিটি",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PharmacyTealPrimary
                        )
                        Text(
                            text = "পিন ভুলে গেলে পুনরুদ্ধারের জন্য একটি প্রশ্ন ও উত্তর সেট করুন।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        OutlinedTextField(
                            value = secQuestion,
                            onValueChange = { viewModel.setupSecurityQuestion.value = it },
                            label = { Text("নিরাপত্তা প্রশ্ন") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = false
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = secAnswer,
                            onValueChange = { viewModel.setupSecurityAnswer.value = it },
                            label = { Text("প্রশ্নের উত্তর *") },
                            placeholder = { Text("যেমন: বিরিয়ানি অথবা স্কুলের নাম") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = errorMessage ?: "", color = DueRed, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                if (secAnswer.isBlank()) {
                                    errorMessage = "দয়া করে নিরাপত্তা প্রশ্নের একটি উত্তর লিখুন"
                                } else {
                                    errorMessage = null
                                    viewModel.completeSetup()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("সেটআপ সম্পন্ন করুন", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
