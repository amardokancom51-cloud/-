package com.example.ui.screens

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.widget.DatePicker
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.Challan
import com.example.data.model.Customer
import com.example.data.model.Medicine
import com.example.service.PdfGenerator
import com.example.ui.components.FormatHelper
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AppViewModel
import com.example.ui.viewmodel.ChallanRowState
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewChallanScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val challanNumber by viewModel.challanNumber.collectAsState()
    val challanDate by viewModel.challanDate.collectAsState()
    val selectedCustomer by viewModel.challanCustomer.collectAsState()
    val customerName by viewModel.challanCustomerName.collectAsState()
    val customerPhone by viewModel.challanCustomerPhone.collectAsState()
    val customerAddress by viewModel.challanCustomerAddress.collectAsState()
    val rows by viewModel.challanRows.collectAsState()
    val paidAmount by viewModel.challanPaidAmount.collectAsState()
    val note by viewModel.challanNote.collectAsState()

    val grossTotal by viewModel.challanGrossTotal.collectAsState()
    val totalDiscount by viewModel.challanTotalDiscount.collectAsState()
    val grandTotal by viewModel.challanGrandTotal.collectAsState()
    val dueAmount by viewModel.challanDueAmount.collectAsState()

    val allCustomers by viewModel.allCustomers.collectAsState()
    val allMedicines by viewModel.allMedicines.collectAsState()

    var showCustomerPicker by remember { mutableStateOf(false) }
    var showMedicinePickerForRow by remember { mutableStateOf<Int?>(null) }
    var paidAmountText by remember { mutableStateOf(if (paidAmount > 0) paidAmount.toString() else "") }
    var previousDue by remember { mutableStateOf(0.0) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(selectedCustomer) {
        val c = selectedCustomer
        if (c != null) {
            previousDue = viewModel.repository.calculateCustomerDue(c.id)
            viewModel.challanCustomerName.value = c.name
            viewModel.challanCustomerPhone.value = c.phone
            viewModel.challanCustomerAddress.value = c.address
        } else {
            previousDue = 0.0
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ওষুধের চালান তৈরি", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.previewDraftChallan() }) {
                        Icon(imageVector = Icons.Default.Visibility, contentDescription = "চালান দেখুন", tint = Color.White)
                    }
                    IconButton(onClick = {
                        viewModel.startNewChallan()
                    }) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "নতুন", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Challan Header & Meta Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("চালান নম্বর:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(challanNumber, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PharmacyTealPrimary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("তারিখ: ${FormatHelper.formatDate(challanDate)}", style = MaterialTheme.typography.bodySmall)
                                TextButton(
                                    onClick = {
                                        val cal = Calendar.getInstance().apply { timeInMillis = challanDate }
                                        DatePickerDialog(
                                            context,
                                            { _: DatePicker, y: Int, m: Int, d: Int ->
                                                val c = Calendar.getInstance().apply { set(y, m, d) }
                                                viewModel.challanDate.value = c.timeInMillis
                                            },
                                            cal.get(Calendar.YEAR),
                                            cal.get(Calendar.MONTH),
                                            cal.get(Calendar.DAY_OF_MONTH)
                                        ).show()
                                    },
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("তারিখ বদলান", fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(10.dp))

                        // Customer Selection
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("কাস্টমার তথ্য", fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                            TextButton(onClick = { showCustomerPicker = true }) {
                                Icon(Icons.Default.PersonSearch, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("তালিকা থেকে নির্বাচন")
                            }
                        }

                        OutlinedTextField(
                            value = customerName,
                            onValueChange = {
                                viewModel.challanCustomerName.value = it
                                if (selectedCustomer != null && selectedCustomer!!.name != it) {
                                    viewModel.challanCustomer.value = null
                                }
                            },
                            label = { Text("কাস্টমারের নাম *") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = customerPhone,
                                onValueChange = { viewModel.challanCustomerPhone.value = it },
                                label = { Text("মোবাইল নম্বর") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = customerAddress,
                                onValueChange = { viewModel.challanCustomerAddress.value = it },
                                label = { Text("ঠিকানা (ঐচ্ছিক)") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        if (selectedCustomer != null && previousDue > 0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "গ্রাহকের পূর্বের বকেয়া বাকি: ${FormatHelper.formatTaka(previousDue)}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = DueRed
                            )
                        }
                    }
                }
            }

            // Medicine Rows Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ওষুধের তালিকা ও হিসাব (${rows.size} টি আইটেম)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = PharmacyTealPrimary
                    )
                    Button(
                        onClick = { viewModel.addChallanRow() },
                        colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("রো যোগ করুন")
                    }
                }
            }

            // Medicine Rows Cards
            itemsIndexed(rows) { index, row ->
                ChallanRowEditorCard(
                    row = row,
                    onUpdate = { updated -> viewModel.updateChallanRow(index, updated) },
                    onDelete = { viewModel.removeChallanRow(index) },
                    onPickMedicine = { showMedicinePickerForRow = index }
                )
            }

            // Calculation Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("চালান মোট হিসাব (স্বয়ংক্রিয়)", fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("মোট মূল মূল্য (Gross):")
                            Text(FormatHelper.formatTaka(grossTotal), fontWeight = FontWeight.SemiBold)
                        }
                        if (totalDiscount > 0) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("মোট ছাড় (Discount):")
                                Text("-${FormatHelper.formatTaka(totalDiscount)}", fontWeight = FontWeight.SemiBold, color = PaidGreen)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("সর্বমোট চালান মূল্য:", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(FormatHelper.formatTaka(grandTotal), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PharmacyTealPrimary)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Paid Amount field
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("পরিশোধিত টাকা (জমা):", fontWeight = FontWeight.Medium)
                            OutlinedTextField(
                                value = paidAmountText,
                                onValueChange = {
                                    paidAmountText = it
                                    viewModel.challanPaidAmount.value = it.toDoubleOrNull() ?: 0.0
                                },
                                placeholder = { Text("0.0") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.width(130.dp),
                                singleLine = true
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            SuggestionChip(
                                onClick = {
                                    paidAmountText = grandTotal.toString()
                                    viewModel.challanPaidAmount.value = grandTotal
                                },
                                label = { Text("পূর্ণ পরিশোধ") }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            SuggestionChip(
                                onClick = {
                                    paidAmountText = "0"
                                    viewModel.challanPaidAmount.value = 0.0
                                },
                                label = { Text("পূর্ণ বাকি") }
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("চালানের বাকি টাকা:", fontWeight = FontWeight.Bold, color = DueRed)
                            Text(FormatHelper.formatTaka(dueAmount), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DueRed)
                        }

                        if (selectedCustomer != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            val totalCombined = previousDue + dueAmount
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("সর্বমোট অবশিষ্ট বকেয়া:", fontWeight = FontWeight.Bold, color = DueRed)
                                Text(FormatHelper.formatTaka(totalCombined), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DueRed)
                            }
                        }
                    }
                }
            }

            // Note field
            item {
                OutlinedTextField(
                    value = note,
                    onValueChange = { viewModel.challanNote.value = it },
                    label = { Text("চালান নোট / মন্তব্য (ঐচ্ছিক)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            if (errorMessage != null) {
                item {
                    Text(text = errorMessage ?: "", color = DueRed, fontSize = 13.sp)
                }
            }

            // Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.previewDraftChallan() },
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, PharmacyTealPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Visibility, contentDescription = null, tint = PharmacyTealPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("চালান দেখুন", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                    }

                    Button(
                        onClick = {
                            val validRows = rows.filter { it.medicineName.isNotBlank() }
                            if (validRows.isEmpty()) {
                                errorMessage = "কমপক্ষে একটি ওষুধের নাম ও বিবরণ পূরণ করুন"
                            } else {
                                errorMessage = null
                                viewModel.saveChallanOffline { savedId ->
                                    Toast.makeText(context, "চালান সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1.2f)
                            .height(54.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("চালান সংরক্ষণ", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // Post-save Modal / Dialog (Requirement 19)
        val showPostSaveDialog by viewModel.showPostSaveDialog.collectAsState()
        val postSaveChallan by viewModel.postSaveChallan.collectAsState()

        if (showPostSaveDialog && postSaveChallan != null) {
            val saved = postSaveChallan!!
            AlertDialog(
                onDismissRequest = { viewModel.showPostSaveDialog.value = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = PaidGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("চালান সংরক্ষিত", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "চালান #${saved.challanNumber} সফলভাবে ডাটাবেজে সংরক্ষিত হয়েছে।",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedButton(
                            onClick = {
                                viewModel.showPostSaveDialog.value = false
                                viewModel.previewSavedChallan(saved.id)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = null, tint = PharmacyTealPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("👁 চালান দেখুন", fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.saveChallanPdfToPhone(saved.id) { msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFFD32F2F))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("📄 PDF তৈরি করুন", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.saveChallanPdfToPhone(saved.id) { msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF1976D2))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("⬇ ডাউনলোড/সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.shareSavedChallan(saved.id, context)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF388E3C))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("↗ শেয়ার করুন", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.printSavedChallan(saved.id, context)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, tint = Color(0xFF5D4037))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("🖨 প্রিন্ট করুন", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.showPostSaveDialog.value = false
                                viewModel.editExistingChallan(saved.id)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("✏ সম্পাদনা করুন", fontWeight = FontWeight.Bold)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.showPostSaveDialog.value = false
                            viewModel.navigateTo(AppScreen.CHALLAN_LIST)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary)
                    ) {
                        Text("সম্পন্ন")
                    }
                }
            )
        }
    }

    // Medicine Picker Dialog for Row
    if (showMedicinePickerForRow != null) {
        val rowIndex = showMedicinePickerForRow!!
        var pickerSearch by remember { mutableStateOf("") }
        val filteredMeds = remember(pickerSearch, allMedicines) {
            if (pickerSearch.isBlank()) allMedicines
            else allMedicines.filter { it.name.contains(pickerSearch, ignoreCase = true) || it.company.contains(pickerSearch, ignoreCase = true) }
        }

        AlertDialog(
            onDismissRequest = { showMedicinePickerForRow = null },
            title = { Text("ওষুধ নির্বাচন করুন") },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                    OutlinedTextField(
                        value = pickerSearch,
                        onValueChange = { pickerSearch = it },
                        placeholder = { Text("নাম বা কোম্পানি দিয়ে খুঁজুন...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn {
                        items(filteredMeds) { med ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        val existing = rows[rowIndex]
                                        viewModel.updateChallanRow(
                                            rowIndex,
                                            existing.copy(
                                                medicineId = med.id,
                                                medicineName = med.name,
                                                companyName = med.company,
                                                boxPrice = if (existing.boxPrice > 0) existing.boxPrice else (med.sellingPrice * existing.piecesPerBox)
                                            )
                                        )
                                        showMedicinePickerForRow = null
                                    },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(med.name, fontWeight = FontWeight.Bold)
                                        Text(med.company, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text("স্টক: ${"%.0f".format(med.currentStock)}", color = PharmacyTealPrimary)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showMedicinePickerForRow = null }) { Text("বাতিল") } }
        )
    }

    // Customer Picker Dialog
    if (showCustomerPicker) {
        var custSearch by remember { mutableStateOf("") }
        val filteredCust = remember(custSearch, allCustomers) {
            if (custSearch.isBlank()) allCustomers
            else allCustomers.filter { it.name.contains(custSearch, ignoreCase = true) || it.phone.contains(custSearch) }
        }

        AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            title = { Text("কাস্টমার নির্বাচন করুন") },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                    OutlinedTextField(
                        value = custSearch,
                        onValueChange = { custSearch = it },
                        placeholder = { Text("নাম বা মোবাইল নম্বর...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn {
                        items(filteredCust) { cust ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        viewModel.challanCustomer.value = cust
                                        showCustomerPicker = false
                                    },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(cust.name, fontWeight = FontWeight.Bold)
                                        Text(cust.phone, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Icon(Icons.Default.Check, contentDescription = null)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showCustomerPicker = false }) { Text("বাতিল") } }
        )
    }
}

@Composable
fun ChallanRowEditorCard(
    row: ChallanRowState,
    onUpdate: (ChallanRowState) -> Unit,
    onDelete: () -> Unit,
    onPickMedicine: () -> Unit
) {
    var name by remember(row.medicineName) { mutableStateOf(row.medicineName) }
    var company by remember(row.companyName) { mutableStateOf(row.companyName) }
    var piecesText by remember(row.piecesPerBox) { mutableStateOf(row.piecesPerBox.toString()) }
    var boxText by remember(row.boxQuantity) { mutableStateOf(if (row.boxQuantity > 0) row.boxQuantity.toString() else "1") }
    var priceText by remember(row.boxPrice) { mutableStateOf(if (row.boxPrice > 0) row.boxPrice.toString() else "") }
    var discountText by remember(row.discountPercent) { mutableStateOf(if (row.discountPercent > 0) row.discountPercent.toString() else "0") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Row Serial & Medicine Name & Quick Picker
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(PharmacyTealPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${row.serialNumber}",
                            fontWeight = FontWeight.Bold,
                            color = PharmacyTealPrimary,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            onUpdate(row.copy(medicineName = it))
                        },
                        label = { Text("ওষুধের নাম *") },
                        placeholder = { Text("যেমন: Napa 500") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                IconButton(onClick = onPickMedicine) {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "ইনভেন্টরি থেকে খুঁজুন", tint = PharmacyTealPrimary)
                }

                IconButton(onClick = onDelete) {
                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "রো মুছুন", tint = DueRed)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Box and Pieces Fields
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = piecesText,
                    onValueChange = {
                        piecesText = it
                        val p = it.toIntOrNull() ?: 1
                        onUpdate(row.copy(piecesPerBox = p))
                    },
                    label = { Text("প্রতি বক্সে পিস") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                OutlinedTextField(
                    value = boxText,
                    onValueChange = {
                        boxText = it
                        val b = it.toDoubleOrNull() ?: 1.0
                        onUpdate(row.copy(boxQuantity = b))
                    },
                    label = { Text("বক্স সংখ্যা") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                // Calculated total pieces
                Card(
                    modifier = Modifier.weight(1f).height(56.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("মোট পিস", style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
                        Text("${"%.0f".format(row.totalPieces)}", fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Box Price and Percentage Discount
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = priceText,
                    onValueChange = {
                        priceText = it
                        val p = it.toDoubleOrNull() ?: 0.0
                        onUpdate(row.copy(boxPrice = p))
                    },
                    label = { Text("প্রতি বক্স মূল্য *") },
                    placeholder = { Text("0.0") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                OutlinedTextField(
                    value = discountText,
                    onValueChange = {
                        discountText = it
                        val d = it.toDoubleOrNull() ?: 0.0
                        onUpdate(row.copy(discountPercent = d))
                    },
                    label = { Text("ছাড় % (Discount)") },
                    placeholder = { Text("0") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                // Calculated net total
                Card(
                    modifier = Modifier.weight(1f).height(56.dp),
                    colors = CardDefaults.cardColors(containerColor = PharmacyTealContainer)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("মোট মূল্য", style = MaterialTheme.typography.bodySmall, fontSize = 11.sp, color = PharmacyTealPrimary)
                        Text(FormatHelper.formatTaka(row.netTotal), fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChallanListScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val challans by viewModel.allChallans.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(searchQuery, challans) {
        if (searchQuery.isBlank()) challans
        else challans.filter {
            it.challanNumber.contains(searchQuery, ignoreCase = true) ||
                    it.customerName.contains(searchQuery, ignoreCase = true) ||
                    it.customerPhone.contains(searchQuery)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ওষুধের চালান ইতিহাস", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.startNewChallan() }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "নতুন চালান", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.startNewChallan() },
                containerColor = PharmacyTealPrimary,
                contentColor = Color.White
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "নতুন চালান")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("চালান নং বা কাস্টমারের নাম দিয়ে খুঁজুন...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("কোন চালান পাওয়া যায়নি", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered) { ch ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectChallan(ch.id) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = ch.customerName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text(
                                            text = "${ch.challanNumber} | ${FormatHelper.formatDateTime(ch.challanDate)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = FormatHelper.formatTaka(ch.grandTotal),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = PharmacyTealPrimary
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "জমা: ${FormatHelper.formatTaka(ch.paidAmount)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = PaidGreen
                                    )
                                    if (ch.dueAmount > 0) {
                                        Text(
                                            text = "বাকি: ${FormatHelper.formatTaka(ch.dueAmount)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = DueRed
                                        )
                                    } else {
                                        Text(
                                            text = "পরিশোধিত",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = PaidGreen
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = Color(0xFFEEEEEE))
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = { viewModel.previewSavedChallan(ch.id) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("দেখুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.editExistingChallan(ch.id) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1.1f)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("সম্পাদনা", fontSize = 12.sp)
                                    }

                                    IconButton(
                                        onClick = {
                                            viewModel.saveChallanPdfToPhone(ch.id) { msg ->
                                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                            }
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = "ডাউনলোড", tint = Color(0xFF1976D2), modifier = Modifier.size(18.dp))
                                    }

                                    IconButton(
                                        onClick = { viewModel.shareSavedChallan(ch.id, context) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "শেয়ার", tint = Color(0xFF388E3C), modifier = Modifier.size(18.dp))
                                    }

                                    IconButton(
                                        onClick = { viewModel.printSavedChallan(ch.id, context) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Print, contentDescription = "প্রিন্ট", tint = Color(0xFF5D4037), modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChallanPreviewScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val isDraft by viewModel.isDraftChallanPreview.collectAsState()
    val shopInfo by viewModel.shopInfo.collectAsState()

    // Saved challan state
    val savedChallan by viewModel.selectedChallan.collectAsState()
    val savedItems by viewModel.selectedChallanItems.collectAsState()

    // Draft challan state
    val draftNumber by viewModel.challanNumber.collectAsState()
    val draftDate by viewModel.challanDate.collectAsState()
    val draftCustomer by viewModel.challanCustomer.collectAsState()
    val draftCustomerName by viewModel.challanCustomerName.collectAsState()
    val draftCustomerPhone by viewModel.challanCustomerPhone.collectAsState()
    val draftCustomerAddress by viewModel.challanCustomerAddress.collectAsState()
    val draftRows by viewModel.challanRows.collectAsState()
    val draftGross by viewModel.challanGrossTotal.collectAsState()
    val draftDiscount by viewModel.challanTotalDiscount.collectAsState()
    val draftGrand by viewModel.challanGrandTotal.collectAsState()
    val draftPaid by viewModel.challanPaidAmount.collectAsState()
    val draftDue by viewModel.challanDueAmount.collectAsState()

    var showCancelConfirm by remember { mutableStateOf(false) }

    // If not draft and saved challan is still loading
    if (!isDraft && savedChallan == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PharmacyTealPrimary)
        }
        return
    }

    // Resolve which data to display
    val chNumber = if (isDraft) draftNumber.ifBlank { "CH-DRAFT" } else (savedChallan?.challanNumber ?: "")
    val chDate = if (isDraft) draftDate else (savedChallan?.challanDate ?: System.currentTimeMillis())
    val cName = if (isDraft) (draftCustomer?.name ?: draftCustomerName.ifBlank { "সাধারণ ক্রেতা" }) else (savedChallan?.customerName ?: "সাধারণ ক্রেতা")
    val cPhone = if (isDraft) (draftCustomer?.phone ?: draftCustomerPhone) else (savedChallan?.customerPhone ?: "")
    val cAddress = if (isDraft) (draftCustomer?.address ?: draftCustomerAddress) else (savedChallan?.customerAddress ?: "")
    val grossTotal = if (isDraft) draftGross else (savedChallan?.grossTotal ?: 0.0)
    val totalDiscount = if (isDraft) draftDiscount else (savedChallan?.totalDiscount ?: 0.0)
    val grandTotal = if (isDraft) draftGrand else (savedChallan?.grandTotal ?: 0.0)
    val paidAmount = if (isDraft) draftPaid else (savedChallan?.paidAmount ?: 0.0)
    val dueAmount = if (isDraft) draftDue else (savedChallan?.dueAmount ?: 0.0)

    val displayRows = if (isDraft) {
        draftRows.filter { it.medicineName.isNotBlank() }.mapIndexed { idx, r ->
            com.example.data.model.ChallanItem(
                challanId = 0,
                serialNumber = idx + 1,
                medicineId = r.medicineId,
                medicineName = r.medicineName,
                companyName = r.companyName,
                piecesPerBox = r.piecesPerBox,
                boxQuantity = r.boxQuantity,
                totalPieces = r.totalPieces,
                boxPrice = r.boxPrice,
                discountPercent = r.discountPercent,
                discountAmount = r.discountAmount,
                netTotal = r.netTotal
            )
        }
    } else {
        savedItems
    }

    val totalBoxes = displayRows.sumOf { it.boxQuantity }
    val totalPieces = displayRows.sumOf { it.totalPieces }

    var previousDue by remember { mutableStateOf(0.0) }
    LaunchedEffect(isDraft, draftCustomer, savedChallan) {
        val custId = if (isDraft) draftCustomer?.id else savedChallan?.customerId
        if (custId != null) {
            val calcDue = viewModel.repository.calculateCustomerDue(custId)
            previousDue = if (isDraft) calcDue else (calcDue - (savedChallan?.dueAmount ?: 0.0)).coerceAtLeast(0.0)
        } else {
            previousDue = 0.0
        }
    }

    val currentDue = previousDue + dueAmount

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isDraft) "চালান প্রিভিউ (খসড়া)" else "চালান: $chNumber",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (isDraft) "সংরক্ষণের পূর্বে সম্পূর্ণ চালান দেখুন" else "অফলাইন প্রিন্ট ও রসিদ প্রিভিউ",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "বন্ধ করুন", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        if (isDraft) {
                            viewModel.saveDraftPdfToPhone(context) { msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            }
                        } else {
                            viewModel.saveChallanPdfToPhone(savedChallan!!.id) { msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            }
                        }
                    }) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = "ডাউনলোড", tint = Color.White)
                    }

                    IconButton(onClick = {
                        if (isDraft) {
                            viewModel.shareDraftChallan(context)
                        } else {
                            viewModel.shareSavedChallan(savedChallan!!.id, context)
                        }
                    }) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "শেয়ার", tint = Color.White)
                    }

                    IconButton(onClick = {
                        if (isDraft) {
                            viewModel.printDraftChallan(context)
                        } else {
                            viewModel.printSavedChallan(savedChallan!!.id, context)
                        }
                    }) {
                        Icon(imageVector = Icons.Default.Print, contentDescription = "প্রিন্ট", tint = Color.White)
                    }

                    if (!isDraft && savedChallan != null) {
                        IconButton(onClick = { viewModel.editExistingChallan(savedChallan!!.id) }) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "এডিট", tint = Color.White)
                        }
                        IconButton(onClick = { showCancelConfirm = true }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "বাতিল", tint = Color.White)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFECEFF1))
        ) {
            // Action Bar Strip
            Surface(
                color = Color.White,
                tonalElevation = 2.dp,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isDraft) {
                        Button(
                            onClick = {
                                viewModel.saveChallanOffline {
                                    Toast.makeText(context, "চালান সফলভাবে সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = {
                            if (isDraft) {
                                viewModel.saveDraftPdfToPhone(context) { msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }
                            } else {
                                viewModel.saveChallanPdfToPhone(savedChallan!!.id) { msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ডাউনলোড/সংরক্ষণ")
                    }

                    OutlinedButton(
                        onClick = {
                            if (isDraft) {
                                viewModel.shareDraftChallan(context)
                            } else {
                                viewModel.shareSavedChallan(savedChallan!!.id, context)
                            }
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF388E3C))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("শেয়ার করুন")
                    }

                    OutlinedButton(
                        onClick = {
                            if (isDraft) {
                                viewModel.printDraftChallan(context)
                            } else {
                                viewModel.printSavedChallan(savedChallan!!.id, context)
                            }
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF5D4037))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("প্রিন্ট করুন")
                    }

                    if (!isDraft && savedChallan != null) {
                        OutlinedButton(
                            onClick = { viewModel.editExistingChallan(savedChallan!!.id) },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit করুন")
                        }
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateBack() },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("বন্ধ করুন")
                    }
                }
            }

            // A4 Paper Document View
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 680.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCFD8DC))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            // Header: Pharmacy Logo, Shop Details & Challan Title
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(PharmacyTealPrimary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.LocalHospital,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = shopInfo.shopName.ifBlank { "আমার ওষুধের খাতা" },
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp,
                                            color = Color(0xFF004D40)
                                        )
                                        if (shopInfo.address.isNotBlank()) {
                                            Text(text = shopInfo.address, fontSize = 11.sp, color = Color.Gray)
                                        }
                                        val contacts = listOfNotNull(
                                            if (shopInfo.phone.isNotBlank()) "মোবাইল: ${shopInfo.phone}" else null,
                                            if (shopInfo.email.isNotBlank()) "ইমেইল: ${shopInfo.email}" else null
                                        ).joinToString(" | ")
                                        if (contacts.isNotBlank()) {
                                            Text(text = contacts, fontSize = 10.5.sp, color = Color.Gray)
                                        }
                                    }
                                }

                                Surface(
                                    color = Color(0xFF004D40),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("ওষুধের চালান", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("CHALLAN", color = Color(0xFF80CBC4), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(thickness = 2.dp, color = PharmacyTealPrimary)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Metadata Card: Left: Challan info, Right: Customer info
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FBE7)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFC5E1A5))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("চালান নং: $chNumber", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("তারিখ: ${FormatHelper.formatDateTime(chDate)}", fontSize = 12.sp, color = Color.DarkGray)
                                    }
                                    Column(modifier = Modifier.weight(1.2f), horizontalAlignment = Alignment.End) {
                                        Text("ক্রেতা/ফার্মেসি: $cName", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        if (cPhone.isNotBlank()) {
                                            Text("মোবাইল: $cPhone", fontSize = 12.sp, color = Color.DarkGray)
                                        }
                                        if (cAddress.isNotBlank()) {
                                            Text("ঠিকানা: $cAddress", fontSize = 11.sp, color = Color.Gray)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Professional 8-Column Medicine Table
                            Box(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                                Column(modifier = Modifier.widthIn(min = 620.dp)) {
                                    // Table Header Row
                                    Surface(
                                        color = Color(0xFFE0F2F1),
                                        shape = RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("নং", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF004D40), modifier = Modifier.width(32.dp))
                                            Text("ওষুধের নাম", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF004D40), modifier = Modifier.width(150.dp))
                                            Text("প্রতি বক্সে", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF004D40), modifier = Modifier.width(75.dp), textAlign = TextAlign.Center)
                                            Text("বক্স", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF004D40), modifier = Modifier.width(48.dp), textAlign = TextAlign.Center)
                                            Text("মোট পিস", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF004D40), modifier = Modifier.width(70.dp), textAlign = TextAlign.Center)
                                            Text("বক্স দর", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF004D40), modifier = Modifier.width(75.dp), textAlign = TextAlign.End)
                                            Text("ছাড় %", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF004D40), modifier = Modifier.width(55.dp), textAlign = TextAlign.Center)
                                            Text("নিট মূল্য", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF004D40), modifier = Modifier.width(95.dp), textAlign = TextAlign.End)
                                        }
                                    }

                                    HorizontalDivider(color = Color(0xFFB2DFDB), thickness = 1.dp)

                                    if (displayRows.isEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(20.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("কোন ওষুধ আইটেম নেই", color = Color.Gray, fontSize = 12.sp)
                                        }
                                    } else {
                                        displayRows.forEachIndexed { idx, item ->
                                            Surface(
                                                color = if (idx % 2 == 1) Color(0xFFF9FBE7).copy(alpha = 0.35f) else Color.White
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 8.dp, vertical = 7.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text("${item.serialNumber}", fontSize = 11.sp, modifier = Modifier.width(32.dp), color = Color.DarkGray)
                                                    Column(modifier = Modifier.width(150.dp)) {
                                                        Text(item.medicineName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                        if (item.companyName.isNotBlank()) {
                                                            Text(item.companyName, fontSize = 10.sp, color = Color.Gray)
                                                        }
                                                    }
                                                    Text("${item.piecesPerBox} পিস", fontSize = 11.sp, modifier = Modifier.width(75.dp), textAlign = TextAlign.Center)
                                                    Text("${"%.0f".format(item.boxQuantity)}", fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.width(48.dp), textAlign = TextAlign.Center)
                                                    Text("${"%.0f".format(item.totalPieces)}", fontSize = 11.sp, modifier = Modifier.width(70.dp), textAlign = TextAlign.Center)
                                                    Text(FormatHelper.formatTaka(item.boxPrice), fontSize = 11.sp, modifier = Modifier.width(75.dp), textAlign = TextAlign.End)
                                                    Text(if (item.discountPercent > 0) "${item.discountPercent}%" else "০%", fontSize = 11.sp, modifier = Modifier.width(55.dp), textAlign = TextAlign.Center, color = if (item.discountPercent > 0) PaidGreen else Color.DarkGray)
                                                    Text(FormatHelper.formatTaka(item.netTotal), fontWeight = FontWeight.Bold, fontSize = 11.5.sp, modifier = Modifier.width(95.dp), textAlign = TextAlign.End, color = Color(0xFF004D40))
                                                }
                                            }
                                            HorizontalDivider(color = Color(0xFFEEEEEE), thickness = 0.5.dp)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Box & Piece Summary Card (Requirement 6)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(6.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFC5E1A5))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("চালান সারাংশ:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF33691E))
                                    Text("মোট ওষুধ: ${displayRows.size} টি", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                    Text("মোট বক্স: ${"%.0f".format(totalBoxes)} বক্স", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF33691E))
                                    Text("সর্বমোট পিস: ${"%.0f".format(totalPieces)} পিস", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF33691E))
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Totals and Financial Breakdown (Requirement 5 & 7)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                // Left: Customer Balance Details (if customer linked)
                                Card(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(6.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
                                    border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFFE0E0E0))
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("গ্রাহক লেনদেন বিবরণ:", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = PharmacyTealPrimary)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("আগের বাকি:", fontSize = 11.sp)
                                            Text(FormatHelper.formatTaka(previousDue), fontSize = 11.sp)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("এই চালানের মূল্য:", fontSize = 11.sp)
                                            Text(FormatHelper.formatTaka(grandTotal), fontSize = 11.sp)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("আজ জমা:", fontSize = 11.sp)
                                            Text(FormatHelper.formatTaka(paidAmount), fontSize = 11.sp, color = PaidGreen, fontWeight = FontWeight.SemiBold)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        HorizontalDivider(color = Color(0xFFBDBDBD))
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("বর্তমান বাকি:", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                            Text(FormatHelper.formatTaka(currentDue), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (currentDue > 0) DueRed else PaidGreen)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                // Right: Challan Financial Totals
                                Card(
                                    modifier = Modifier.weight(1.1f),
                                    shape = RoundedCornerShape(6.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0))
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("মোট মূল মূল্য:", fontSize = 11.5.sp)
                                            Text(FormatHelper.formatTaka(grossTotal), fontSize = 11.5.sp)
                                        }
                                        if (totalDiscount > 0) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("মোট ছাড়:", fontSize = 11.5.sp, color = PaidGreen)
                                                Text("-${FormatHelper.formatTaka(totalDiscount)}", fontSize = 11.5.sp, color = PaidGreen, fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        HorizontalDivider(color = Color(0xFFB2DFDB), thickness = 1.dp)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("সর্বমোট বিল:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(FormatHelper.formatTaka(grandTotal), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PharmacyTealPrimary)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("পরিশোধিত টাকা (জমা):", fontSize = 11.5.sp, color = PaidGreen)
                                            Text(FormatHelper.formatTaka(paidAmount), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PaidGreen)
                                        }
                                        if (dueAmount > 0) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("চালানের বকেয়া বাকি:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DueRed)
                                                Text(FormatHelper.formatTaka(dueAmount), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DueRed)
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(36.dp))

                            // Dual Signatures (Requirement 8)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(160.dp)) {
                                    Text("------------------------------------", color = Color.Gray, fontSize = 11.sp)
                                    Text("ক্রেতার স্বাক্ষর", fontWeight = FontWeight.Medium, fontSize = 11.sp, color = Color.DarkGray)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(160.dp)) {
                                    Text("------------------------------------", color = Color.Gray, fontSize = 11.sp)
                                    Text("বিক্রেতার স্বাক্ষর", fontWeight = FontWeight.Medium, fontSize = 11.sp, color = Color.DarkGray)
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))
                            HorizontalDivider(color = Color(0xFFEEEEEE))
                            Spacer(modifier = Modifier.height(8.dp))

                            // Professional Footer (Requirement 9)
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = shopInfo.receiptFooter.ifBlank { "কেনাকাটার জন্য ধন্যবাদ। সুস্থ থাকুন।" },
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                                Text(
                                    text = "এই চালানটি সফটওয়্যার দ্বারা তৈরি করা হয়েছে।",
                                    fontSize = 9.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }

    if (showCancelConfirm && savedChallan != null) {
        val ch = savedChallan!!
        AlertDialog(
            onDismissRequest = { showCancelConfirm = false },
            title = { Text("চালান বাতিল নিশ্চিত করুন") },
            text = { Text("আপনি কি নিশ্চিতভাবে চালান #${ch.challanNumber} বাতিল করতে চান? ওষুধ স্টক ফেরত যুক্ত হবে এবং বাকি সমন্বয় করা হবে।") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.cancelChallan(ch.id) {
                            showCancelConfirm = false
                            Toast.makeText(context, "চালান বাতিল করা হয়েছে", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DueRed)
                ) {
                    Text("বাতিল করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelConfirm = false }) { Text("না") }
            }
        )
    }
}

@Composable
fun ChallanDetailScreen(viewModel: AppViewModel) {
    ChallanPreviewScreen(viewModel = viewModel)
}
