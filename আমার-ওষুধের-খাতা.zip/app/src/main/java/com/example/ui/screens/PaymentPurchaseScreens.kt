package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.DatePicker
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.Medicine
import com.example.data.model.SalesReturn
import com.example.data.model.StockPurchase
import com.example.data.model.Supplier
import com.example.ui.components.FormatHelper
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentEntryScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val customers by viewModel.allCustomers.collectAsState()
    val selectedCustFromDetail by viewModel.selectedCustomer.collectAsState()

    var selectedCustomer by remember { mutableStateOf<Customer?>(selectedCustFromDetail) }
    var currentDue by remember { mutableStateOf(0.0) }
    var amountText by remember { mutableStateOf("") }
    var paymentDate by remember { mutableStateOf(System.currentTimeMillis()) }
    var paymentMethod by remember { mutableStateOf("নগদ (Cash)") }
    var note by remember { mutableStateOf("") }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(selectedCustomer) {
        val c = selectedCustomer
        if (c != null) {
            currentDue = viewModel.repository.calculateCustomerDue(c.id)
        } else {
            currentDue = 0.0
        }
    }

    val amount = amountText.toDoubleOrNull() ?: 0.0
    val newDue = (currentDue - amount).coerceAtLeast(0.0)

    val methods = listOf("নগদ (Cash)", "বিকাশ (bKash)", "নগদ (Nagad)", "ব্যাংক (Bank)", "রকেট (Rocket)")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("টাকা জমা / বাকি আদায়", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PaidGreen)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Customer Selector Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("গ্রাহক নির্বাচন", fontWeight = FontWeight.Bold, color = PaidGreen)
                        TextButton(onClick = { showCustomerPicker = true }) {
                            Icon(Icons.Default.PersonSearch, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("পরিবর্তন")
                        }
                    }

                    if (selectedCustomer != null) {
                        val c = selectedCustomer!!
                        Text(text = c.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(text = c.phone, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("বর্তমান বাকি:")
                            Text(
                                text = FormatHelper.formatTaka(currentDue),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = DueRed
                            )
                        }
                    } else {
                        Text("কোন গ্রাহক নির্বাচিত নেই। 'পরিবর্তন' চাপুন।", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Payment Amount Input
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                label = { Text("জমা / আদায়ের পরিমাণ (টাকা) *") },
                placeholder = { Text("0.0") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Quick Amount Buttons
            if (currentDue > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SuggestionChip(
                        onClick = { amountText = currentDue.toString() },
                        label = { Text("পূর্ণ পরিশোধ") }
                    )
                    SuggestionChip(
                        onClick = { amountText = (currentDue / 2).toString() },
                        label = { Text("৫০% পরিশোধ") }
                    )
                    SuggestionChip(
                        onClick = { amountText = "500" },
                        label = { Text("৫০০ ৳") }
                    )
                    SuggestionChip(
                        onClick = { amountText = "1000" },
                        label = { Text("১০০০ ৳") }
                    )
                }
            }

            // Payment Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("জমার তারিখ: ${FormatHelper.formatDate(paymentDate)}", fontWeight = FontWeight.Medium)
                TextButton(onClick = {
                    val cal = Calendar.getInstance().apply { timeInMillis = paymentDate }
                    DatePickerDialog(
                        context,
                        { _: DatePicker, y: Int, m: Int, d: Int ->
                            val c = Calendar.getInstance().apply { set(y, m, d) }
                            paymentDate = c.timeInMillis
                        },
                        cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                }) {
                    Text("তারিখ বদলান")
                }
            }

            // Payment Method Selector
            Text("পরিশোধের মাধ্যম:", fontWeight = FontWeight.Medium)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                methods.take(3).forEach { m ->
                    FilterChip(
                        selected = paymentMethod == m,
                        onClick = { paymentMethod = m },
                        label = { Text(m) }
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                methods.drop(3).forEach { m ->
                    FilterChip(
                        selected = paymentMethod == m,
                        onClick = { paymentMethod = m },
                        label = { Text(m) }
                    )
                }
            }

            // Note
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("মন্তব্য (ঐচ্ছিক)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Balance Recalculation Summary Box
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("পূর্বের বাকি:", color = Color.Black)
                        Text(FormatHelper.formatTaka(currentDue), fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("জমা হচ্ছে:", color = PaidGreen)
                        Text("-${FormatHelper.formatTaka(amount)}", fontWeight = FontWeight.Bold, color = PaidGreen)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("নতুন অবশিষ্ট বাকি:", fontWeight = FontWeight.Bold, color = DueRed)
                        Text(FormatHelper.formatTaka(newDue), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DueRed)
                    }
                }
            }

            if (errorMessage != null) {
                Text(text = errorMessage ?: "", color = DueRed, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    if (selectedCustomer == null) {
                        errorMessage = "দয়া করে একজন গ্রাহক নির্বাচন করুন"
                    } else if (amount <= 0) {
                        errorMessage = "সঠিক জমার পরিমাণ লিখুন"
                    } else {
                        errorMessage = null
                        viewModel.recordCustomerPayment(
                            customer = selectedCustomer!!,
                            amount = amount,
                            method = paymentMethod,
                            date = paymentDate,
                            note = note,
                            onSuccess = {
                                // Navigated to receipt
                            }
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PaidGreen)
            ) {
                Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("টাকা জমা নিশ্চিত ও রসিদ তৈরি করুন", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showCustomerPicker) {
        var custSearch by remember { mutableStateOf("") }
        val filteredCust = remember(custSearch, customers) {
            if (custSearch.isBlank()) customers
            else customers.filter {
                it.name.contains(custSearch, ignoreCase = true) || it.phone.contains(custSearch)
            }
        }

        AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            title = { Text("গ্রাহক নির্বাচন করুন") },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                    OutlinedTextField(
                        value = custSearch,
                        onValueChange = { custSearch = it },
                        placeholder = { Text("নাম বা মোবাইল নম্বর দিয়ে খুঁজুন...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(filteredCust) { cust ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        selectedCustomer = cust
                                        showCustomerPicker = false
                                    },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = cust.name, fontWeight = FontWeight.Bold)
                                        Text(text = cust.phone, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCustomerPicker = false }) { Text("বাতিল") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockPurchaseScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val medicines by viewModel.allMedicines.collectAsState()
    val suppliers by viewModel.allSuppliers.collectAsState()

    var selectedMedicine by remember { mutableStateOf<Medicine?>(null) }
    var selectedSupplier by remember { mutableStateOf<Supplier?>(null) }
    var supplierNameInput by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("") }
    var purchasePriceText by remember { mutableStateOf("") }
    var sellingPriceText by remember { mutableStateOf("") }
    var batchNumber by remember { mutableStateOf("") }
    var expiryDate by remember { mutableStateOf(0L) }
    var purchaseDate by remember { mutableStateOf(System.currentTimeMillis()) }
    var note by remember { mutableStateOf("") }

    var showMedicinePicker by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("স্টক ক্রয় / চালান এন্ট্রি", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Medicine Selection Card
            Card(
                modifier = Modifier.fillMaxWidth().clickable { showMedicinePicker = true },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ওষুধ নির্বাচন *", fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                        Text(
                            text = selectedMedicine?.let { "${it.name} (${it.company}) | বর্তমান স্টক: ${"%.0f".format(it.currentStock)}" } ?: "ওষুধ নির্বাচন করতে ক্লিক করুন",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Icon(Icons.Default.Search, contentDescription = null)
                }
            }

            // Supplier Input
            OutlinedTextField(
                value = supplierNameInput,
                onValueChange = { supplierNameInput = it },
                label = { Text("সরবরাহকারী / কোম্পানি প্রতিনিধি") },
                placeholder = { Text("যেমন: স্কয়ার ডিপো / ড্রাগ ইন্টারন্যাশনাল") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Quantity and Purchase Price
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    label = { Text("পরিমাণ (Quantity) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = purchasePriceText,
                    onValueChange = { purchasePriceText = it },
                    label = { Text("একক ক্রয়মূল্য *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            val qty = quantityText.toDoubleOrNull() ?: 0.0
            val pPrice = purchasePriceText.toDoubleOrNull() ?: 0.0
            val totalCost = qty * pPrice

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = PharmacyTealContainer)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("মোট ক্রয়মূল্য (স্বয়ংক্রিয় হিসাব):", color = PharmacyTealPrimary)
                    Text(FormatHelper.formatTaka(totalCost), fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                }
            }

            // Batch & Expiry
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = batchNumber,
                    onValueChange = { batchNumber = it },
                    label = { Text("ব্যাচ নম্বর") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = sellingPriceText,
                    onValueChange = { sellingPriceText = it },
                    label = { Text("বিক্রয়দর") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (expiryDate > 0) "মেয়াদ: ${FormatHelper.formatDate(expiryDate)}" else "মেয়াদোত্তীর্ণ তারিখ নির্ধারণ করুন",
                    style = MaterialTheme.typography.bodyMedium
                )
                TextButton(onClick = {
                    val cal = Calendar.getInstance().apply { if (expiryDate > 0) timeInMillis = expiryDate }
                    DatePickerDialog(
                        context,
                        { _: DatePicker, y: Int, m: Int, d: Int ->
                            val c = Calendar.getInstance().apply { set(y, m, d) }
                            expiryDate = c.timeInMillis
                        },
                        cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                }) {
                    Text("তারিখ দিন")
                }
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("মন্তব্য (ঐচ্ছিক)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            if (errorMessage != null) {
                Text(text = errorMessage ?: "", color = DueRed, fontSize = 13.sp)
            }
            if (successMessage != null) {
                Text(text = successMessage ?: "", color = PaidGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    if (selectedMedicine == null) {
                        errorMessage = "ওষুধ নির্বাচন করুন"
                    } else if (qty <= 0) {
                        errorMessage = "সঠিক পরিমাণ লিখুন"
                    } else if (pPrice <= 0) {
                        errorMessage = "ক্রয়মূল্য লিখুন"
                    } else {
                        errorMessage = null
                        scope.launch {
                            val med = selectedMedicine!!
                            viewModel.repository.recordStockPurchase(
                                StockPurchase(
                                    supplierName = supplierNameInput,
                                    medicineId = med.id,
                                    medicineName = med.name,
                                    quantity = qty,
                                    purchasePrice = pPrice,
                                    sellingPrice = sellingPriceText.toDoubleOrNull() ?: med.sellingPrice,
                                    batchNumber = batchNumber,
                                    expiryDate = expiryDate,
                                    purchaseDate = purchaseDate,
                                    note = note
                                )
                            )
                            successMessage = "স্টক সফলভাবে বৃদ্ধি পেয়েছে! নতুন স্টক: ${"%.0f".format(med.currentStock + qty)}"
                            quantityText = ""
                            purchasePriceText = ""
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary)
            ) {
                Icon(Icons.Default.AddShoppingCart, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("স্টক এন্ট্রি সংরক্ষণ করুন", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showMedicinePicker) {
        var pickerSearch by remember { mutableStateOf("") }
        val filtered = remember(pickerSearch, medicines) {
            if (pickerSearch.isBlank()) medicines
            else medicines.filter { it.name.contains(pickerSearch, ignoreCase = true) }
        }

        AlertDialog(
            onDismissRequest = { showMedicinePicker = false },
            title = { Text("ওষুধ নির্বাচন করুন") },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                    OutlinedTextField(
                        value = pickerSearch,
                        onValueChange = { pickerSearch = it },
                        placeholder = { Text("ওষুধের নাম খুঁজুন...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn {
                        items(filtered) { med ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        selectedMedicine = med
                                        purchasePriceText = if (med.purchasePrice > 0) med.purchasePrice.toString() else ""
                                        sellingPriceText = if (med.sellingPrice > 0) med.sellingPrice.toString() else ""
                                        showMedicinePicker = false
                                    },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(med.name, fontWeight = FontWeight.Bold)
                                    Text("স্টক: ${"%.0f".format(med.currentStock)}")
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showMedicinePicker = false }) { Text("বাতিল") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesReturnScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val medicines by viewModel.allMedicines.collectAsState()
    val customers by viewModel.allCustomers.collectAsState()

    var selectedMedicine by remember { mutableStateOf<Medicine?>(null) }
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var customerNameInput by remember { mutableStateOf("সাধারণ ক্রেতা") }
    var quantityText by remember { mutableStateOf("1") }
    var returnAmountText by remember { mutableStateOf("") }
    var reasonText by remember { mutableStateOf("") }
    var returnDate by remember { mutableStateOf(System.currentTimeMillis()) }

    var showMedicinePicker by remember { mutableStateOf(false) }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var medicineSearch by remember { mutableStateOf("") }
    var customerSearch by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    val reasonChips = listOf("ভুল ওষুধ", "অতিরিক্ত কেনা", "ডাক্তার প্রেসক্রিপশন পরিবর্তন", "মেয়াদ কাছাকাছি", "অন্যান্য")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ওষুধ ফেরত (Sales Return)", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PharmacyTealPrimary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Medicine Selection Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showMedicinePicker = true },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("ফেরতকৃত ওষুধ নির্বাচন *", fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                        Text(
                            text = selectedMedicine?.let { "${it.name} (${it.company}) | বর্তমান স্টক: ${"%.0f".format(it.currentStock)}" }
                                ?: "ওষুধ নির্বাচন করতে ক্লিক করুন",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Icon(Icons.Default.Medication, contentDescription = null, tint = PharmacyTealPrimary)
                }
            }

            // Customer Selection Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showCustomerPicker = true },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("ক্রেতা / কাস্টমার", fontWeight = FontWeight.Bold, color = PharmacyTealPrimary)
                        Text(
                            text = selectedCustomer?.let { "${it.name} (${it.phone})" } ?: customerNameInput,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Icon(Icons.Default.Person, contentDescription = null, tint = PharmacyTealPrimary)
                }
            }

            // Quantity & Refund Amount
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = quantityText,
                    onValueChange = {
                        quantityText = it
                        val q = it.toDoubleOrNull() ?: 0.0
                        val price = selectedMedicine?.sellingPrice ?: 0.0
                        if (q > 0 && price > 0) {
                            returnAmountText = "%.2f".format(q * price)
                        }
                    },
                    label = { Text("ফেরত পরিমাণ *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = returnAmountText,
                    onValueChange = { returnAmountText = it },
                    label = { Text("ফেরত টাকা (৳) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            // Reason Chips
            Text("ফেরতের কারণ:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                reasonChips.take(3).forEach { chip ->
                    FilterChip(
                        selected = reasonText == chip,
                        onClick = { reasonText = chip },
                        label = { Text(chip, fontSize = 11.sp) }
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                reasonChips.drop(3).forEach { chip ->
                    FilterChip(
                        selected = reasonText == chip,
                        onClick = { reasonText = chip },
                        label = { Text(chip, fontSize = 11.sp) }
                    )
                }
            }

            OutlinedTextField(
                value = reasonText,
                onValueChange = { reasonText = it },
                label = { Text("বিস্তারিত কারণ বা নোট") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Date picker
            val cal = Calendar.getInstance().apply { timeInMillis = returnDate }
            val datePickerDialog = DatePickerDialog(
                context,
                { _: DatePicker, y: Int, m: Int, d: Int ->
                    cal.set(y, m, d)
                    returnDate = cal.timeInMillis
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            )

            OutlinedTextField(
                value = FormatHelper.formatDate(returnDate),
                onValueChange = {},
                readOnly = true,
                label = { Text("ফেরতের তারিখ") },
                trailingIcon = {
                    IconButton(onClick = { datePickerDialog.show() }) {
                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = "তারিখ নির্বাচন")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMessage != null) {
                Text(text = errorMessage ?: "", color = DueRed, fontSize = 13.sp)
            }

            if (successMessage != null) {
                Text(text = successMessage ?: "", color = PaidGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val med = selectedMedicine
                    val qty = quantityText.toDoubleOrNull() ?: 0.0
                    val amount = returnAmountText.toDoubleOrNull() ?: 0.0

                    if (med == null) {
                        errorMessage = "দয়া করে ফেরতকৃত ওষুধ নির্বাচন করুন"
                        return@Button
                    }
                    if (qty <= 0) {
                        errorMessage = "সঠিক পরিমাণ প্রদান করুন"
                        return@Button
                    }
                    if (amount < 0) {
                        errorMessage = "সঠিক ফেরত টাকার পরিমাণ দিন"
                        return@Button
                    }

                    errorMessage = null
                    scope.launch {
                        viewModel.repository.recordSalesReturn(
                            SalesReturn(
                                customerId = selectedCustomer?.id,
                                customerName = selectedCustomer?.name ?: customerNameInput,
                                medicineId = med.id,
                                medicineName = med.name,
                                quantity = qty,
                                returnAmount = amount,
                                returnDate = returnDate,
                                reason = reasonText
                            )
                        )
                        successMessage = "ওষুধ ফেরত সফলভাবে রেকর্ড করা হয়েছে এবং স্টক আপডেট হয়েছে!"
                        kotlinx.coroutines.delay(1200)
                        viewModel.navigateBack()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PharmacyTealPrimary)
            ) {
                Icon(Icons.Default.AssignmentReturn, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("ফেরত নিশ্চিত করুন", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    // Medicine Picker Dialog
    if (showMedicinePicker) {
        val filteredMeds = medicines.filter {
            it.name.contains(medicineSearch, ignoreCase = true) ||
            it.company.contains(medicineSearch, ignoreCase = true)
        }

        AlertDialog(
            onDismissRequest = { showMedicinePicker = false },
            title = { Text("ওষুধ নির্বাচন করুন") },
            text = {
                Column(modifier = Modifier.height(350.dp)) {
                    OutlinedTextField(
                        value = medicineSearch,
                        onValueChange = { medicineSearch = it },
                        placeholder = { Text("ওষুধ বা কোম্পানির নাম খুঁজুন...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn {
                        items(filteredMeds) { med ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        selectedMedicine = med
                                        val q = quantityText.toDoubleOrNull() ?: 1.0
                                        if (med.sellingPrice > 0) {
                                            returnAmountText = "%.2f".format(q * med.sellingPrice)
                                        }
                                        showMedicinePicker = false
                                    },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(med.name, fontWeight = FontWeight.Bold)
                                        Text(med.company, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text("স্টক: ${"%.0f".format(med.currentStock)}")
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showMedicinePicker = false }) { Text("বাতিল") } }
        )
    }

    // Customer Picker Dialog
    if (showCustomerPicker) {
        val filteredCust = customers.filter {
            it.name.contains(customerSearch, ignoreCase = true) ||
            it.phone.contains(customerSearch)
        }

        AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            title = { Text("কাস্টমার নির্বাচন করুন") },
            text = {
                Column(modifier = Modifier.height(350.dp)) {
                    OutlinedTextField(
                        value = customerSearch,
                        onValueChange = { customerSearch = it },
                        placeholder = { Text("গ্রাহকের নাম বা ফোন খুঁজুন...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        onClick = {
                            selectedCustomer = null
                            customerNameInput = "সাধারণ ক্রেতা"
                            showCustomerPicker = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("সাধারণ ক্রেতা (ওয়াক-ইন)", fontWeight = FontWeight.Bold)
                    }
                    LazyColumn {
                        items(filteredCust) { c ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        selectedCustomer = c
                                        customerNameInput = c.name
                                        showCustomerPicker = false
                                    },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(c.name, fontWeight = FontWeight.Bold)
                                    if (c.phone.isNotBlank()) {
                                        Text(c.phone, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showCustomerPicker = false }) { Text("বাতিল") } }
        )
    }
}
