package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.*
import com.example.data.repository.AppRepository
import com.example.data.repository.CustomerFinancialSummary
import com.example.data.repository.CustomerLedgerEntry
import com.example.security.PinManager
import com.example.service.BackupManager
import com.example.service.BackupPreview
import com.example.service.NotificationHelper
import com.example.service.PdfGenerator
import com.example.service.ShopInfo
import com.example.ui.components.FormatHelper
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.*

enum class AppScreen {
    PIN_LOCK,
    FIRST_SETUP,
    DASHBOARD,
    SALES_LIST,
    NEW_SALE,
    CUSTOMER_LIST,
    CUSTOMER_DETAIL,
    MEDICINE_LIST,
    MEDICINE_DETAIL,
    PAYMENT_ENTRY,
    STOCK_PURCHASE,
    SALES_RETURN,
    CHALLAN_LIST,
    NEW_CHALLAN,
    CHALLAN_DETAIL,
    CHALLAN_PREVIEW,
    REPORTS,
    RECEIPT_PREVIEW,
    SETTINGS
}

data class CartItem(
    val medicine: Medicine,
    var quantity: Double,
    var unitPrice: Double,
    var purchasePrice: Double
) {
    val totalPrice: Double get() = quantity * unitPrice
}

data class ChallanRowState(
    val id: Long = 0,
    val serialNumber: Int = 1,
    val medicineId: Long = 0,
    val medicineName: String = "",
    val companyName: String = "",
    val piecesPerBox: Int = 100,
    val boxQuantity: Double = 1.0,
    val boxPrice: Double = 0.0,
    val discountPercent: Double = 0.0
) {
    val totalPieces: Double get() = piecesPerBox * boxQuantity
    val basePrice: Double get() = boxQuantity * boxPrice
    val discountAmount: Double get() = basePrice * (discountPercent / 100.0)
    val netTotal: Double get() = (basePrice - discountAmount).coerceAtLeast(0.0)
}

data class DashboardStats(
    val todaySales: Double = 0.0,
    val todayCollection: Double = 0.0,
    val todayNewDue: Double = 0.0,
    val totalOutstandingDue: Double = 0.0,
    val totalCustomerCount: Int = 0,
    val totalMedicineCount: Int = 0,
    val totalStockQuantity: Double = 0.0,
    val lowStockCount: Int = 0,
    val expiredCount: Int = 0,
    val dueRemindersCount: Int = 0
)

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = AppRepository(database)
    val pinManager = PinManager(application)
    val backupManager = BackupManager(application, database)

    // Current Screen
    private val _currentScreen = MutableStateFlow(
        if (!pinManager.isSetupComplete()) AppScreen.FIRST_SETUP else AppScreen.PIN_LOCK
    )
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Screen navigation stack for reliable BackHandler
    private val screenStack = ArrayDeque<AppScreen>()

    // Notification channel setup
    init {
        NotificationHelper.createNotificationChannels(application)
        loadShopInfo()
        loadBackupSettings()
        // If setup is complete, start on PIN lock
        if (pinManager.isSetupComplete()) {
            _currentScreen.value = AppScreen.PIN_LOCK
        } else {
            _currentScreen.value = AppScreen.FIRST_SETUP
        }
    }

    // Navigation
    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            screenStack.push(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (!screenStack.isEmpty()) {
            val prev = screenStack.pop()
            _currentScreen.value = prev
            return true
        } else if (_currentScreen.value != AppScreen.DASHBOARD && _currentScreen.value != AppScreen.PIN_LOCK) {
            _currentScreen.value = AppScreen.DASHBOARD
            return true
        }
        return false
    }

    // PIN State
    val enteredPin = MutableStateFlow("")
    val pinError = MutableStateFlow<String?>(null)
    val isLockedOut = MutableStateFlow(false)
    val lockoutSeconds = MutableStateFlow(0)

    // Setup Flow
    val setupStep = MutableStateFlow(1) // 1: Shop Info, 2: 4-digit PIN, 3: Confirm PIN, 4: Recovery Question
    val setupShopName = MutableStateFlow("")
    val setupOwnerPhone = MutableStateFlow("")
    val setupPin1 = MutableStateFlow("")
    val setupPin2 = MutableStateFlow("")
    val setupSecurityQuestion = MutableStateFlow("আপনার প্রিয় খাবার বা শৈশবের স্কুলের নাম কি?")
    val setupSecurityAnswer = MutableStateFlow("")

    fun onPinDigit(digit: String) {
        if (pinManager.isLockedOut()) {
            isLockedOut.value = true
            lockoutSeconds.value = pinManager.getRemainingLockoutSeconds()
            pinError.value = "অতিরিক্ত ভুল চেষ্টার কারণে ${lockoutSeconds.value} সেকেন্ডের জন্য লক করা হয়েছে।"
            return
        }
        if (enteredPin.value.length < 4) {
            enteredPin.value += digit
            if (enteredPin.value.length == 4) {
                verifyUnlockPin(enteredPin.value)
            }
        }
    }

    fun onPinBackspace() {
        if (enteredPin.value.isNotEmpty()) {
            enteredPin.value = enteredPin.value.dropLast(1)
            pinError.value = null
        }
    }

    private fun verifyUnlockPin(pin: String) {
        if (pinManager.verifyPin(pin)) {
            enteredPin.value = ""
            pinError.value = null
            _currentScreen.value = AppScreen.DASHBOARD
        } else {
            enteredPin.value = ""
            if (pinManager.isLockedOut()) {
                isLockedOut.value = true
                lockoutSeconds.value = pinManager.getRemainingLockoutSeconds()
                pinError.value = "ভুল পিন! অতিরিক্ত ভুলের কারণে ${lockoutSeconds.value} সেকেন্ড লক করা হয়েছে।"
            } else {
                val attempts = pinManager.getFailedAttempts()
                pinError.value = "ভুল পিন নম্বর! আবার চেষ্টা করুন (ভুল প্রচেষ্টা: $attempts/5)"
            }
        }
    }

    fun unlockWithRecovery(answer: String): Boolean {
        if (pinManager.verifyRecoveryAnswer(answer)) {
            enteredPin.value = ""
            pinError.value = null
            isLockedOut.value = false
            _currentScreen.value = AppScreen.DASHBOARD
            return true
        }
        return false
    }

    fun completeSetup(): Boolean {
        if (setupPin1.value != setupPin2.value || setupPin1.value.length != 4) {
            return false
        }
        val pinSet = pinManager.setPin(setupPin1.value)
        if (!pinSet) return false

        pinManager.setRecoveryQuestion(setupSecurityQuestion.value, setupSecurityAnswer.value)

        viewModelScope.launch {
            repository.setSetting("shop_name", setupShopName.value.ifBlank { "আমার ওষুধের খাতা" })
            repository.setSetting("shop_phone", setupOwnerPhone.value)

            // Seed initial common medicine inventory if empty
            val currentMeds = repository.medicineDao.getAllMedicinesSync()
            if (currentMeds.isEmpty()) {
                val sampleMeds = listOf(
                    Medicine(
                        name = "Napa Extra",
                        genericName = "Paracetamol + Caffeine",
                        company = "Beximco Pharma",
                        category = "ট্যাবলেট",
                        strength = "500mg+65mg",
                        purchasePrice = 2.50,
                        sellingPrice = 3.00,
                        currentStock = 150.0,
                        minStockLevel = 30.0,
                        batchNumber = "BX-2026A",
                        expiryDate = System.currentTimeMillis() + (365L * 24 * 3600 * 1000)
                    ),
                    Medicine(
                        name = "Seclo 20mg",
                        genericName = "Omeprazole",
                        company = "Square Pharmaceuticals",
                        category = "ক্যাপসুল",
                        strength = "20mg",
                        purchasePrice = 5.00,
                        sellingPrice = 6.00,
                        currentStock = 100.0,
                        minStockLevel = 20.0,
                        batchNumber = "SQ-901B",
                        expiryDate = System.currentTimeMillis() + (180L * 24 * 3600 * 1000)
                    ),
                    Medicine(
                        name = "Ace Plus",
                        genericName = "Paracetamol + Caffeine",
                        company = "Square Pharmaceuticals",
                        category = "ট্যাবলেট",
                        strength = "500mg+65mg",
                        purchasePrice = 2.50,
                        sellingPrice = 3.00,
                        currentStock = 120.0,
                        minStockLevel = 25.0,
                        batchNumber = "SQ-440C",
                        expiryDate = System.currentTimeMillis() + (400L * 24 * 3600 * 1000)
                    ),
                    Medicine(
                        name = "Maxpro 20mg",
                        genericName = "Esomeprazole",
                        company = "Renata Limited",
                        category = "ট্যাবলেট",
                        strength = "20mg",
                        purchasePrice = 6.00,
                        sellingPrice = 7.50,
                        currentStock = 8.0, // Low stock on purpose to demonstrate alert!
                        minStockLevel = 20.0,
                        batchNumber = "RN-812D",
                        expiryDate = System.currentTimeMillis() + (20L * 24 * 3600 * 1000) // Near expiry to demonstrate alert!
                    )
                )
                sampleMeds.forEach { repository.insertMedicine(it) }

                // Seed initial customer with existing due
                repository.insertCustomer(
                    Customer(
                        name = "মোঃ রফিকুল ইসলাম",
                        phone = "01711223344",
                        address = "ধানমন্ডি, ঢাকা",
                        openingDue = 500.0,
                        expectedPaymentDate = System.currentTimeMillis() + (2L * 24 * 3600 * 1000),
                        note = "নিয়মিত গ্রাহক"
                    )
                )
                repository.insertCustomer(
                    Customer(
                        name = "আবুল কালাম আজাদ",
                        phone = "01819334455",
                        address = "মিরপুর-১০, ঢাকা",
                        openingDue = 0.0,
                        note = ""
                    )
                )
            }

            loadShopInfo()
            _currentScreen.value = AppScreen.DASHBOARD
        }
        return true
    }

    // Shop Info & Settings
    val shopInfo = MutableStateFlow(ShopInfo())

    private fun loadShopInfo() {
        viewModelScope.launch {
            val name = repository.getSetting("shop_name", "আমার ওষুধের খাতা")
            val owner = repository.getSetting("shop_owner", "")
            val phone = repository.getSetting("shop_phone", "")
            val address = repository.getSetting("shop_address", "")
            val footer = repository.getSetting("receipt_footer", "আমাদের সাথে থাকার জন্য ধন্যবাদ। সুস্থ থাকুন।")
            shopInfo.value = ShopInfo(name, owner, phone, address, footer)
        }
    }

    fun updateShopInfo(name: String, owner: String, phone: String, address: String, footer: String) {
        viewModelScope.launch {
            repository.setSetting("shop_name", name)
            repository.setSetting("shop_owner", owner)
            repository.setSetting("shop_phone", phone)
            repository.setSetting("shop_address", address)
            repository.setSetting("receipt_footer", footer)
            loadShopInfo()
        }
    }

    // Google Drive & Backup Settings
    val isDriveBackupEnabled = MutableStateFlow(false)
    val isDriveConnected = MutableStateFlow(false)
    val lastBackupText = MutableStateFlow("এখনো ব্যাকআপ নেওয়া হয়নি")
    val backupOperationStatus = MutableStateFlow<String?>(null)
    val backupPreview = MutableStateFlow<BackupPreview?>(null)

    private fun loadBackupSettings() {
        viewModelScope.launch {
            val driveEnabled = repository.getSetting("drive_backup_enabled", "false").toBoolean()
            val driveConnected = repository.getSetting("drive_connected", "false").toBoolean()
            val lastTimeStr = repository.getSetting("last_backup_time", "")
            isDriveBackupEnabled.value = driveEnabled
            isDriveConnected.value = driveConnected

            if (lastTimeStr.isNotBlank()) {
                val time = lastTimeStr.toLongOrNull() ?: 0L
                if (time > 0) {
                    val formatted = FormatHelper.formatDateTime(time)
                    lastBackupText.value = formatted
                }
            }
        }
    }

    fun setDriveBackupToggle(enabled: Boolean) {
        isDriveBackupEnabled.value = enabled
        viewModelScope.launch {
            repository.setSetting("drive_backup_enabled", enabled.toString())
        }
    }

    fun connectGoogleDrive(accountEmail: String = "user@gmail.com") {
        isDriveConnected.value = true
        viewModelScope.launch {
            repository.setSetting("drive_connected", "true")
            repository.setSetting("drive_account", accountEmail)
            backupOperationStatus.value = "গুগল ড্রাইভ সফলভাবে সংযুক্ত হয়েছে ($accountEmail)"
        }
    }

    fun performBackupNow() {
        viewModelScope.launch {
            try {
                val file = backupManager.saveBackupToLocalFile()
                val nowFormatted = FormatHelper.formatDateTime(System.currentTimeMillis())
                lastBackupText.value = nowFormatted
                backupOperationStatus.value = "ব্যাকআপ সফল হয়েছে! (${file.name})"
                NotificationHelper.showBackupNotification(
                    getApplication(),
                    true,
                    "ডাটা ব্যাকআপ সফলভাবে সম্পন্ন হয়েছে ($nowFormatted)"
                )
            } catch (e: Exception) {
                backupOperationStatus.value = "ব্যাকআপ করতে সমস্যা হয়েছে: ${e.localizedMessage}"
                NotificationHelper.showBackupNotification(
                    getApplication(),
                    false,
                    "ব্যাকআপ ব্যর্থ হয়েছে। ইন্টারনেট বা স্টোরেজ চেক করুন।"
                )
            }
        }
    }

    fun prepareRestoreFromJson(json: String): Boolean {
        val preview = backupManager.inspectBackupJson(json)
        backupPreview.value = preview
        return preview != null
    }

    fun confirmRestoreBackup() {
        val preview = backupPreview.value ?: return
        viewModelScope.launch {
            val success = backupManager.restoreFromJson(preview.rawJson)
            if (success) {
                backupOperationStatus.value = "ডাটা সফলভাবে রিস্টোর হয়েছে!"
                backupPreview.value = null
            } else {
                backupOperationStatus.value = "রিস্টোর ব্যর্থ হয়েছে! ফাইলটি সঠিক কিনা যাচাই করুন।"
            }
        }
    }

    // Customers Data Flow
    val allCustomers = repository.getAllCustomers().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Medicines Data Flow
    val allMedicines = repository.getAllMedicines().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Sales Data Flow
    val allSales = repository.getAllSales().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Payments Data Flow
    val allPayments = repository.getAllPayments().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Suppliers Data Flow
    val allSuppliers = repository.getAllSuppliers().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Purchases Data Flow
    val allPurchases = repository.stockDao.getAllPurchases().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Returns Data Flow
    val allReturns = repository.stockDao.getAllReturns().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Dashboard Statistics Calculation
    val dashboardStats: StateFlow<DashboardStats> = combine(
        allSales,
        allPayments,
        allCustomers,
        allMedicines
    ) { sales, payments, customers, medicines ->
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startOfDay = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        val endOfDay = cal.timeInMillis

        val todaySalesList = sales.filter { it.saleDate in startOfDay..endOfDay }
        val todaySalesTotal = todaySalesList.sumOf { it.grandTotal }
        val todaySalePayments = todaySalesList.sumOf { it.paidAmount }
        val todayNewDue = todaySalesList.sumOf { it.dueAmount }

        val todayDirectPayments = payments.filter { it.paymentDate in startOfDay..endOfDay }.sumOf { it.amount }
        val todayCollection = todaySalePayments + todayDirectPayments

        // Calculate total due across all customers
        var totalOutstandingDue = 0.0
        var overdueCount = 0
        for (c in customers) {
            val cSales = sales.filter { it.customerId == c.id }
            val cPayments = payments.filter { it.customerId == c.id }
            val totalCustomerDue = (c.openingDue + cSales.sumOf { it.grandTotal }) -
                    (cSales.sumOf { it.paidAmount } + cPayments.sumOf { it.amount })
            if (totalCustomerDue > 0) {
                totalOutstandingDue += totalCustomerDue
                if (c.expectedPaymentDate != null && c.expectedPaymentDate <= endOfDay) {
                    overdueCount++
                }
            }
        }

        val lowStockMedicines = medicines.filter { it.currentStock <= it.minStockLevel }
        val thirtyDaysFromNow = System.currentTimeMillis() + (30L * 24 * 3600 * 1000)
        val expiredMedicines = medicines.filter { it.expiryDate in 1..thirtyDaysFromNow }

        DashboardStats(
            todaySales = todaySalesTotal,
            todayCollection = todayCollection,
            todayNewDue = todayNewDue,
            totalOutstandingDue = totalOutstandingDue,
            totalCustomerCount = customers.size,
            totalMedicineCount = medicines.size,
            totalStockQuantity = medicines.sumOf { it.currentStock },
            lowStockCount = lowStockMedicines.size,
            expiredCount = expiredMedicines.size,
            dueRemindersCount = overdueCount
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardStats())

    // Selected Customer Details
    val selectedCustomerId = MutableStateFlow<Long?>(null)
    val selectedCustomer = selectedCustomerId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getCustomerByIdFlow(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedCustomerLedger = MutableStateFlow<List<CustomerLedgerEntry>>(emptyList())
    val selectedCustomerSummary = MutableStateFlow<CustomerFinancialSummary?>(null)

    fun selectCustomer(customerId: Long) {
        selectedCustomerId.value = customerId
        refreshSelectedCustomer()
        navigateTo(AppScreen.CUSTOMER_DETAIL)
    }

    fun refreshSelectedCustomer() {
        val id = selectedCustomerId.value ?: return
        viewModelScope.launch {
            selectedCustomerLedger.value = repository.getCustomerLedger(id)
            selectedCustomerSummary.value = repository.getCustomerFinancialSummary(id)
        }
    }

    // Selected Medicine Details
    val selectedMedicineId = MutableStateFlow<Long?>(null)
    val selectedMedicine = selectedMedicineId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getMedicineByIdFlow(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedMedicineTransactions = selectedMedicineId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.getTransactionsForMedicine(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectMedicine(medicineId: Long) {
        selectedMedicineId.value = medicineId
        navigateTo(AppScreen.MEDICINE_DETAIL)
    }

    // Cart / New Sale State
    val cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val saleCustomer = MutableStateFlow<Customer?>(null)
    val saleDiscount = MutableStateFlow(0.0)
    val salePaidAmount = MutableStateFlow(0.0)
    val saleDate = MutableStateFlow(System.currentTimeMillis())
    val saleNote = MutableStateFlow("")

    val cartSubtotal: StateFlow<Double> = cartItems.map { list ->
        list.sumOf { it.totalPrice }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val cartGrandTotal: StateFlow<Double> = combine(cartSubtotal, saleDiscount) { sub, disc ->
        (sub - disc).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val cartDueAmount: StateFlow<Double> = combine(cartGrandTotal, salePaidAmount) { grand, paid ->
        (grand - paid).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun clearCart() {
        cartItems.value = emptyList()
        saleCustomer.value = null
        saleDiscount.value = 0.0
        salePaidAmount.value = 0.0
        saleDate.value = System.currentTimeMillis()
        saleNote.value = ""
    }

    fun addMedicineToCart(medicine: Medicine) {
        val current = cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.medicine.id == medicine.id }
        if (index >= 0) {
            val item = current[index]
            current[index] = item.copy(quantity = item.quantity + 1.0)
        } else {
            current.add(
                CartItem(
                    medicine = medicine,
                    quantity = 1.0,
                    unitPrice = medicine.sellingPrice,
                    purchasePrice = medicine.purchasePrice
                )
            )
        }
        cartItems.value = current
    }

    fun updateCartItemQuantity(medicineId: Long, newQuantity: Double) {
        if (newQuantity <= 0) {
            cartItems.value = cartItems.value.filter { it.medicine.id != medicineId }
        } else {
            cartItems.value = cartItems.value.map {
                if (it.medicine.id == medicineId) it.copy(quantity = newQuantity) else it
            }
        }
    }

    fun updateCartItemUnitPrice(medicineId: Long, newPrice: Double) {
        cartItems.value = cartItems.value.map {
            if (it.medicine.id == medicineId) it.copy(unitPrice = newPrice) else it
        }
    }

    // Receipt Preview State
    val previewReceiptPdf = MutableStateFlow<File?>(null)
    val previewReceiptTitle = MutableStateFlow("রসিদ")

    fun completeSaleAndOpenReceipt(onSuccess: (Long) -> Unit) {
        val items = cartItems.value
        if (items.isEmpty()) return

        val subtotal = cartSubtotal.value
        val discount = saleDiscount.value
        val grandTotal = cartGrandTotal.value
        val paid = salePaidAmount.value
        val due = cartDueAmount.value
        val customer = saleCustomer.value

        viewModelScope.launch {
            val receiptNo = repository.generateReceiptNumber("INV")
            val sale = Sale(
                receiptNumber = receiptNo,
                customerId = customer?.id,
                customerName = customer?.name ?: "নগদ ক্রেতা",
                customerPhone = customer?.phone ?: "",
                subtotal = subtotal,
                discount = discount,
                grandTotal = grandTotal,
                paidAmount = paid,
                dueAmount = due,
                saleDate = saleDate.value,
                note = saleNote.value
            )

            val saleItems = items.map {
                SaleItem(
                    saleId = 0,
                    medicineId = it.medicine.id,
                    medicineName = it.medicine.name,
                    quantity = it.quantity,
                    unitPrice = it.unitPrice,
                    purchasePrice = it.purchasePrice,
                    totalPrice = it.totalPrice
                )
            }

            val saleId = repository.createSale(sale, saleItems)

            // Generate PDF receipt
            val prevDue = if (customer != null) repository.calculateCustomerDue(customer.id) - due else 0.0
            val currentDue = prevDue + due
            val pdfFile = PdfGenerator.generateSaleReceiptPdf(
                context = getApplication(),
                sale = sale.copy(id = saleId),
                items = saleItems,
                shopInfo = shopInfo.value,
                previousDue = prevDue,
                currentDue = currentDue
            )

            previewReceiptPdf.value = pdfFile
            previewReceiptTitle.value = "বিক্রি চালান #${receiptNo}"
            clearCart()
            navigateTo(AppScreen.RECEIPT_PREVIEW)
            onSuccess(saleId)
        }
    }

    // Payment Collection Flow
    fun recordCustomerPayment(
        customer: Customer,
        amount: Double,
        method: String,
        date: Long,
        note: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val receiptNo = repository.generateReceiptNumber("PAY")
            val payment = Payment(
                receiptNumber = receiptNo,
                customerId = customer.id,
                amount = amount,
                paymentDate = date,
                paymentMethod = method,
                note = note
            )
            val paymentId = repository.recordPayment(payment)
            val prevDue = repository.calculateCustomerDue(customer.id) + amount
            val currentDue = prevDue - amount

            val pdf = PdfGenerator.generatePaymentReceiptPdf(
                context = getApplication(),
                payment = payment.copy(id = paymentId),
                customer = customer,
                shopInfo = shopInfo.value,
                previousDue = prevDue,
                currentDue = currentDue
            )

            previewReceiptPdf.value = pdf
            previewReceiptTitle.value = "মানি রিসিট #${receiptNo}"
            refreshSelectedCustomer()
            navigateTo(AppScreen.RECEIPT_PREVIEW)
            onSuccess()
        }
    }

    // ==========================================
    // MEDICINE CHALLAN (ওষুধের চালান) SYSTEM
    // ==========================================

    val allChallans = repository.getAllChallans().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val editingChallanId = MutableStateFlow<Long?>(null)
    val challanNumber = MutableStateFlow("")
    val challanCustomer = MutableStateFlow<Customer?>(null)
    val challanCustomerName = MutableStateFlow("সাধারণ ক্রেতা")
    val challanCustomerPhone = MutableStateFlow("")
    val challanCustomerAddress = MutableStateFlow("")
    val challanDate = MutableStateFlow(System.currentTimeMillis())
    val challanRows = MutableStateFlow<List<ChallanRowState>>(listOf(ChallanRowState(serialNumber = 1)))
    val challanPaidAmount = MutableStateFlow(0.0)
    val challanNote = MutableStateFlow("")

    val challanGrossTotal: StateFlow<Double> = challanRows.map { rows ->
        rows.sumOf { it.basePrice }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val challanTotalDiscount: StateFlow<Double> = challanRows.map { rows ->
        rows.sumOf { it.discountAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val challanGrandTotal: StateFlow<Double> = challanRows.map { rows ->
        rows.sumOf { it.netTotal }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val challanDueAmount: StateFlow<Double> = combine(challanGrandTotal, challanPaidAmount) { grand, paid ->
        (grand - paid).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val selectedChallanId = MutableStateFlow<Long?>(null)
    val selectedChallan: StateFlow<Challan?> = selectedChallanId.flatMapLatest { id ->
        if (id == null) flowOf<Challan?>(null) else flow { emit(repository.getChallanById(id)) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedChallanItems = selectedChallanId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.getChallanItems(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isDraftChallanPreview = MutableStateFlow(false)
    val postSaveChallan = MutableStateFlow<Challan?>(null)
    val showPostSaveDialog = MutableStateFlow(false)

    fun previewDraftChallan() {
        isDraftChallanPreview.value = true
        navigateTo(AppScreen.CHALLAN_PREVIEW)
    }

    fun previewSavedChallan(challanId: Long) {
        isDraftChallanPreview.value = false
        selectedChallanId.value = challanId
        navigateTo(AppScreen.CHALLAN_PREVIEW)
    }

    fun startNewChallan() {
        editingChallanId.value = null
        challanNumber.value = repository.generateChallanNumber()
        challanCustomer.value = null
        challanCustomerName.value = "সাধারণ ক্রেতা"
        challanCustomerPhone.value = ""
        challanCustomerAddress.value = ""
        challanDate.value = System.currentTimeMillis()
        challanRows.value = listOf(ChallanRowState(serialNumber = 1))
        challanPaidAmount.value = 0.0
        challanNote.value = ""
        navigateTo(AppScreen.NEW_CHALLAN)
    }

    fun addChallanRow(medicine: Medicine? = null) {
        val current = challanRows.value.toMutableList()
        val nextSerial = current.size + 1
        if (medicine != null) {
            current.add(
                ChallanRowState(
                    serialNumber = nextSerial,
                    medicineId = medicine.id,
                    medicineName = medicine.name,
                    companyName = medicine.company,
                    piecesPerBox = 100,
                    boxQuantity = 1.0,
                    boxPrice = medicine.sellingPrice * 100, // Box price based on unit price
                    discountPercent = 0.0
                )
            )
        } else {
            current.add(
                ChallanRowState(
                    serialNumber = nextSerial,
                    medicineId = 0,
                    medicineName = "",
                    companyName = "",
                    piecesPerBox = 100,
                    boxQuantity = 1.0,
                    boxPrice = 0.0,
                    discountPercent = 0.0
                )
            )
        }
        challanRows.value = current
    }

    fun removeChallanRow(index: Int) {
        val current = challanRows.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            // Re-index serial numbers
            val reIndexed = current.mapIndexed { idx, row ->
                row.copy(serialNumber = idx + 1)
            }
            challanRows.value = if (reIndexed.isEmpty()) listOf(ChallanRowState(serialNumber = 1)) else reIndexed
        }
    }

    fun updateChallanRow(index: Int, updated: ChallanRowState) {
        val current = challanRows.value.toMutableList()
        if (index in current.indices) {
            current[index] = updated
            challanRows.value = current
        }
    }

    fun selectChallan(id: Long) {
        selectedChallanId.value = id
        navigateTo(AppScreen.CHALLAN_DETAIL)
    }

    fun editExistingChallan(challanId: Long) {
        viewModelScope.launch {
            val ch = repository.getChallanById(challanId) ?: return@launch
            val items = repository.getChallanItemsSync(challanId)
            editingChallanId.value = ch.id
            challanNumber.value = ch.challanNumber
            challanCustomer.value = if (ch.customerId != null) repository.getCustomerById(ch.customerId) else null
            challanCustomerName.value = ch.customerName
            challanCustomerPhone.value = ch.customerPhone
            challanCustomerAddress.value = ch.customerAddress
            challanDate.value = ch.challanDate
            challanPaidAmount.value = ch.paidAmount
            challanNote.value = ch.note
            challanRows.value = items.map {
                ChallanRowState(
                    id = it.id,
                    serialNumber = it.serialNumber,
                    medicineId = it.medicineId,
                    medicineName = it.medicineName,
                    companyName = it.companyName,
                    piecesPerBox = it.piecesPerBox,
                    boxQuantity = it.boxQuantity,
                    boxPrice = it.boxPrice,
                    discountPercent = it.discountPercent
                )
            }.ifEmpty { listOf(ChallanRowState(serialNumber = 1)) }
            navigateTo(AppScreen.NEW_CHALLAN)
        }
    }

    fun saveChallanOffline(onSuccess: (Long) -> Unit) {
        val rows = challanRows.value.filter { it.medicineName.isNotBlank() }
        if (rows.isEmpty()) return

        val gross = challanGrossTotal.value
        val discount = challanTotalDiscount.value
        val grand = challanGrandTotal.value
        val paid = challanPaidAmount.value
        val due = challanDueAmount.value
        val customer = challanCustomer.value
        val cName = customer?.name ?: challanCustomerName.value.ifBlank { "সাধারণ ক্রেতা" }
        val cPhone = customer?.phone ?: challanCustomerPhone.value
        val cAddress = customer?.address ?: challanCustomerAddress.value

        val existingId = editingChallanId.value

        viewModelScope.launch {
            val challanObj = Challan(
                id = existingId ?: 0L,
                challanNumber = challanNumber.value.ifBlank { repository.generateChallanNumber() },
                customerId = customer?.id,
                customerName = cName,
                customerPhone = cPhone,
                customerAddress = cAddress,
                grossTotal = gross,
                totalDiscount = discount,
                grandTotal = grand,
                paidAmount = paid,
                dueAmount = due,
                challanDate = challanDate.value,
                note = challanNote.value
            )

            val challanItems = rows.mapIndexed { idx, r ->
                ChallanItem(
                    challanId = existingId ?: 0L,
                    serialNumber = idx + 1,
                    medicineId = r.medicineId,
                    medicineName = r.medicineName,
                    companyName = r.companyName,
                    piecesPerBox = r.piecesPerBox,
                    boxQuantity = r.boxQuantity,
                    totalPieces = r.totalPieces,
                    boxPrice = r.boxPrice,
                    discountPercent = r.discountPercent,
                    discountAmount = r.discountAmount,
                    netTotal = r.netTotal
                )
            }

            val savedId = if (existingId != null && existingId > 0) {
                repository.updateChallanTransaction(challanObj, challanItems)
                existingId
            } else {
                repository.saveChallan(challanObj, challanItems)
            }

            // Generate and open PDF
            val prevDue = if (customer != null) repository.calculateCustomerDue(customer.id) - due else 0.0
            val currentDue = prevDue + due

            val pdf = PdfGenerator.generateChallanPdf(
                context = getApplication(),
                challan = challanObj.copy(id = savedId),
                items = challanItems,
                shopInfo = shopInfo.value,
                previousDue = prevDue,
                currentDue = currentDue
            )

            previewReceiptPdf.value = pdf
            previewReceiptTitle.value = "ওষুধের চালান #${challanObj.challanNumber}"
            selectedChallanId.value = savedId
            isDraftChallanPreview.value = false
            postSaveChallan.value = challanObj.copy(id = savedId)
            showPostSaveDialog.value = true

            if (customer != null) {
                refreshSelectedCustomer()
            }

            onSuccess(savedId)
        }
    }

    fun cancelChallan(challanId: Long, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.cancelChallan(challanId)
            navigateBack()
            onDone()
        }
    }

    fun saveChallanPdfToPhone(challanId: Long, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val ch = repository.getChallanById(challanId) ?: return@launch
            val items = repository.getChallanItemsSync(challanId)
            val prevDue = if (ch.customerId != null) repository.calculateCustomerDue(ch.customerId) - ch.dueAmount else 0.0
            val pdf = PdfGenerator.generateChallanPdf(
                context = getApplication(),
                challan = ch,
                items = items,
                shopInfo = shopInfo.value,
                previousDue = prevDue,
                currentDue = prevDue + ch.dueAmount
            )
            val result = PdfGenerator.savePdfToPhoneStorage(
                context = getApplication(),
                sourceFile = pdf,
                targetFileName = "Challan_${ch.challanNumber}.pdf"
            )
            onResult(result.second)
        }
    }

    fun printSavedChallan(challanId: Long, context: android.content.Context) {
        viewModelScope.launch {
            val ch = repository.getChallanById(challanId) ?: return@launch
            val items = repository.getChallanItemsSync(challanId)
            val prevDue = if (ch.customerId != null) repository.calculateCustomerDue(ch.customerId) - ch.dueAmount else 0.0
            val pdf = PdfGenerator.generateChallanPdf(
                context = context,
                challan = ch,
                items = items,
                shopInfo = shopInfo.value,
                previousDue = prevDue,
                currentDue = prevDue + ch.dueAmount
            )
            PdfGenerator.printPdf(context, pdf, "Challan_${ch.challanNumber}")
        }
    }

    fun shareSavedChallan(challanId: Long, context: android.content.Context) {
        viewModelScope.launch {
            val ch = repository.getChallanById(challanId) ?: return@launch
            val items = repository.getChallanItemsSync(challanId)
            val prevDue = if (ch.customerId != null) repository.calculateCustomerDue(ch.customerId) - ch.dueAmount else 0.0
            val pdf = PdfGenerator.generateChallanPdf(
                context = context,
                challan = ch,
                items = items,
                shopInfo = shopInfo.value,
                previousDue = prevDue,
                currentDue = prevDue + ch.dueAmount
            )
            PdfGenerator.sharePdf(context, pdf, "চালান #${ch.challanNumber} শেয়ার করুন")
        }
    }

    fun printDraftChallan(context: android.content.Context) {
        viewModelScope.launch {
            val rows = challanRows.value.filter { it.medicineName.isNotBlank() }
            val customer = challanCustomer.value
            val cName = customer?.name ?: challanCustomerName.value.ifBlank { "সাধারণ ক্রেতা" }
            val cPhone = customer?.phone ?: challanCustomerPhone.value
            val cAddress = customer?.address ?: challanCustomerAddress.value
            val gross = challanGrossTotal.value
            val discount = challanTotalDiscount.value
            val grand = challanGrandTotal.value
            val paid = challanPaidAmount.value
            val due = challanDueAmount.value

            val tempChallan = Challan(
                challanNumber = challanNumber.value.ifBlank { "CH-DRAFT" },
                customerId = customer?.id,
                customerName = cName,
                customerPhone = cPhone,
                customerAddress = cAddress,
                grossTotal = gross,
                totalDiscount = discount,
                grandTotal = grand,
                paidAmount = paid,
                dueAmount = due,
                challanDate = challanDate.value
            )

            val tempItems = rows.mapIndexed { idx, r ->
                ChallanItem(
                    challanId = 0,
                    serialNumber = idx + 1,
                    medicineId = r.medicineId,
                    medicineName = r.medicineName,
                    companyName = r.companyName,
                    piecesPerBox = r.piecesPerBox,
                    boxQuantity = r.boxQuantity,
                    totalPieces = r.totalPieces,
                    boxPrice = r.boxPrice,
                    discountPercent = r.discountPercent,
                    discountAmount = r.discountAmount,
                    netTotal = r.netTotal
                )
            }

            val prevDue = if (customer != null) repository.calculateCustomerDue(customer.id) else 0.0
            val pdf = PdfGenerator.generateChallanPdf(
                context = context,
                challan = tempChallan,
                items = tempItems,
                shopInfo = shopInfo.value,
                previousDue = prevDue,
                currentDue = prevDue + due
            )
            PdfGenerator.printPdf(context, pdf, "Challan_Draft_${tempChallan.challanNumber}")
        }
    }

    fun shareDraftChallan(context: android.content.Context) {
        viewModelScope.launch {
            val rows = challanRows.value.filter { it.medicineName.isNotBlank() }
            val customer = challanCustomer.value
            val cName = customer?.name ?: challanCustomerName.value.ifBlank { "সাধারণ ক্রেতা" }
            val cPhone = customer?.phone ?: challanCustomerPhone.value
            val cAddress = customer?.address ?: challanCustomerAddress.value
            val gross = challanGrossTotal.value
            val discount = challanTotalDiscount.value
            val grand = challanGrandTotal.value
            val paid = challanPaidAmount.value
            val due = challanDueAmount.value

            val tempChallan = Challan(
                challanNumber = challanNumber.value.ifBlank { "CH-DRAFT" },
                customerId = customer?.id,
                customerName = cName,
                customerPhone = cPhone,
                customerAddress = cAddress,
                grossTotal = gross,
                totalDiscount = discount,
                grandTotal = grand,
                paidAmount = paid,
                dueAmount = due,
                challanDate = challanDate.value
            )

            val tempItems = rows.mapIndexed { idx, r ->
                ChallanItem(
                    challanId = 0,
                    serialNumber = idx + 1,
                    medicineId = r.medicineId,
                    medicineName = r.medicineName,
                    companyName = r.companyName,
                    piecesPerBox = r.piecesPerBox,
                    boxQuantity = r.boxQuantity,
                    totalPieces = r.totalPieces,
                    boxPrice = r.boxPrice,
                    discountPercent = r.discountPercent,
                    discountAmount = r.discountAmount,
                    netTotal = r.netTotal
                )
            }

            val prevDue = if (customer != null) repository.calculateCustomerDue(customer.id) else 0.0
            val pdf = PdfGenerator.generateChallanPdf(
                context = context,
                challan = tempChallan,
                items = tempItems,
                shopInfo = shopInfo.value,
                previousDue = prevDue,
                currentDue = prevDue + due
            )
            PdfGenerator.sharePdf(context, pdf, "চালান #${tempChallan.challanNumber} শেয়ার করুন")
        }
    }

    fun saveDraftPdfToPhone(context: android.content.Context, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val rows = challanRows.value.filter { it.medicineName.isNotBlank() }
            val customer = challanCustomer.value
            val cName = customer?.name ?: challanCustomerName.value.ifBlank { "সাধারণ ক্রেতা" }
            val cPhone = customer?.phone ?: challanCustomerPhone.value
            val cAddress = customer?.address ?: challanCustomerAddress.value
            val gross = challanGrossTotal.value
            val discount = challanTotalDiscount.value
            val grand = challanGrandTotal.value
            val paid = challanPaidAmount.value
            val due = challanDueAmount.value

            val tempChallan = Challan(
                challanNumber = challanNumber.value.ifBlank { repository.generateChallanNumber() },
                customerId = customer?.id,
                customerName = cName,
                customerPhone = cPhone,
                customerAddress = cAddress,
                grossTotal = gross,
                totalDiscount = discount,
                grandTotal = grand,
                paidAmount = paid,
                dueAmount = due,
                challanDate = challanDate.value
            )

            val tempItems = rows.mapIndexed { idx, r ->
                ChallanItem(
                    challanId = 0,
                    serialNumber = idx + 1,
                    medicineId = r.medicineId,
                    medicineName = r.medicineName,
                    companyName = r.companyName,
                    piecesPerBox = r.piecesPerBox,
                    boxQuantity = r.boxQuantity,
                    totalPieces = r.totalPieces,
                    boxPrice = r.boxPrice,
                    discountPercent = r.discountPercent,
                    discountAmount = r.discountAmount,
                    netTotal = r.netTotal
                )
            }

            val prevDue = if (customer != null) repository.calculateCustomerDue(customer.id) else 0.0
            val pdf = PdfGenerator.generateChallanPdf(
                context = context,
                challan = tempChallan,
                items = tempItems,
                shopInfo = shopInfo.value,
                previousDue = prevDue,
                currentDue = prevDue + due
            )
            val result = PdfGenerator.savePdfToPhoneStorage(
                context = context,
                sourceFile = pdf,
                targetFileName = "Challan_${tempChallan.challanNumber}.pdf"
            )
            onResult(result.second)
        }
    }
}

