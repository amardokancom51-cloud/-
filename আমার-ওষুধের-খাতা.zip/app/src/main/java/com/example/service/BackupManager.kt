package com.example.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.data.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class BackupPreview(
    val timestamp: Long,
    val dateFormatted: String,
    val customerCount: Int,
    val medicineCount: Int,
    val saleCount: Int,
    val paymentCount: Int,
    val rawJson: String
)

class BackupManager(private val context: Context, private val database: AppDatabase) {

    fun isInternetAvailable(): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false
        return activeNetwork.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun createBackupJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("version", 1)
        root.put("appName", "আমার ওষুধের খাতা")
        root.put("backupTimestamp", System.currentTimeMillis())

        // Customers
        val customers = database.customerDao().searchCustomers("").let {
            // grab sync from db
            database.openHelper.readableDatabase.query("SELECT * FROM customers").use { cursor ->
                val list = mutableListOf<JSONObject>()
                while (cursor.moveToNext()) {
                    val obj = JSONObject()
                    for (i in 0 until cursor.columnCount) {
                        obj.put(cursor.getColumnName(i), cursor.getString(i))
                    }
                    list.add(obj)
                }
                list
            }
        }
        val customersArray = JSONArray()
        customers.forEach { customersArray.put(it) }
        root.put("customers", customersArray)

        // Medicines
        val medicines = database.openHelper.readableDatabase.query("SELECT * FROM medicines").use { cursor ->
            val list = mutableListOf<JSONObject>()
            while (cursor.moveToNext()) {
                val obj = JSONObject()
                for (i in 0 until cursor.columnCount) {
                    obj.put(cursor.getColumnName(i), cursor.getString(i))
                }
                list.add(obj)
            }
            list
        }
        val medicinesArray = JSONArray()
        medicines.forEach { medicinesArray.put(it) }
        root.put("medicines", medicinesArray)

        // Sales
        val sales = database.openHelper.readableDatabase.query("SELECT * FROM sales").use { cursor ->
            val list = mutableListOf<JSONObject>()
            while (cursor.moveToNext()) {
                val obj = JSONObject()
                for (i in 0 until cursor.columnCount) {
                    obj.put(cursor.getColumnName(i), cursor.getString(i))
                }
                list.add(obj)
            }
            list
        }
        val salesArray = JSONArray()
        sales.forEach { salesArray.put(it) }
        root.put("sales", salesArray)

        // Sale Items
        val saleItems = database.openHelper.readableDatabase.query("SELECT * FROM sale_items").use { cursor ->
            val list = mutableListOf<JSONObject>()
            while (cursor.moveToNext()) {
                val obj = JSONObject()
                for (i in 0 until cursor.columnCount) {
                    obj.put(cursor.getColumnName(i), cursor.getString(i))
                }
                list.add(obj)
            }
            list
        }
        val saleItemsArray = JSONArray()
        saleItems.forEach { saleItemsArray.put(it) }
        root.put("sale_items", saleItemsArray)

        // Payments
        val payments = database.openHelper.readableDatabase.query("SELECT * FROM payments").use { cursor ->
            val list = mutableListOf<JSONObject>()
            while (cursor.moveToNext()) {
                val obj = JSONObject()
                for (i in 0 until cursor.columnCount) {
                    obj.put(cursor.getColumnName(i), cursor.getString(i))
                }
                list.add(obj)
            }
            list
        }
        val paymentsArray = JSONArray()
        payments.forEach { paymentsArray.put(it) }
        root.put("payments", paymentsArray)

        // Challans
        val challans = database.openHelper.readableDatabase.query("SELECT * FROM challans").use { cursor ->
            val list = mutableListOf<JSONObject>()
            while (cursor.moveToNext()) {
                val obj = JSONObject()
                for (i in 0 until cursor.columnCount) {
                    obj.put(cursor.getColumnName(i), cursor.getString(i))
                }
                list.add(obj)
            }
            list
        }
        val challansArray = JSONArray()
        challans.forEach { challansArray.put(it) }
        root.put("challans", challansArray)

        // Challan Items
        val challanItems = database.openHelper.readableDatabase.query("SELECT * FROM challan_items").use { cursor ->
            val list = mutableListOf<JSONObject>()
            while (cursor.moveToNext()) {
                val obj = JSONObject()
                for (i in 0 until cursor.columnCount) {
                    obj.put(cursor.getColumnName(i), cursor.getString(i))
                }
                list.add(obj)
            }
            list
        }
        val challanItemsArray = JSONArray()
        challanItems.forEach { challanItemsArray.put(it) }
        root.put("challan_items", challanItemsArray)

        // Settings (Exclude sensitive security keys)
        val settings = database.settingDao().getAllSettings()
            .filter { !it.key.contains("pin", ignoreCase = true) && !it.key.contains("salt", ignoreCase = true) }
        val settingsArray = JSONArray()
        settings.forEach {
            val obj = JSONObject()
            obj.put("key", it.key)
            obj.put("value", it.value)
            settingsArray.put(obj)
        }
        root.put("settings", settingsArray)

        root.toString(2)
    }

    suspend fun saveBackupToLocalFile(): File = withContext(Dispatchers.IO) {
        val json = createBackupJson()
        val dir = File(context.filesDir, "backups").apply { if (!exists()) mkdirs() }
        val file = File(dir, "med_ledger_backup_${System.currentTimeMillis()}.json")
        file.writeText(json)

        // Update latest backup record
        database.settingDao().setSetting(
            AppSetting("last_backup_time", System.currentTimeMillis().toString())
        )
        database.settingDao().setSetting(
            AppSetting("last_backup_path", file.absolutePath)
        )
        file
    }

    fun inspectBackupJson(jsonString: String): BackupPreview? {
        return try {
            val root = JSONObject(jsonString)
            val timestamp = root.optLong("backupTimestamp", System.currentTimeMillis())
            val dateFormatted = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.US).format(Date(timestamp))
            val customerCount = root.optJSONArray("customers")?.length() ?: 0
            val medicineCount = root.optJSONArray("medicines")?.length() ?: 0
            val saleCount = root.optJSONArray("sales")?.length() ?: 0
            val paymentCount = root.optJSONArray("payments")?.length() ?: 0

            BackupPreview(
                timestamp = timestamp,
                dateFormatted = dateFormatted,
                customerCount = customerCount,
                medicineCount = medicineCount,
                saleCount = saleCount,
                paymentCount = paymentCount,
                rawJson = jsonString
            )
        } catch (e: Exception) {
            null
        }
    }

    suspend fun restoreFromJson(jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)

            val customersArray = root.optJSONArray("customers")
            if (customersArray != null) {
                database.customerDao().clearAll()
                for (i in 0 until customersArray.length()) {
                    val obj = customersArray.getJSONObject(i)
                    database.customerDao().insertCustomer(
                        Customer(
                            id = obj.optLong("id", 0),
                            name = obj.optString("name", ""),
                            phone = obj.optString("phone", ""),
                            address = obj.optString("address", ""),
                            note = obj.optString("note", ""),
                            openingDue = obj.optDouble("openingDue", 0.0),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            expectedPaymentDate = if (obj.has("expectedPaymentDate") && !obj.isNull("expectedPaymentDate")) obj.optLong("expectedPaymentDate") else null,
                            expectedPaymentNote = obj.optString("expectedPaymentNote", ""),
                            isArchived = obj.optBoolean("isArchived", false)
                        )
                    )
                }
            }

            val medicinesArray = root.optJSONArray("medicines")
            if (medicinesArray != null) {
                database.medicineDao().clearAll()
                for (i in 0 until medicinesArray.length()) {
                    val obj = medicinesArray.getJSONObject(i)
                    database.medicineDao().insertMedicine(
                        Medicine(
                            id = obj.optLong("id", 0),
                            name = obj.optString("name", ""),
                            genericName = obj.optString("genericName", ""),
                            company = obj.optString("company", ""),
                            category = obj.optString("category", "ট্যাবলেট"),
                            strength = obj.optString("strength", ""),
                            dosageForm = obj.optString("dosageForm", "ট্যাবলেট"),
                            unit = obj.optString("unit", "পাতা/পিস"),
                            purchasePrice = obj.optDouble("purchasePrice", 0.0),
                            sellingPrice = obj.optDouble("sellingPrice", 0.0),
                            currentStock = obj.optDouble("currentStock", 0.0),
                            minStockLevel = obj.optDouble("minStockLevel", 10.0),
                            batchNumber = obj.optString("batchNumber", ""),
                            expiryDate = obj.optLong("expiryDate", 0L),
                            supplierName = obj.optString("supplierName", ""),
                            note = obj.optString("note", ""),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            isDeleted = obj.optBoolean("isDeleted", false)
                        )
                    )
                }
            }

            val salesArray = root.optJSONArray("sales")
            if (salesArray != null) {
                database.saleDao().clearAllSales()
                for (i in 0 until salesArray.length()) {
                    val obj = salesArray.getJSONObject(i)
                    database.saleDao().insertSale(
                        Sale(
                            id = obj.optLong("id", 0),
                            receiptNumber = obj.optString("receiptNumber", "INV-${System.currentTimeMillis()}"),
                            customerId = if (obj.has("customerId") && !obj.isNull("customerId")) obj.optLong("customerId") else null,
                            customerName = obj.optString("customerName", "নগদ ক্রেতা"),
                            customerPhone = obj.optString("customerPhone", ""),
                            subtotal = obj.optDouble("subtotal", 0.0),
                            discount = obj.optDouble("discount", 0.0),
                            grandTotal = obj.optDouble("grandTotal", 0.0),
                            paidAmount = obj.optDouble("paidAmount", 0.0),
                            dueAmount = obj.optDouble("dueAmount", 0.0),
                            saleDate = obj.optLong("saleDate", System.currentTimeMillis()),
                            note = obj.optString("note", ""),
                            isDeleted = obj.optBoolean("isDeleted", false)
                        )
                    )
                }
            }

            val saleItemsArray = root.optJSONArray("sale_items")
            if (saleItemsArray != null) {
                database.saleDao().clearAllSaleItems()
                val list = mutableListOf<SaleItem>()
                for (i in 0 until saleItemsArray.length()) {
                    val obj = saleItemsArray.getJSONObject(i)
                    list.add(
                        SaleItem(
                            id = obj.optLong("id", 0),
                            saleId = obj.optLong("saleId", 0),
                            medicineId = obj.optLong("medicineId", 0),
                            medicineName = obj.optString("medicineName", ""),
                            quantity = obj.optDouble("quantity", 1.0),
                            unitPrice = obj.optDouble("unitPrice", 0.0),
                            purchasePrice = obj.optDouble("purchasePrice", 0.0),
                            totalPrice = obj.optDouble("totalPrice", 0.0)
                        )
                    )
                }
                database.saleDao().insertSaleItems(list)
            }

            val paymentsArray = root.optJSONArray("payments")
            if (paymentsArray != null) {
                database.paymentDao().clearAll()
                for (i in 0 until paymentsArray.length()) {
                    val obj = paymentsArray.getJSONObject(i)
                    database.paymentDao().insertPayment(
                        Payment(
                            id = obj.optLong("id", 0),
                            receiptNumber = obj.optString("receiptNumber", ""),
                            customerId = obj.optLong("customerId", 0),
                            amount = obj.optDouble("amount", 0.0),
                            paymentDate = obj.optLong("paymentDate", System.currentTimeMillis()),
                            paymentMethod = obj.optString("paymentMethod", "নগদ (Cash)"),
                            note = obj.optString("note", ""),
                            isDeleted = obj.optBoolean("isDeleted", false)
                        )
                    )
                }
            }

            val challansArray = root.optJSONArray("challans")
            if (challansArray != null) {
                database.challanDao().clearAllChallans()
                for (i in 0 until challansArray.length()) {
                    val obj = challansArray.getJSONObject(i)
                    database.challanDao().insertChallan(
                        Challan(
                            id = obj.optLong("id", 0),
                            challanNumber = obj.optString("challanNumber", "CH-${System.currentTimeMillis()}"),
                            customerId = if (obj.has("customerId") && !obj.isNull("customerId")) obj.optLong("customerId") else null,
                            customerName = obj.optString("customerName", "সাধারণ ক্রেতা"),
                            customerPhone = obj.optString("customerPhone", ""),
                            customerAddress = obj.optString("customerAddress", ""),
                            grossTotal = obj.optDouble("grossTotal", 0.0),
                            totalDiscount = obj.optDouble("totalDiscount", 0.0),
                            grandTotal = obj.optDouble("grandTotal", 0.0),
                            paidAmount = obj.optDouble("paidAmount", 0.0),
                            dueAmount = obj.optDouble("dueAmount", 0.0),
                            challanDate = obj.optLong("challanDate", System.currentTimeMillis()),
                            note = obj.optString("note", ""),
                            isCancelled = obj.optBoolean("isCancelled", false)
                        )
                    )
                }
            }

            val challanItemsArray = root.optJSONArray("challan_items")
            if (challanItemsArray != null) {
                database.challanDao().clearAllChallanItems()
                val list = mutableListOf<ChallanItem>()
                for (i in 0 until challanItemsArray.length()) {
                    val obj = challanItemsArray.getJSONObject(i)
                    list.add(
                        ChallanItem(
                            id = obj.optLong("id", 0),
                            challanId = obj.optLong("challanId", 0),
                            serialNumber = obj.optInt("serialNumber", i + 1),
                            medicineId = obj.optLong("medicineId", 0),
                            medicineName = obj.optString("medicineName", ""),
                            companyName = obj.optString("companyName", ""),
                            piecesPerBox = obj.optInt("piecesPerBox", 100),
                            boxQuantity = obj.optDouble("boxQuantity", 1.0),
                            totalPieces = obj.optDouble("totalPieces", 100.0),
                            boxPrice = obj.optDouble("boxPrice", 0.0),
                            discountPercent = obj.optDouble("discountPercent", 0.0),
                            discountAmount = obj.optDouble("discountAmount", 0.0),
                            netTotal = obj.optDouble("netTotal", 0.0)
                        )
                    )
                }
                database.challanDao().insertChallanItems(list)
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun exportCustomersCsv(): File = withContext(Dispatchers.IO) {
        val customers = database.openHelper.readableDatabase.query("SELECT * FROM customers WHERE isArchived = 0").use { cursor ->
            val list = mutableListOf<String>()
            list.add("ID,নাম,মোবাইল,ঠিকানা,পূর্বের বাকি,তৈরির তারিখ")
            while (cursor.moveToNext()) {
                val id = cursor.getLong(cursor.getColumnIndexOrThrow("id"))
                val name = cursor.getString(cursor.getColumnIndexOrThrow("name")).replace(",", " ")
                val phone = cursor.getString(cursor.getColumnIndexOrThrow("phone"))
                val address = cursor.getString(cursor.getColumnIndexOrThrow("address")).replace(",", " ")
                val due = cursor.getDouble(cursor.getColumnIndexOrThrow("openingDue"))
                val date = cursor.getLong(cursor.getColumnIndexOrThrow("createdAt"))
                list.add("$id,$name,$phone,$address,$due,$date")
            }
            list
        }
        val file = File(context.cacheDir, "customers_export.csv")
        file.writeText(customers.joinToString("\n"))
        file
    }

    suspend fun exportMedicinesCsv(): File = withContext(Dispatchers.IO) {
        val medicines = database.openHelper.readableDatabase.query("SELECT * FROM medicines WHERE isDeleted = 0").use { cursor ->
            val list = mutableListOf<String>()
            list.add("ID,ওষুধের নাম,জেনেরিক,কোম্পানি,ক্যাটাগরি,মজুত স্টক,ক্রয়মূল্য,বিক্রয়মূল্য")
            while (cursor.moveToNext()) {
                val id = cursor.getLong(cursor.getColumnIndexOrThrow("id"))
                val name = cursor.getString(cursor.getColumnIndexOrThrow("name")).replace(",", " ")
                val generic = cursor.getString(cursor.getColumnIndexOrThrow("genericName")).replace(",", " ")
                val company = cursor.getString(cursor.getColumnIndexOrThrow("company")).replace(",", " ")
                val cat = cursor.getString(cursor.getColumnIndexOrThrow("category"))
                val stock = cursor.getDouble(cursor.getColumnIndexOrThrow("currentStock"))
                val buy = cursor.getDouble(cursor.getColumnIndexOrThrow("purchasePrice"))
                val sell = cursor.getDouble(cursor.getColumnIndexOrThrow("sellingPrice"))
                list.add("$id,$name,$generic,$company,$cat,$stock,$buy,$sell")
            }
            list
        }
        val file = File(context.cacheDir, "medicines_export.csv")
        file.writeText(medicines.joinToString("\n"))
        file
    }
}
