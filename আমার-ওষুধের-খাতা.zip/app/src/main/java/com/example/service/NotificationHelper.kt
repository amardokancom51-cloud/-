package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {
    const val CHANNEL_DUE = "channel_due_reminders"
    const val CHANNEL_EXPIRY = "channel_expiry_alerts"
    const val CHANNEL_STOCK = "channel_stock_alerts"
    const val CHANNEL_BACKUP = "channel_backup_status"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val dueChannel = NotificationChannel(
                CHANNEL_DUE,
                "বাকি পরিশোধের তাগাদা",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "গ্রাহকদের সম্ভাব্য বাকি পরিশোধের তারিখের নোটিফিকেশন"
            }

            val expiryChannel = NotificationChannel(
                CHANNEL_EXPIRY,
                "ওষুধ মেয়াদ সতর্কতা",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "মেয়াদোত্তীর্ণ অথবা আসন্ন মেয়াদের ওষুধের সতর্কতা"
            }

            val stockChannel = NotificationChannel(
                CHANNEL_STOCK,
                "স্বল্প স্টক সতর্কতা",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "ওষুধের স্টক নির্দিষ্ট পরিমাণের নিচে নেমে গেলে নোটিফিকেশন"
            }

            val backupChannel = NotificationChannel(
                CHANNEL_BACKUP,
                "ডাটা ব্যাকআপ ও রিস্টোর",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "গুগল ড্রাইভ ও লোকাল ব্যাকআপ স্ট্যাটাস"
            }

            notificationManager.createNotificationChannels(
                listOf(dueChannel, expiryChannel, stockChannel, backupChannel)
            )
        }
    }

    private fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun showPaymentDueReminder(context: Context, customerName: String, amount: Double, dateStr: String) {
        if (!hasNotificationPermission(context)) return
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            101,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_DUE)
            .setSmallIcon(R.drawable.ic_app_pharmacy_logo)
            .setContentTitle("বাকি পরিশোধের তাগাদা - $customerName")
            .setContentText("পরিশোধের সম্ভাব্য তারিখ: $dateStr | বাকি: ৳${"%.2f".format(amount)}")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("গ্রাহক $customerName এর কাছ থেকে ৳${"%.2f".format(amount)} বাকি আদায়ের সম্ভাব্য তারিখ $dateStr। তাগাদা দিতে কল বা যোগাযোগ করুন।")
            )
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(101 + customerName.hashCode(), notification)
    }

    fun showExpiryAlert(context: Context, count: Int, sampleName: String) {
        if (!hasNotificationPermission(context)) return
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            102,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_EXPIRY)
            .setSmallIcon(R.drawable.ic_app_pharmacy_logo)
            .setContentTitle("মেয়াদোত্তীর্ণ ওষুধের সতর্কতা!")
            .setContentText("$count টি ওষুধের মেয়াদ আসন্ন বা শেষ হয়ে গেছে (যেমন: $sampleName)")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(202, notification)
    }

    fun showLowStockAlert(context: Context, count: Int, sampleName: String) {
        if (!hasNotificationPermission(context)) return
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            103,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_STOCK)
            .setSmallIcon(R.drawable.ic_app_pharmacy_logo)
            .setContentTitle("স্বল্প স্টক অ্যালার্ট!")
            .setContentText("$count টি ওষুধের স্টক শেষ পর্যায়ে (যেমন: $sampleName)")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(203, notification)
    }

    fun showBackupNotification(context: Context, isSuccess: Boolean, message: String) {
        if (!hasNotificationPermission(context)) return
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val notification = NotificationCompat.Builder(context, CHANNEL_BACKUP)
            .setSmallIcon(R.drawable.ic_app_pharmacy_logo)
            .setContentTitle(if (isSuccess) "ডাটা ব্যাকআপ সম্পন্ন" else "ডাটা ব্যাকআপ ব্যর্থ")
            .setContentText(message)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(301, notification)
    }
}
