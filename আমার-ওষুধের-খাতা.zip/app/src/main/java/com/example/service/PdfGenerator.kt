package com.example.service

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Customer
import com.example.data.model.Medicine
import com.example.data.model.Payment
import com.example.data.model.Sale
import com.example.data.model.SaleItem
import com.example.data.repository.CustomerFinancialSummary
import com.example.data.repository.CustomerLedgerEntry
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class ShopInfo(
    val shopName: String = "আমার ওষুধের খাতা",
    val ownerName: String = "",
    val phone: String = "",
    val address: String = "",
    val receiptFooter: String = "আমাদের সাথে থাকার জন্য ধন্যবাদ। সুস্থ থাকুন।",
    val email: String = ""
)

object PdfGenerator {
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.US)
    private val shortDateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.US)

    fun generateSaleReceiptPdf(
        context: Context,
        sale: Sale,
        items: List<SaleItem>,
        shopInfo: ShopInfo,
        previousDue: Double,
        currentDue: Double
    ): File {
        val pdfDoc = PdfDocument()
        val pageWidth = 400
        val pageHeight = 650 + (items.size * 30)
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDoc.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint().apply { isAntiAlias = true }

        // Header Background
        paint.color = Color.parseColor("#00695C")
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 95f, paint)

        // Shop Title
        paint.color = Color.WHITE
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(shopInfo.shopName, 20f, 32f, paint)

        // Subtitle / Address / Phone
        paint.textSize = 10f
        paint.typeface = Typeface.DEFAULT
        if (shopInfo.address.isNotBlank()) {
            canvas.drawText(shopInfo.address, 20f, 50f, paint)
        }
        val contact = if (shopInfo.phone.isNotBlank()) "মোবাইল: ${shopInfo.phone}" else ""
        canvas.drawText(contact, 20f, 66f, paint)
        canvas.drawText("বিক্রি চালান / ক্যাশ মেমো", 20f, 84f, paint)

        var y = 120f
        paint.color = Color.BLACK
        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT

        // Invoice metadata
        canvas.drawText("রসিদ নং: ${sale.receiptNumber}", 20f, y, paint)
        y += 18f
        canvas.drawText("তারিখ: ${dateFormat.format(Date(sale.saleDate))}", 20f, y, paint)
        y += 18f
        canvas.drawText("ক্রেতার নাম: ${sale.customerName}", 20f, y, paint)
        if (sale.customerPhone.isNotBlank()) {
            y += 18f
            canvas.drawText("মোবাইল: ${sale.customerPhone}", 20f, y, paint)
        }

        y += 25f
        // Table Header
        paint.color = Color.parseColor("#ECEFF1")
        canvas.drawRect(20f, y - 16f, (pageWidth - 20).toFloat(), y + 8f, paint)

        paint.color = Color.BLACK
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 10f
        canvas.drawText("ওষুধের বিবরণ", 25f, y, paint)
        canvas.drawText("পরিমাণ", 210f, y, paint)
        canvas.drawText("দর", 270f, y, paint)
        canvas.drawText("মোট", 330f, y, paint)

        // Divider
        y += 12f
        paint.color = Color.LTGRAY
        paint.strokeWidth = 1f
        canvas.drawLine(20f, y, (pageWidth - 20).toFloat(), y, paint)

        // Table Rows
        paint.color = Color.BLACK
        paint.typeface = Typeface.DEFAULT
        for (item in items) {
            y += 20f
            val medName = if (item.medicineName.length > 24) item.medicineName.take(22) + ".." else item.medicineName
            canvas.drawText(medName, 25f, y, paint)
            canvas.drawText("${"%.0f".format(item.quantity)}", 215f, y, paint)
            canvas.drawText("৳${"%.1f".format(item.unitPrice)}", 270f, y, paint)
            canvas.drawText("৳${"%.1f".format(item.totalPrice)}", 330f, y, paint)
        }

        y += 20f
        paint.color = Color.LTGRAY
        canvas.drawLine(20f, y, (pageWidth - 20).toFloat(), y, paint)

        // Financial Summary
        y += 20f
        paint.color = Color.BLACK
        paint.textSize = 11f
        canvas.drawText("মোট মূল্য (Subtotal):", 190f, y, paint)
        canvas.drawText("৳${"%.2f".format(sale.subtotal)}", 320f, y, paint)

        if (sale.discount > 0) {
            y += 20f
            canvas.drawText("ছাড় (Discount):", 190f, y, paint)
            canvas.drawText("-৳${"%.2f".format(sale.discount)}", 320f, y, paint)
        }

        y += 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("সর্বমোট বিল:", 190f, y, paint)
        canvas.drawText("৳${"%.2f".format(sale.grandTotal)}", 320f, y, paint)

        y += 20f
        paint.color = Color.parseColor("#2E7D32")
        canvas.drawText("নগদ পরিশোধ:", 190f, y, paint)
        canvas.drawText("৳${"%.2f".format(sale.paidAmount)}", 320f, y, paint)

        y += 20f
        paint.color = Color.parseColor("#C62828")
        canvas.drawText("চালানের বাকি:", 190f, y, paint)
        canvas.drawText("৳${"%.2f".format(sale.dueAmount)}", 320f, y, paint)

        if (sale.customerId != null) {
            y += 20f
            paint.color = Color.BLACK
            paint.typeface = Typeface.DEFAULT
            canvas.drawText("পূর্বের বাকি:", 190f, y, paint)
            canvas.drawText("৳${"%.2f".format(previousDue)}", 320f, y, paint)

            y += 22f
            paint.color = Color.parseColor("#B71C1C")
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("সর্বমোট বর্তমান বাকি:", 170f, y, paint)
            canvas.drawText("৳${"%.2f".format(currentDue)}", 320f, y, paint)
        }

        // Footer Note
        y += 45f
        paint.color = Color.GRAY
        paint.textSize = 9f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        canvas.drawText(shopInfo.receiptFooter, 20f, y, paint)
        y += 15f
        canvas.drawText("সফটওয়্যার: আমার ওষুধের খাতা (অফলাইন হিসাব ব্যবস্থাপনা)", 20f, y, paint)

        pdfDoc.finishPage(page)

        val file = File(context.cacheDir, "Receipt_${sale.receiptNumber}.pdf")
        FileOutputStream(file).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()
        return file
    }

    fun generatePaymentReceiptPdf(
        context: Context,
        payment: Payment,
        customer: Customer,
        shopInfo: ShopInfo,
        previousDue: Double,
        currentDue: Double
    ): File {
        val pdfDoc = PdfDocument()
        val pageWidth = 400
        val pageHeight = 520
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDoc.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint().apply { isAntiAlias = true }

        // Header Background
        paint.color = Color.parseColor("#1B5E20")
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 90f, paint)

        paint.color = Color.WHITE
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(shopInfo.shopName, 20f, 32f, paint)

        paint.textSize = 10f
        paint.typeface = Typeface.DEFAULT
        if (shopInfo.address.isNotBlank()) {
            canvas.drawText(shopInfo.address, 20f, 50f, paint)
        }
        canvas.drawText("বাকি পরিশোধের মানি রিসিট", 20f, 74f, paint)

        var y = 125f
        paint.color = Color.BLACK
        paint.textSize = 11f
        canvas.drawText("রসিদ নং: ${payment.receiptNumber.ifBlank { "PAY-${payment.id}" }}", 20f, y, paint)
        y += 20f
        canvas.drawText("তারিখ: ${dateFormat.format(Date(payment.paymentDate))}", 20f, y, paint)
        y += 20f
        canvas.drawText("গ্রাহকের নাম: ${customer.name}", 20f, y, paint)
        if (customer.phone.isNotBlank()) {
            y += 20f
            canvas.drawText("মোবাইল: ${customer.phone}", 20f, y, paint)
        }
        y += 20f
        canvas.drawText("পরিশোধের মাধ্যম: ${payment.paymentMethod}", 20f, y, paint)
        if (payment.note.isNotBlank()) {
            y += 20f
            canvas.drawText("মন্তব্য: ${payment.note}", 20f, y, paint)
        }

        y += 35f
        paint.color = Color.parseColor("#E8F5E9")
        canvas.drawRoundRect(20f, y - 20f, (pageWidth - 20).toFloat(), y + 110f, 8f, 8f, paint)

        paint.color = Color.BLACK
        paint.textSize = 12f
        canvas.drawText("পূর্বের বাকি:", 35f, y + 5f, paint)
        canvas.drawText("৳${"%.2f".format(previousDue)}", 270f, y + 5f, paint)

        paint.color = Color.parseColor("#2E7D32")
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 14f
        canvas.drawText("জমা / পরিশোধ:", 35f, y + 40f, paint)
        canvas.drawText("৳${"%.2f".format(payment.amount)}", 270f, y + 40f, paint)

        paint.color = Color.parseColor("#C62828")
        paint.textSize = 12f
        canvas.drawText("অবশিষ্ট বর্তমান বাকি:", 35f, y + 75f, paint)
        canvas.drawText("৳${"%.2f".format(currentDue)}", 270f, y + 75f, paint)

        y += 150f
        paint.color = Color.GRAY
        paint.textSize = 9f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        canvas.drawText(shopInfo.receiptFooter, 20f, y, paint)
        y += 15f
        canvas.drawText("আমার ওষুধের খাতা - ডিজিটাল হিসাব ও বাকি খাতা", 20f, y, paint)

        pdfDoc.finishPage(page)

        val file = File(context.cacheDir, "PaymentReceipt_${payment.id}.pdf")
        FileOutputStream(file).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()
        return file
    }

    fun generateCustomerLedgerPdf(
        context: Context,
        customer: Customer,
        ledger: List<CustomerLedgerEntry>,
        summary: CustomerFinancialSummary,
        shopInfo: ShopInfo
    ): File {
        val pdfDoc = PdfDocument()
        val pageWidth = 595 // A4 standard width (pt)
        val pageHeight = (842 + (ledger.size * 22)).coerceAtLeast(842)
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDoc.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint().apply { isAntiAlias = true }

        // Header
        paint.color = Color.parseColor("#004D40")
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 85f, paint)

        paint.color = Color.WHITE
        paint.textSize = 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(shopInfo.shopName, 25f, 35f, paint)

        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT
        canvas.drawText("গ্রাহক পূর্ণাঙ্গ বাকি ও জমার খতিয়ান (Ledger Statement)", 25f, 58f, paint)
        canvas.drawText("তারিখ: ${shortDateFormat.format(Date())}", 450f, 58f, paint)

        var y = 115f
        paint.color = Color.BLACK
        paint.textSize = 12f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("গ্রাহক: ${customer.name}", 25f, y, paint)
        paint.typeface = Typeface.DEFAULT
        canvas.drawText("মোবাইল: ${customer.phone}", 320f, y, paint)
        y += 18f
        if (customer.address.isNotBlank()) {
            canvas.drawText("ঠিকানা: ${customer.address}", 25f, y, paint)
        }

        // Summary Bar
        y += 25f
        paint.color = Color.parseColor("#E0F2F1")
        canvas.drawRect(25f, y - 16f, (pageWidth - 25).toFloat(), y + 25f, paint)

        paint.color = Color.BLACK
        paint.textSize = 10f
        canvas.drawText("মোট বিক্রি: ৳${"%.2f".format(summary.totalSalesAmount)}", 35f, y + 6f, paint)
        canvas.drawText("মোট আদায়: ৳${"%.2f".format(summary.totalPaidAmount)}", 195f, y + 6f, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.color = Color.parseColor("#C62828")
        canvas.drawText("বর্তমান নিট বাকি: ৳${"%.2f".format(summary.currentDue)}", 370f, y + 6f, paint)

        // Table Header
        y += 45f
        paint.color = Color.parseColor("#CFD8DC")
        canvas.drawRect(25f, y - 14f, (pageWidth - 25).toFloat(), y + 8f, paint)

        paint.color = Color.BLACK
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("তারিখ", 30f, y, paint)
        canvas.drawText("বিবরণ ও চালান", 110f, y, paint)
        canvas.drawText("বাকি (দেবীট)", 320f, y, paint)
        canvas.drawText("জমা (ক্রেডিট)", 410f, y, paint)
        canvas.drawText("ব্যালেন্স", 500f, y, paint)

        // Ledger Items
        paint.typeface = Typeface.DEFAULT
        for (item in ledger) {
            y += 20f
            canvas.drawText(shortDateFormat.format(Date(item.date)), 30f, y, paint)
            val desc = if (item.title.length > 28) item.title.take(26) + ".." else item.title
            canvas.drawText(desc, 110f, y, paint)
            canvas.drawText(if (item.debit > 0) "৳${"%.1f".format(item.debit)}" else "-", 320f, y, paint)
            canvas.drawText(if (item.credit > 0) "৳${"%.1f".format(item.credit)}" else "-", 410f, y, paint)
            canvas.drawText("৳${"%.1f".format(item.balance)}", 500f, y, paint)
        }

        y += 35f
        paint.color = Color.GRAY
        paint.textSize = 9f
        canvas.drawText("এই রিপোর্টটি 'আমার ওষুধের খাতা' মোবাইল অ্যাপ দ্বারা স্বয়ংক্রিয়ভাবে প্রস্তুতকৃত।", 25f, y, paint)

        pdfDoc.finishPage(page)

        val file = File(context.cacheDir, "CustomerLedger_${customer.id}.pdf")
        FileOutputStream(file).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()
        return file
    }

    fun generateStockReportPdf(
        context: Context,
        medicines: List<Medicine>,
        shopInfo: ShopInfo,
        title: String = "ওষুধ স্টক রিপোর্ট"
    ): File {
        val pdfDoc = PdfDocument()
        val pageWidth = 595
        val pageHeight = (842 + (medicines.size * 22)).coerceAtLeast(842)
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDoc.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint().apply { isAntiAlias = true }

        // Header
        paint.color = Color.parseColor("#00695C")
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 75f, paint)

        paint.color = Color.WHITE
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(shopInfo.shopName, 25f, 32f, paint)

        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT
        canvas.drawText(title, 25f, 55f, paint)
        canvas.drawText("তারিখ: ${shortDateFormat.format(Date())}", 450f, 55f, paint)

        var y = 105f
        // Table Header
        paint.color = Color.parseColor("#ECEFF1")
        canvas.drawRect(25f, y - 14f, (pageWidth - 25).toFloat(), y + 8f, paint)

        paint.color = Color.BLACK
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("ওষুধের নাম", 30f, y, paint)
        canvas.drawText("জেনেরিক / কোম্পানি", 170f, y, paint)
        canvas.drawText("স্টক", 340f, y, paint)
        canvas.drawText("ক্রয়দর", 400f, y, paint)
        canvas.drawText("বিক্রয়দর", 470f, y, paint)
        canvas.drawText("স্টক মূল্য", 530f, y, paint)

        paint.typeface = Typeface.DEFAULT
        var totalStockValue = 0.0

        for (m in medicines) {
            y += 20f
            val itemStockVal = m.currentStock * m.purchasePrice
            totalStockValue += itemStockVal

            val medName = if (m.name.length > 20) m.name.take(18) + ".." else m.name
            val sub = if (m.genericName.isNotBlank()) m.genericName else m.company
            val subText = if (sub.length > 24) sub.take(22) + ".." else sub

            canvas.drawText(medName, 30f, y, paint)
            canvas.drawText(subText, 170f, y, paint)
            canvas.drawText("${"%.0f".format(m.currentStock)}", 340f, y, paint)
            canvas.drawText("৳${"%.1f".format(m.purchasePrice)}", 400f, y, paint)
            canvas.drawText("৳${"%.1f".format(m.sellingPrice)}", 470f, y, paint)
            canvas.drawText("৳${"%.0f".format(itemStockVal)}", 530f, y, paint)
        }

        y += 30f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("সর্বমোট স্টক আইটেম: ${medicines.size} টি | মোট ক্রয়মূল্যে স্টক ভ্যালু: ৳${"%.2f".format(totalStockValue)}", 30f, y, paint)

        pdfDoc.finishPage(page)

        val file = File(context.cacheDir, "StockReport_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()
        return file
    }

    fun generateChallanPdf(
        context: Context,
        challan: com.example.data.model.Challan,
        items: List<com.example.data.model.ChallanItem>,
        shopInfo: ShopInfo,
        previousDue: Double = 0.0,
        currentDue: Double = 0.0
    ): File {
        val pdfDoc = PdfDocument()
        val pageWidth = 595 // Standard A4 width in points
        val pageHeight = 842 // Standard A4 height in points

        // Calculate pages and item distribution cleanly
        val pagesItems = mutableListOf<List<com.example.data.model.ChallanItem>>()
        var remaining = items
        var isFirstPage = true
        while (remaining.isNotEmpty()) {
            val capacityWithSummary = if (isFirstPage) 16 else 21
            val capacityWithoutSummary = if (isFirstPage) 24 else 29
            if (remaining.size <= capacityWithSummary) {
                pagesItems.add(remaining)
                remaining = emptyList()
            } else {
                val chunk = remaining.take(capacityWithoutSummary)
                pagesItems.add(chunk)
                remaining = remaining.drop(capacityWithoutSummary)
            }
            isFirstPage = false
        }
        if (pagesItems.isEmpty()) {
            pagesItems.add(emptyList())
        }

        // Check if last page has room for summary block
        val lastPageItemCount = pagesItems.last().size
        val maxOnLastPageWithSummary = if (pagesItems.size == 1) 16 else 21
        val needsExtraSummaryPage = lastPageItemCount > maxOnLastPageWithSummary
        val totalPages = if (needsExtraSummaryPage) pagesItems.size + 1 else pagesItems.size

        val paint = Paint().apply { isAntiAlias = true }

        for (pageIndex in 0 until totalPages) {
            val pageNum = pageIndex + 1
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
            val page = pdfDoc.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            var y: Float

            if (pageIndex == 0) {
                // First page header banner
                paint.color = Color.parseColor("#00695C")
                canvas.drawRect(0f, 0f, pageWidth.toFloat(), 88f, paint)

                // Medical Cross / Logo Emblem
                paint.color = Color.parseColor("#80CBC4")
                canvas.drawCircle(44f, 44f, 22f, paint)
                paint.color = Color.WHITE
                paint.strokeWidth = 4f
                canvas.drawLine(44f, 32f, 44f, 56f, paint)
                canvas.drawLine(32f, 44f, 56f, 44f, paint)
                paint.strokeWidth = 1f

                // Shop Name
                paint.color = Color.WHITE
                paint.textSize = 19f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText(shopInfo.shopName.ifBlank { "আমার ওষুধের খাতা" }, 78f, 36f, paint)

                // Address & Phone & Email
                paint.textSize = 9.5f
                paint.typeface = Typeface.DEFAULT
                val addressLine = if (shopInfo.address.isNotBlank()) shopInfo.address else "ফার্মেসি ও ড্রাগ হাউস"
                canvas.drawText(addressLine, 78f, 52f, paint)

                val contactDetails = StringBuilder()
                if (shopInfo.phone.isNotBlank()) contactDetails.append("মোবাইল: ${shopInfo.phone}  ")
                if (shopInfo.email.isNotBlank()) contactDetails.append("ইমেইল: ${shopInfo.email}")
                canvas.drawText(contactDetails.toString(), 78f, 68f, paint)

                // Challan Title badge on top right
                paint.color = Color.parseColor("#004D40")
                canvas.drawRoundRect(415f, 20f, 575f, 68f, 8f, 8f, paint)
                paint.color = Color.WHITE
                paint.textSize = 15f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("ওষুধের চালান", 442f, 44f, paint)
                paint.textSize = 8.5f
                paint.typeface = Typeface.DEFAULT
                canvas.drawText("Medicine Challan", 450f, 58f, paint)

                // Challan Metadata Box (Bordered)
                y = 100f
                paint.color = Color.parseColor("#F9FBE7")
                canvas.drawRoundRect(20f, y, (pageWidth - 20).toFloat(), y + 60f, 6f, 6f, paint)
                paint.color = Color.parseColor("#C5E1A5")
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f
                canvas.drawRoundRect(20f, y, (pageWidth - 20).toFloat(), y + 60f, 6f, 6f, paint)
                paint.style = Paint.Style.FILL

                // Left: Challan Number & Date
                paint.color = Color.BLACK
                paint.textSize = 10f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("চালান নং: ${challan.challanNumber}", 30f, y + 22f, paint)
                paint.typeface = Typeface.DEFAULT
                canvas.drawText("তারিখ: ${dateFormat.format(Date(challan.challanDate))}", 30f, y + 44f, paint)

                // Right: Customer info
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("ক্রেতা/ফার্মেসি: ${challan.customerName}", 290f, y + 22f, paint)
                paint.typeface = Typeface.DEFAULT
                val custPhone = if (challan.customerPhone.isNotBlank()) "মোবাইল: ${challan.customerPhone}" else ""
                val custAddr = if (challan.customerAddress.isNotBlank()) " | ঠিকানা: ${challan.customerAddress}" else ""
                canvas.drawText("$custPhone$custAddr", 290f, y + 44f, paint)

                y += 72f
            } else {
                // Subsequent pages continuation header
                paint.color = Color.parseColor("#00695C")
                canvas.drawRect(0f, 0f, pageWidth.toFloat(), 38f, paint)
                paint.color = Color.WHITE
                paint.textSize = 12f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("${shopInfo.shopName.ifBlank { "আমার ওষুধের খাতা" }} - ওষুধের চালান", 24f, 24f, paint)
                paint.textSize = 9.5f
                paint.typeface = Typeface.DEFAULT
                canvas.drawText("চালান নং: ${challan.challanNumber} | পৃষ্ঠা $pageNum / $totalPages", 390f, 24f, paint)

                y = 50f
            }

            // Draw Table Header if there are items on this page
            val pageItems = if (pageIndex < pagesItems.size) pagesItems[pageIndex] else emptyList()
            if (pageItems.isNotEmpty()) {
                paint.color = Color.parseColor("#E0F2F1")
                canvas.drawRect(20f, y, (pageWidth - 20).toFloat(), y + 22f, paint)

                paint.color = Color.parseColor("#004D40")
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.textSize = 9.5f

                val textY = y + 15f
                canvas.drawText("নং", 25f, textY, paint)
                canvas.drawText("ওষুধের নাম", 50f, textY, paint)
                canvas.drawText("প্রতি বক্সে", 210f, textY, paint)
                canvas.drawText("বক্স", 265f, textY, paint)
                canvas.drawText("মোট পিস", 305f, textY, paint)
                canvas.drawText("বক্স দর", 365f, textY, paint)
                canvas.drawText("ছাড় %", 425f, textY, paint)
                canvas.drawText("নিট মূল্য", 495f, textY, paint)

                y += 22f
                paint.color = Color.parseColor("#B2DFDB")
                paint.strokeWidth = 1f
                canvas.drawLine(20f, y, (pageWidth - 20).toFloat(), y, paint)

                // Draw Table Rows
                for ((idx, item) in pageItems.withIndex()) {
                    y += 21f

                    // Alternating row background
                    if (idx % 2 == 1) {
                        paint.color = Color.parseColor("#FAFAFA")
                        canvas.drawRect(20f, y - 16f, (pageWidth - 20).toFloat(), y + 5f, paint)
                    }

                    paint.color = Color.BLACK
                    paint.typeface = Typeface.DEFAULT
                    paint.textSize = 9f

                    canvas.drawText("${item.serialNumber}", 25f, y, paint)

                    val nameWithCo = if (item.companyName.isNotBlank()) "${item.medicineName} (${item.companyName})" else item.medicineName
                    val displayName = if (nameWithCo.length > 25) nameWithCo.take(23) + ".." else nameWithCo
                    canvas.drawText(displayName, 50f, y, paint)

                    canvas.drawText("${item.piecesPerBox} পিস", 210f, y, paint)
                    canvas.drawText("${"%.0f".format(item.boxQuantity)}", 268f, y, paint)
                    canvas.drawText("${"%.0f".format(item.totalPieces)}", 308f, y, paint)
                    canvas.drawText("৳${"%.1f".format(item.boxPrice)}", 365f, y, paint)
                    canvas.drawText("${item.discountPercent}%", 428f, y, paint)
                    canvas.drawText("৳${"%.1f".format(item.netTotal)}", 495f, y, paint)

                    // Line between rows
                    paint.color = Color.parseColor("#E0E0E0")
                    canvas.drawLine(20f, y + 4f, (pageWidth - 20).toFloat(), y + 4f, paint)
                }
            }

            // Draw Summary, Signatures, and Footer on final page
            if (pageNum == totalPages) {
                val totalBoxes = items.sumOf { it.boxQuantity }
                val totalPieces = items.sumOf { it.totalPieces }

                y += 18f

                // Left: Box and Piece Summary Box
                paint.color = Color.parseColor("#F1F8E9")
                canvas.drawRoundRect(20f, y, 260f, y + 105f, 6f, 6f, paint)
                paint.color = Color.parseColor("#C5E1A5")
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f
                canvas.drawRoundRect(20f, y, 260f, y + 105f, 6f, 6f, paint)
                paint.style = Paint.Style.FILL

                paint.color = Color.parseColor("#33691E")
                paint.textSize = 10f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("চালান সারাংশ (Item Summary)", 30f, y + 20f, paint)

                paint.color = Color.BLACK
                paint.typeface = Typeface.DEFAULT
                paint.textSize = 9.5f
                canvas.drawText("মোট ওষুধ আইটেম: ${items.size} টি", 30f, y + 40f, paint)
                canvas.drawText("মোট বক্স সংখ্যা: ${"%.0f".format(totalBoxes)} বক্স", 30f, y + 60f, paint)
                canvas.drawText("সর্বমোট পিস: ${"%.0f".format(totalPieces)} পিস", 30f, y + 80f, paint)

                // Right: Financial Totals Box
                paint.color = Color.parseColor("#FAFAFA")
                canvas.drawRoundRect(280f, y, (pageWidth - 20).toFloat(), y + 115f, 6f, 6f, paint)
                paint.color = Color.parseColor("#E0E0E0")
                paint.style = Paint.Style.STROKE
                canvas.drawRoundRect(280f, y, (pageWidth - 20).toFloat(), y + 115f, 6f, 6f, paint)
                paint.style = Paint.Style.FILL

                var finY = y + 18f
                paint.textSize = 9.5f
                paint.typeface = Typeface.DEFAULT
                paint.color = Color.BLACK
                canvas.drawText("মোট মূল মূল্য:", 295f, finY, paint)
                canvas.drawText("৳${"%.2f".format(challan.grossTotal)}", 490f, finY, paint)

                if (challan.totalDiscount > 0) {
                    finY += 16f
                    paint.color = Color.parseColor("#2E7D32")
                    canvas.drawText("মোট ছাড় (Discount):", 295f, finY, paint)
                    canvas.drawText("-৳${"%.2f".format(challan.totalDiscount)}", 490f, finY, paint)
                }

                finY += 18f
                paint.color = Color.parseColor("#00695C")
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.textSize = 10.5f
                canvas.drawText("সর্বমোট চালান মূল্য:", 295f, finY, paint)
                canvas.drawText("৳${"%.2f".format(challan.grandTotal)}", 490f, finY, paint)

                finY += 16f
                paint.color = Color.parseColor("#1B5E20")
                canvas.drawText("পরিশোধিত টাকা (জমা):", 295f, finY, paint)
                canvas.drawText("৳${"%.2f".format(challan.paidAmount)}", 490f, finY, paint)

                if (challan.dueAmount > 0) {
                    finY += 16f
                    paint.color = Color.parseColor("#C62828")
                    canvas.drawText("চালানের বকেয়া বাকি:", 295f, finY, paint)
                    canvas.drawText("৳${"%.2f".format(challan.dueAmount)}", 490f, finY, paint)
                }

                if (challan.customerId != null && previousDue > 0) {
                    finY += 16f
                    paint.color = Color.BLACK
                    paint.typeface = Typeface.DEFAULT
                    paint.textSize = 9f
                    canvas.drawText("পূর্বের বাকি: ৳${"%.2f".format(previousDue)}  |  বর্তমান বাকি: ৳${"%.2f".format(currentDue)}", 295f, finY, paint)
                }

                // Signatures Section
                y = (finY + 45f).coerceAtLeast(y + 140f)

                paint.color = Color.DKGRAY
                paint.strokeWidth = 1f

                // Left signature: Customer
                canvas.drawLine(50f, y, 190f, y, paint)
                paint.textSize = 9.5f
                paint.typeface = Typeface.DEFAULT
                canvas.drawText("ক্রেতার স্বাক্ষর", 90f, y + 14f, paint)

                // Right signature: Seller
                canvas.drawLine(400f, y, 540f, y, paint)
                canvas.drawText("বিক্রেতার স্বাক্ষর", 435f, y + 14f, paint)

                // Shop Footer Note
                y += 32f
                paint.color = Color.GRAY
                paint.textSize = 9f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                val footer1 = shopInfo.receiptFooter.ifBlank { "কেনাকাটার জন্য ধন্যবাদ। সুস্থ থাকুন।" }
                canvas.drawText(footer1, 24f, y, paint)

                paint.typeface = Typeface.DEFAULT
                paint.textSize = 8f
                canvas.drawText("এই চালানটি সফটওয়্যার দ্বারা তৈরি করা হয়েছে।", 24f, y + 12f, paint)
            }

            // Bottom running footer on every page
            paint.color = Color.parseColor("#E0E0E0")
            canvas.drawLine(20f, 815f, (pageWidth - 20).toFloat(), 815f, paint)

            paint.color = Color.GRAY
            paint.textSize = 8f
            paint.typeface = Typeface.DEFAULT
            canvas.drawText("আমার ওষুধের খাতা - সম্পূর্ণ অফলাইন ফার্মেসি ও চালান ব্যবস্থাপনা", 24f, 827f, paint)
            canvas.drawText("পৃষ্ঠা $pageNum এর $totalPages", 510f, 827f, paint)

            pdfDoc.finishPage(page)
        }

        val file = File(context.cacheDir, "Challan_${challan.challanNumber}.pdf")
        FileOutputStream(file).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()
        return file
    }

    fun savePdfToPhoneStorage(context: Context, sourceFile: File, targetFileName: String): Pair<Boolean, String> {
        return try {
            val docsDir = File(
                android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS),
                "আমার ওষুধের খাতা/চালান"
            )
            if (!docsDir.exists()) {
                docsDir.mkdirs()
            }
            val destination = File(docsDir, targetFileName)
            sourceFile.copyTo(destination, overwrite = true)
            Pair(true, "চালান PDF সফলভাবে সংরক্ষণ করা হয়েছে:\nDocuments/আমার ওষুধের খাতা/চালান/$targetFileName")
        } catch (e: Exception) {
            try {
                val dlDir = File(
                    android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS),
                    "আমার ওষুধের খাতা/চালান"
                )
                if (!dlDir.exists()) dlDir.mkdirs()
                val dlDest = File(dlDir, targetFileName)
                sourceFile.copyTo(dlDest, overwrite = true)
                Pair(true, "চালান PDF সফলভাবে সংরক্ষণ করা হয়েছে:\nDownload/আমার ওষুধের খাতা/চালান/$targetFileName")
            } catch (ex: Exception) {
                try {
                    val appDocs = File(context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS), "চালান")
                    if (!appDocs.exists()) appDocs.mkdirs()
                    val fallbackDest = File(appDocs, targetFileName)
                    sourceFile.copyTo(fallbackDest, overwrite = true)
                    Pair(true, "চালান PDF সফলভাবে সংরক্ষণ করা হয়েছে:\n${fallbackDest.name}")
                } catch (lastEx: Exception) {
                    Pair(false, "সংরক্ষণ করতে সমস্যা হয়েছে: ${lastEx.localizedMessage}")
                }
            }
        }
    }

    fun sharePdf(context: Context, file: File, title: String = "চালান শেয়ার করুন") {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Toast.makeText(context, "শেয়ার করতে সমস্যা হয়েছে: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun printPdf(context: Context, file: File, jobName: String = "Challan_Print") {
        try {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
            if (printManager == null) {
                Toast.makeText(context, "প্রিন্ট সেবা পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
                return
            }
            val adapter = object : android.print.PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: android.os.CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: android.os.Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val pdi = android.print.PrintDocumentInfo.Builder(file.name)
                        .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(android.print.PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                        .build()
                    callback?.onLayoutFinished(pdi, true)
                }

                override fun onWrite(
                    pages: Array<out android.print.PageRange>?,
                    destination: android.os.ParcelFileDescriptor?,
                    cancellationSignal: android.os.CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    try {
                        FileInputStream(file).use { input ->
                            FileOutputStream(destination?.fileDescriptor).use { output ->
                                input.copyTo(output)
                            }
                        }
                        callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    }
                }
            }
            printManager.print(jobName, adapter, null)
        } catch (e: Exception) {
            Toast.makeText(context, "প্রিন্ট ব্যর্থ হয়েছে: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun openPdfFile(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "PDF ওপেন করার জন্য উপযুক্ত অ্যাপ ইনস্টল নেই", Toast.LENGTH_SHORT).show()
        }
    }
}
