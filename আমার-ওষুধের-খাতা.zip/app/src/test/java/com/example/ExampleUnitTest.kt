package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testAccountingCalculation() {
    // Previous Due = 500
    // Sale: 5 * 20 = 100, Paid = 40, Due = 60
    // Payment received = 200
    // Current Due = 500 + 60 - 200 = 360
    val previousDue = 500.0
    val quantity = 5.0
    val unitPrice = 20.0
    val saleTotal = quantity * unitPrice
    val paidOnSale = 40.0
    val newSaleDue = saleTotal - paidOnSale
    val laterPayment = 200.0

    val currentDue = previousDue + newSaleDue - laterPayment
    assertEquals(360.0, currentDue, 0.001)
  }

  @Test
  fun testProfitCalculation() {
    val purchasePrice = 15.0
    val sellingPrice = 20.0
    val quantity = 10.0
    val discount = 5.0
    val profit = ((sellingPrice - purchasePrice) * quantity) - discount
    assertEquals(45.0, profit, 0.001)
  }

  @Test
  fun testMedicineChallanCalculations() {
    // Row 1: Napa 500, piecesPerBox = 100, boxes = 2 -> totalPieces = 200, boxPrice = 500, discount = 5%
    val piecesPerBox1 = 100
    val boxes1 = 2.0
    val totalPieces1 = piecesPerBox1 * boxes1
    assertEquals(200.0, totalPieces1, 0.001)

    val grossPrice1 = boxes1 * 500.0
    val discountPercent1 = 5.0
    val discountAmount1 = grossPrice1 * (discountPercent1 / 100.0)
    val netTotal1 = grossPrice1 - discountAmount1
    assertEquals(1000.0, grossPrice1, 0.001)
    assertEquals(50.0, discountAmount1, 0.001)
    assertEquals(950.0, netTotal1, 0.001)

    // Row 2: Seclo 20, piecesPerBox = 50, boxes = 3 -> totalPieces = 150, boxPrice = 400, discount = 10%
    val piecesPerBox2 = 50
    val boxes2 = 3.0
    val totalPieces2 = piecesPerBox2 * boxes2
    assertEquals(150.0, totalPieces2, 0.001)

    val grossPrice2 = boxes2 * 400.0
    val discountPercent2 = 10.0
    val discountAmount2 = grossPrice2 * (discountPercent2 / 100.0)
    val netTotal2 = grossPrice2 - discountAmount2
    assertEquals(1200.0, grossPrice2, 0.001)
    assertEquals(120.0, discountAmount2, 0.001)
    assertEquals(1080.0, netTotal2, 0.001)

    // Total Challan
    val challanGrandTotal = netTotal1 + netTotal2 // 950 + 1080 = 2030
    val paid = 1000.0
    val challanDue = challanGrandTotal - paid // 1030
    assertEquals(2030.0, challanGrandTotal, 0.001)
    assertEquals(1030.0, challanDue, 0.001)

    // Customer ledger integration
    val previousCustomerDue = 1000.0
    val finalCustomerDue = previousCustomerDue + challanDue
    assertEquals(2030.0, finalCustomerDue, 0.001)
  }
}
